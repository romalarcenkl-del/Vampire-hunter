import { useState, useEffect, useRef, useCallback } from 'react';

type Position = { x: number; y: number };
type Velocity = { x: number; y: number };
type WeaponMode = 'ranged' | 'sword';
type UpgradeId = 'gun' | 'sword' | 'vitality' | 'speed';

type AbilityState = {
  dashCooldown: number;
  burstCooldown: number;
  shieldActive: boolean;
  holyPulse: number;
  swordSlash: number;
};

export type UpgradeState = {
  gun: number;
  sword: number;
  vitality: number;
  speed: number;
};

export type Player = {
  pos: Position;
  health: number;
  maxHealth: number;
  speed: number;
  radius: number;
};

export type Enemy = {
  id: string;
  kind: 'vampire' | 'wraith' | 'boss';
  name?: string;
  pos: Position;
  health: number;
  maxHealth: number;
  speed: number;
  radius: number;
};

export type Bullet = {
  id: string;
  pos: Position;
  vel: Velocity;
  speed: number;
  radius: number;
  damage: number;
};

export type GameState = {
  status: 'menu' | 'playing' | 'shop' | 'gameover';
  score: number;
  wave: number;
  money: number;
  weapon: WeaponMode;
  player: Player;
  enemies: Enemy[];
  bullets: Bullet[];
  upgrades: UpgradeState;
  abilities: AbilityState;
  bossMessage: string;
  shopWave: number;
  notice: string;
};

export const SHOP_UPGRADES: Record<UpgradeId, { label: string; description: string; baseCost: number; max: number }> = {
  gun: { label: 'Silver Rounds', description: 'Ranged damage up. Best against Wraiths.', baseCost: 80, max: 6 },
  sword: { label: 'Blessed Blade', description: 'Sword damage and reach up.', baseCost: 75, max: 6 },
  vitality: { label: 'Blood Vial', description: 'Max blood and healing up.', baseCost: 95, max: 5 },
  speed: { label: 'Hunter Boots', description: 'Move and dash faster.', baseCost: 90, max: 4 },
};

const GAME_WIDTH = 1200;
const GAME_HEIGHT = 800;
const PLAYER_SPEED = 5.4;
const ENEMY_SPEED_BASE = 1.8;
const BULLET_SPEED = 17;
const SHOOT_COOLDOWN = 170;
const SWORD_COOLDOWN = 330;
const DAMAGE_COOLDOWN = 360;
const SCORE_PER_KILL = 100;
const WRAITH_SCORE = 150;
const BOSS_SCORE = 750;
const SCORE_PER_WAVE = 1000;
const DASH_COOLDOWN = 3600;
const BURST_COOLDOWN = 7200;
const DASH_DISTANCE = 150;
const SHIELD_DURATION = 560;
const BURST_RADIUS = 235;
const BURST_DAMAGE = 120;

export const getUpgradeCost = (id: UpgradeId, level: number) => SHOP_UPGRADES[id].baseCost + level * 55;

const createInitialState = (): GameState => ({
  status: 'menu',
  score: 0,
  wave: 1,
  money: 0,
  weapon: 'ranged',
  player: {
    pos: { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 },
    health: 100,
    maxHealth: 100,
    speed: PLAYER_SPEED,
    radius: 15,
  },
  enemies: [],
  bullets: [],
  upgrades: {
    gun: 0,
    sword: 0,
    vitality: 0,
    speed: 0,
  },
  abilities: {
    dashCooldown: 0,
    burstCooldown: 0,
    shieldActive: false,
    holyPulse: 0,
    swordSlash: 0,
  },
  bossMessage: '',
  shopWave: 0,
  notice: '',
});

export function useGameLoop() {
  const [gameState, setGameState] = useState<GameState>(createInitialState());
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const mouseRef = useRef<Position>({ x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 });
  const isMouseDownRef = useRef(false);
  const touchMovementRef = useRef<Velocity>({ x: 0, y: 0 });
  const lastShootTimeRef = useRef(0);
  const lastSwordTimeRef = useRef(0);
  const lastDamageTimeRef = useRef(0);
  const lastDashTimeRef = useRef(-DASH_COOLDOWN);
  const lastBurstTimeRef = useRef(-BURST_COOLDOWN);
  const shieldUntilRef = useRef(0);
  const holyPulseUntilRef = useRef(0);
  const swordSlashUntilRef = useRef(0);
  const dashRequestedRef = useRef(false);
  const burstRequestedRef = useRef(false);
  const weaponToggleRequestedRef = useRef(false);
  const spawnedBossWavesRef = useRef<Set<number>>(new Set());
  const openedShopWavesRef = useRef<Set<number>>(new Set());
  const frameRef = useRef<number | null>(null);
  const runningRef = useRef(false);
  const lastEnemySpawnRef = useRef(0);

  const stopFrame = useCallback(() => {
    runningRef.current = false;
    if (frameRef.current !== null) {
      cancelAnimationFrame(frameRef.current);
      frameRef.current = null;
    }
  }, []);

  const toggleWeapon = useCallback(() => {
    setGameState((prev) => ({
      ...prev,
      weapon: prev.weapon === 'ranged' ? 'sword' : 'ranged',
      notice: prev.weapon === 'ranged' ? 'Sword drawn' : 'Silver pistol ready',
    }));
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      keysRef.current[key] = true;
      if (key === ' ' || key === 'shift') {
        e.preventDefault();
        dashRequestedRef.current = true;
      }
      if (key === 'q' || key === 'e') {
        burstRequestedRef.current = true;
      }
      if (key === 'tab' || key === 'f' || key === '1' || key === '2') {
        e.preventDefault();
        weaponToggleRequestedRef.current = true;
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => { keysRef.current[e.key.toLowerCase()] = false; };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const startGame = useCallback(() => {
    stopFrame();
    mouseRef.current = { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 };
    isMouseDownRef.current = false;
    touchMovementRef.current = { x: 0, y: 0 };
    lastShootTimeRef.current = 0;
    lastSwordTimeRef.current = 0;
    lastDamageTimeRef.current = 0;
    lastDashTimeRef.current = -DASH_COOLDOWN;
    lastBurstTimeRef.current = -BURST_COOLDOWN;
    shieldUntilRef.current = 0;
    holyPulseUntilRef.current = 0;
    swordSlashUntilRef.current = 0;
    dashRequestedRef.current = false;
    burstRequestedRef.current = false;
    weaponToggleRequestedRef.current = false;
    spawnedBossWavesRef.current = new Set();
    openedShopWavesRef.current = new Set();
    lastEnemySpawnRef.current = performance.now() - 1200;
    keysRef.current = {};
    runningRef.current = true;
    setGameState({ ...createInitialState(), status: 'playing' });
  }, [stopFrame]);

  const continueFromShop = useCallback(() => {
    lastEnemySpawnRef.current = performance.now();
    runningRef.current = true;
    setGameState((prev) => ({ ...prev, status: 'playing', notice: 'The hunt continues' }));
  }, []);

  const buyUpgrade = useCallback((id: UpgradeId) => {
    setGameState((prev) => {
      if (prev.status !== 'shop') return prev;
      const currentLevel = prev.upgrades[id];
      const upgrade = SHOP_UPGRADES[id];
      const cost = getUpgradeCost(id, currentLevel);
      if (currentLevel >= upgrade.max) return { ...prev, notice: `${upgrade.label} is maxed` };
      if (prev.money < cost) return { ...prev, notice: `Need ${cost - prev.money} more coins` };
      const nextUpgrades = { ...prev.upgrades, [id]: currentLevel + 1 };
      const healthGain = id === 'vitality' ? 12 : 0;
      const nextMaxHealth = 100 + nextUpgrades.vitality * 12;
      const nextSpeed = PLAYER_SPEED + nextUpgrades.speed * 0.35;
      return {
        ...prev,
        money: prev.money - cost,
        upgrades: nextUpgrades,
        player: {
          ...prev.player,
          maxHealth: nextMaxHealth,
          health: Math.min(nextMaxHealth, prev.player.health + healthGain),
          speed: nextSpeed,
        },
        notice: `${upgrade.label} upgraded`,
      };
    });
  }, []);

  const setTouchMovement = useCallback((movement: Velocity) => {
    touchMovementRef.current = movement;
  }, []);

  const setAimPosition = useCallback((position: Position) => {
    mouseRef.current = position;
  }, []);

  const setFiring = useCallback((isFiring: boolean) => {
    isMouseDownRef.current = isFiring;
  }, []);

  const activateDash = useCallback(() => {
    dashRequestedRef.current = true;
  }, []);

  const activateHolyBurst = useCallback(() => {
    burstRequestedRef.current = true;
  }, []);

  const switchWeapon = useCallback(() => {
    toggleWeapon();
  }, [toggleWeapon]);

  const update = useCallback((time: number) => {
    setGameState((prev) => {
      if (!runningRef.current || prev.status !== 'playing') {
        runningRef.current = false;
        return prev;
      }

      if (weaponToggleRequestedRef.current) {
        weaponToggleRequestedRef.current = false;
        return {
          ...prev,
          weapon: prev.weapon === 'ranged' ? 'sword' : 'ranged',
          notice: prev.weapon === 'ranged' ? 'Sword drawn' : 'Silver pistol ready',
        };
      }

      let dx = touchMovementRef.current.x;
      let dy = touchMovementRef.current.y;

      if (keysRef.current['w'] || keysRef.current['arrowup']) dy -= 1;
      if (keysRef.current['s'] || keysRef.current['arrowdown']) dy += 1;
      if (keysRef.current['a'] || keysRef.current['arrowleft']) dx -= 1;
      if (keysRef.current['d'] || keysRef.current['arrowright']) dx += 1;

      if (dx !== 0 || dy !== 0) {
        const length = Math.sqrt(dx * dx + dy * dy);
        dx /= length;
        dy /= length;
      }

      let nextPlayerPos = {
        x: Math.max(24, Math.min(GAME_WIDTH - 24, prev.player.pos.x + dx * prev.player.speed)),
        y: Math.max(24, Math.min(GAME_HEIGHT - 24, prev.player.pos.y + dy * prev.player.speed))
      };

      if (dashRequestedRef.current && time - lastDashTimeRef.current >= DASH_COOLDOWN) {
        let dashX = dx;
        let dashY = dy;
        if (dashX === 0 && dashY === 0) {
          dashX = mouseRef.current.x - nextPlayerPos.x;
          dashY = mouseRef.current.y - nextPlayerPos.y;
          const dashLen = Math.sqrt(dashX * dashX + dashY * dashY) || 1;
          dashX /= dashLen;
          dashY /= dashLen;
        }
        const dashDistance = DASH_DISTANCE + prev.upgrades.speed * 18;
        nextPlayerPos = {
          x: Math.max(24, Math.min(GAME_WIDTH - 24, nextPlayerPos.x + dashX * dashDistance)),
          y: Math.max(24, Math.min(GAME_HEIGHT - 24, nextPlayerPos.y + dashY * dashDistance))
        };
        lastDashTimeRef.current = time;
        shieldUntilRef.current = time + SHIELD_DURATION;
      }
      dashRequestedRef.current = false;

      let newBullets = [...prev.bullets];
      let newEnemies = [...prev.enemies];
      const gunDamage = 30 + prev.upgrades.gun * 7;
      const swordDamage = 72 + prev.upgrades.sword * 18;
      const swordRange = 82 + prev.upgrades.sword * 8;
      const shootCooldown = Math.max(95, SHOOT_COOLDOWN - prev.upgrades.gun * 10);

      if (isMouseDownRef.current && prev.weapon === 'ranged' && time - lastShootTimeRef.current > shootCooldown) {
        const mx = mouseRef.current.x;
        const my = mouseRef.current.y;
        let dirX = mx - nextPlayerPos.x;
        let dirY = my - nextPlayerPos.y;
        const dirLen = Math.sqrt(dirX * dirX + dirY * dirY);
        if (dirLen > 0) {
          dirX /= dirLen;
          dirY /= dirLen;
          newBullets.push({
            id: `${time}-${newBullets.length}`,
            pos: { ...nextPlayerPos },
            vel: { x: dirX * BULLET_SPEED, y: dirY * BULLET_SPEED },
            speed: BULLET_SPEED,
            radius: 5,
            damage: gunDamage,
          });
          lastShootTimeRef.current = time;
        }
      }

      if (isMouseDownRef.current && prev.weapon === 'sword' && time - lastSwordTimeRef.current > SWORD_COOLDOWN) {
        const mx = mouseRef.current.x;
        const my = mouseRef.current.y;
        let aimX = mx - nextPlayerPos.x;
        let aimY = my - nextPlayerPos.y;
        const aimLen = Math.sqrt(aimX * aimX + aimY * aimY) || 1;
        aimX /= aimLen;
        aimY /= aimLen;
        newEnemies = newEnemies.map(e => {
          const toEnemyX = e.pos.x - nextPlayerPos.x;
          const toEnemyY = e.pos.y - nextPlayerPos.y;
          const dist = Math.sqrt(toEnemyX * toEnemyX + toEnemyY * toEnemyY);
          if (dist > swordRange + e.radius) return e;
          const dot = dist > 0 ? ((toEnemyX / dist) * aimX + (toEnemyY / dist) * aimY) : 1;
          if (dot < 0.05) return e;
          const vulnerability = e.kind === 'wraith' ? 0.45 : e.kind === 'boss' ? 0.72 : 1;
          return { ...e, health: e.health - swordDamage * vulnerability };
        });
        lastSwordTimeRef.current = time;
        swordSlashUntilRef.current = time + 220;
      }

      newBullets = newBullets.map(b => ({
        ...b,
        pos: { x: b.pos.x + b.vel.x, y: b.pos.y + b.vel.y }
      })).filter(b => b.pos.x >= -20 && b.pos.x <= GAME_WIDTH + 20 && b.pos.y >= -20 && b.pos.y <= GAME_HEIGHT + 20);

      const hasBoss = newEnemies.some(enemy => enemy.kind === 'boss');
      if (prev.wave >= 3 && prev.wave % 3 === 0 && !hasBoss && !spawnedBossWavesRef.current.has(prev.wave)) {
        spawnedBossWavesRef.current.add(prev.wave);
        newEnemies.push({
          id: `${time}-boss-${prev.wave}`,
          kind: 'boss',
          name: 'Blood Moon Matriarch',
          pos: { x: GAME_WIDTH / 2, y: -70 },
          health: 520 + prev.wave * 80,
          maxHealth: 520 + prev.wave * 80,
          speed: 1.08 + prev.wave * 0.05,
          radius: 38,
        });
      }

      const bossPresent = newEnemies.some(enemy => enemy.kind === 'boss');
      const spawnRate = bossPresent ? Math.max(760, 2300 - prev.wave * 90) : Math.max(460, 1900 - prev.wave * 110);
      const enemyLimit = bossPresent ? 12 : 18;
      if (newEnemies.length < enemyLimit && time - lastEnemySpawnRef.current > spawnRate) {
        const side = Math.floor(Math.random() * 4);
        let ex, ey;
        if (side === 0) { ex = Math.random() * GAME_WIDTH; ey = -30; }
        else if (side === 1) { ex = GAME_WIDTH + 30; ey = Math.random() * GAME_HEIGHT; }
        else if (side === 2) { ex = Math.random() * GAME_WIDTH; ey = GAME_HEIGHT + 30; }
        else { ex = -30; ey = Math.random() * GAME_HEIGHT; }
        const shouldSpawnWraith = prev.wave >= 4 && Math.random() < Math.min(0.36, 0.12 + prev.wave * 0.015);
        const enemyHealth = shouldSpawnWraith ? 72 + prev.wave * 11 : 48 + prev.wave * 9;
        newEnemies.push({
          id: `${time}-enemy-${newEnemies.length}`,
          kind: shouldSpawnWraith ? 'wraith' : 'vampire',
          name: shouldSpawnWraith ? 'Grave Wraith' : undefined,
          pos: { x: ex, y: ey },
          health: enemyHealth,
          maxHealth: enemyHealth,
          speed: shouldSpawnWraith ? ENEMY_SPEED_BASE + prev.wave * 0.13 : ENEMY_SPEED_BASE + prev.wave * 0.18,
          radius: shouldSpawnWraith ? 17 : 14,
        });
        lastEnemySpawnRef.current = time;
      }

      let newScore = prev.score;
      let newHealth = prev.player.health;
      let newMoney = prev.money;
      let touchingPlayer = false;

      if (burstRequestedRef.current && time - lastBurstTimeRef.current >= BURST_COOLDOWN) {
        newEnemies = newEnemies.map(e => {
          const dist = Math.sqrt(Math.pow(nextPlayerPos.x - e.pos.x, 2) + Math.pow(nextPlayerPos.y - e.pos.y, 2));
          if (dist > BURST_RADIUS) return e;
          const push = Math.max(0, (BURST_RADIUS - dist) / BURST_RADIUS);
          const pushX = dist > 0 ? (e.pos.x - nextPlayerPos.x) / dist : 0;
          const pushY = dist > 0 ? (e.pos.y - nextPlayerPos.y) / dist : -1;
          const vulnerability = e.kind === 'wraith' ? 0.65 : e.kind === 'boss' ? 0.6 : 1;
          return {
            ...e,
            health: e.health - BURST_DAMAGE * vulnerability,
            pos: {
              x: Math.max(20, Math.min(GAME_WIDTH - 20, e.pos.x + pushX * push * 90)),
              y: Math.max(20, Math.min(GAME_HEIGHT - 20, e.pos.y + pushY * push * 90)),
            }
          };
        });
        lastBurstTimeRef.current = time;
        shieldUntilRef.current = Math.max(shieldUntilRef.current, time + 1100);
        holyPulseUntilRef.current = time + 460;
        newHealth = Math.min(prev.player.maxHealth, newHealth + 10 + prev.upgrades.vitality * 2);
      }
      burstRequestedRef.current = false;

      newEnemies = newEnemies.map(e => {
        let dirX = nextPlayerPos.x - e.pos.x;
        let dirY = nextPlayerPos.y - e.pos.y;
        const dirLen = Math.sqrt(dirX * dirX + dirY * dirY);
        let nexPos = { ...e.pos };
        if (dirLen > 0) {
          const movementSpeed = e.kind === 'wraith' ? e.speed * 0.78 : e.speed;
          nexPos.x += (dirX / dirLen) * movementSpeed;
          nexPos.y += (dirY / dirLen) * movementSpeed;
        }

        if (dirLen < e.radius + prev.player.radius + 2) {
          touchingPlayer = true;
        }

        return { ...e, pos: nexPos };
      });

      if (touchingPlayer && time > shieldUntilRef.current && time - lastDamageTimeRef.current > DAMAGE_COOLDOWN) {
        newHealth -= bossPresent ? 10 : 8;
        lastDamageTimeRef.current = time;
      }

      newBullets = newBullets.filter(b => {
        let hit = false;
        newEnemies = newEnemies.map(e => {
          if (hit) return e;
          const dist = Math.sqrt(Math.pow(b.pos.x - e.pos.x, 2) + Math.pow(b.pos.y - e.pos.y, 2));
          if (dist < b.radius + e.radius) {
            hit = true;
            const vulnerability = e.kind === 'wraith' ? 1.85 : 1;
            return { ...e, health: e.health - b.damage * vulnerability };
          }
          return e;
        });
        return !hit;
      });

      const defeatedEnemies = newEnemies.filter(e => e.health <= 0);
      newEnemies = newEnemies.filter(e => e.health > 0);
      if (defeatedEnemies.length > 0) {
        newScore += defeatedEnemies.reduce((total, enemy) => total + (enemy.kind === 'boss' ? BOSS_SCORE : enemy.kind === 'wraith' ? WRAITH_SCORE : SCORE_PER_KILL), 0);
        newMoney += defeatedEnemies.reduce((total, enemy) => total + (enemy.kind === 'boss' ? 130 : enemy.kind === 'wraith' ? 28 : 18), 0);
        newHealth = Math.min(prev.player.maxHealth, newHealth + defeatedEnemies.reduce((total, enemy) => total + (enemy.kind === 'boss' ? 22 : 2), 0));
      }

      const newWave = Math.max(1, 1 + Math.floor(newScore / SCORE_PER_WAVE));
      let status: GameState['status'] = prev.status;
      let nextNotice = prev.notice;
      let shopWave = prev.shopWave;
      if (newWave > 1 && newWave % 10 === 0 && !openedShopWavesRef.current.has(newWave)) {
        openedShopWavesRef.current.add(newWave);
        status = 'shop';
        shopWave = newWave;
        nextNotice = 'The lantern shop opens';
        runningRef.current = false;
        isMouseDownRef.current = false;
        touchMovementRef.current = { x: 0, y: 0 };
      }

      if (newHealth <= 0) {
        status = 'gameover';
        runningRef.current = false;
        isMouseDownRef.current = false;
        touchMovementRef.current = { x: 0, y: 0 };
      }

      const boss = newEnemies.find(enemy => enemy.kind === 'boss');
      const dashCooldown = Math.max(0, DASH_COOLDOWN - (time - lastDashTimeRef.current));
      const burstCooldown = Math.max(0, BURST_COOLDOWN - (time - lastBurstTimeRef.current));
      const nextMaxHealth = 100 + prev.upgrades.vitality * 12;
      const nextSpeed = PLAYER_SPEED + prev.upgrades.speed * 0.35;

      return {
        ...prev,
        status,
        score: newScore,
        wave: newWave,
        money: newMoney,
        shopWave,
        notice: nextNotice,
        player: { ...prev.player, pos: nextPlayerPos, health: Math.min(newHealth, nextMaxHealth), maxHealth: nextMaxHealth, speed: nextSpeed },
        bullets: newBullets,
        enemies: newEnemies,
        abilities: {
          dashCooldown,
          burstCooldown,
          shieldActive: time < shieldUntilRef.current,
          holyPulse: Math.max(0, Math.min(1, (holyPulseUntilRef.current - time) / 460)),
          swordSlash: Math.max(0, Math.min(1, (swordSlashUntilRef.current - time) / 220)),
        },
        bossMessage: boss ? `${boss.name} has entered the woods` : '',
      };
    });

    if (runningRef.current) {
      frameRef.current = requestAnimationFrame(update);
    } else {
      frameRef.current = null;
    }
  }, []);

  useEffect(() => {
    if (gameState.status === 'playing' && runningRef.current && frameRef.current === null) {
      frameRef.current = requestAnimationFrame(update);
    }
    if (gameState.status !== 'playing') {
      runningRef.current = false;
    }
    return () => {
      if (frameRef.current !== null) {
        cancelAnimationFrame(frameRef.current);
        frameRef.current = null;
      }
    };
  }, [gameState.status, update]);

  return {
    gameState,
    startGame,
    continueFromShop,
    buyUpgrade,
    mouseRef,
    isMouseDownRef,
    setTouchMovement,
    setAimPosition,
    setFiring,
    activateDash,
    activateHolyBurst,
    switchWeapon,
    GAME_WIDTH,
    GAME_HEIGHT
  };
}
