import React, { useState } from 'react';
import { CHARACTERS, DIFFICULTIES } from '@/data/characters';
import type { CharacterId, DifficultyId } from '@/data/characters';
import {
  OPENING_ACT, CHAR_INTRO, FOREST_ACT, POST_MANSION_ACT, PRE_CHURCH_ACT, CHAR_POST_MANSION,
} from '@/data/story';
import type { StoryAct } from '@/data/story';
import { MANSION_ENDINGS, CHURCH_ENDINGS } from '@/data/endings';
import StoryScene from '@/pages/StoryScene';
import MansionGame from '@/pages/MansionGame';
import ChurchGame from '@/pages/ChurchGame';

type Phase =
  | 'opening'
  | 'char_select'
  | 'char_intro'
  | 'forest_scene'
  | 'mansion'
  | 'post_mansion'
  | 'pre_church'
  | 'church'
  | 'ending';

function buildPostMansionAct(charId: CharacterId): StoryAct {
  const shared = POST_MANSION_ACT;
  const charLine = CHAR_POST_MANSION[charId];
  return [
    ...shared,
    { speaker: CHARACTERS.find(c => c.id === charId)?.name.toUpperCase(), text: charLine },
  ];
}

export default function StoryMode({ onBack }: { onBack: () => void }) {
  const [phase, setPhase] = useState<Phase>('opening');
  const [selectedChar, setSelectedChar] = useState<CharacterId>('hunter');
  const [selectedDiff, setSelectedDiff] = useState<DifficultyId>('normal');

  const char = CHARACTERS.find(c => c.id === selectedChar)!;
  const churchEnding = CHURCH_ENDINGS[selectedChar];

  function advance(next: Phase) {
    setPhase(next);
  }

  if (phase === 'opening') {
    return (
      <StoryScene
        act={OPENING_ACT}
        bg="hellsing"
        accentColor="#dc2626"
        onComplete={() => advance('char_select')}
        onBack={onBack}
      />
    );
  }

  if (phase === 'char_select') {
    return (
      <div
        className="absolute inset-0 flex flex-col items-center justify-center z-50 px-4"
        style={{ background: 'radial-gradient(ellipse at 50% 120%, #0c0c10 0%, #040408 100%)' }}
      >
        <button
          onClick={onBack}
          className="absolute top-5 left-5 font-mono text-xs text-white/30 uppercase tracking-widest hover:text-white/60 transition-colors z-20"
        >
          ← Exit Story
        </button>

        <div className="font-mono text-xs text-red-400/70 uppercase tracking-[0.35em] mb-2">
          ── Hellsing Operative Assignment ──
        </div>
        <h2 className="font-serif text-amber-200 text-2xl italic tracking-widest mb-1">Choose Your Agent</h2>
        <p className="font-mono text-amber-400/45 text-xs mb-5 uppercase tracking-widest">Each operative has a unique perspective on the events</p>

        <div className="char-select-grid">
          {CHARACTERS.map(c => (
            <button
              key={c.id}
              onClick={() => setSelectedChar(c.id)}
              className={`char-card ${c.bgClass} ${selectedChar === c.id ? 'char-card-selected' : ''}`}
              style={{ borderColor: selectedChar === c.id ? c.color : 'rgba(255,255,255,0.12)' }}
            >
              <div className="char-icon">{c.icon}</div>
              <div className="char-name" style={{ color: c.color }}>{c.name}</div>
              <div className="char-subtitle">{c.subtitle}</div>
              <div className="char-weapon-tag">⚔ {c.weapon.replace('_', ' ')}</div>
              <div className="char-trait-preview">{c.trait.slice(0, 55)}{c.trait.length > 55 ? '…' : ''}</div>
            </button>
          ))}
        </div>

        <div className="char-detail-row mt-3">
          <div className="font-mono text-xs" style={{ color: char.accentColor }}>
            HP {char.stats.maxHealth} · SPD ×{char.stats.speed} · REGEN {char.stats.regen}/s
          </div>
          <div className="font-mono text-xs text-white/35 mt-1 italic">{char.flavor}</div>
        </div>

        <div className="mt-5 flex flex-col items-center gap-3">
          <div className="font-mono text-xs text-amber-400/50 uppercase tracking-widest mb-1">Mission Difficulty</div>
          <div className="diff-select-row">
            {DIFFICULTIES.map(d => (
              <button
                key={d.id}
                onClick={() => setSelectedDiff(d.id)}
                className={`diff-card diff-card-${d.id} ${selectedDiff === d.id ? 'diff-card-selected' : ''}`}
              >
                <div className="diff-icon">{d.icon}</div>
                <div className="diff-name">{d.name}</div>
                <div className="diff-score-mult">×{d.scoreMultiplier}</div>
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={() => advance('char_intro')}
          className="game-button mt-5 bg-red-900/30 border border-red-400/60 text-red-100 font-mono text-sm px-8 py-2 hover:bg-red-800/50 transition-all uppercase tracking-widest"
        >
          Begin the Story →
        </button>
      </div>
    );
  }

  if (phase === 'char_intro') {
    return (
      <StoryScene
        act={CHAR_INTRO[selectedChar]}
        bg="hellsing"
        accentColor={char.color}
        onComplete={() => advance('forest_scene')}
        onBack={onBack}
      />
    );
  }

  if (phase === 'forest_scene') {
    return (
      <StoryScene
        act={FOREST_ACT}
        bg="forest"
        accentColor="#22c55e"
        onComplete={() => advance('mansion')}
        onBack={onBack}
      />
    );
  }

  if (phase === 'mansion') {
    return (
      <div className="absolute inset-0 z-50">
        <div
          className="absolute top-0 inset-x-0 z-50 flex items-center justify-center py-2 pointer-events-none"
          style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.72) 0%, transparent 100%)' }}
        >
          <span className="font-mono text-xs text-purple-300/60 uppercase tracking-[0.3em]">
            ── Story Mode · Act II: The Vladros Estate ──
          </span>
        </div>
        <MansionGame
          characterId={selectedChar}
          difficultyId={selectedDiff}
          onBack={() => advance('post_mansion')}
        />
      </div>
    );
  }

  if (phase === 'post_mansion') {
    return (
      <StoryScene
        act={buildPostMansionAct(selectedChar)}
        bg="mansion"
        accentColor={char.color}
        onComplete={() => advance('pre_church')}
        onBack={onBack}
      />
    );
  }

  if (phase === 'pre_church') {
    return (
      <StoryScene
        act={PRE_CHURCH_ACT}
        bg="church"
        accentColor="#fcd34d"
        onComplete={() => advance('church')}
        onBack={onBack}
      />
    );
  }

  if (phase === 'church') {
    return (
      <div className="absolute inset-0 z-50">
        <div
          className="absolute top-0 inset-x-0 z-50 flex items-center justify-center py-2 pointer-events-none"
          style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.72) 0%, transparent 100%)' }}
        >
          <span className="font-mono text-xs text-yellow-300/55 uppercase tracking-[0.3em]">
            ── Story Mode · Act III: The Light Church ──
          </span>
        </div>
        <ChurchGame
          characterId={selectedChar}
          difficultyId={selectedDiff}
          onBack={() => advance('ending')}
        />
      </div>
    );
  }

  if (phase === 'ending') {
    return (
      <div
        className="absolute inset-0 flex flex-col items-center justify-center z-50 px-6 text-center"
        style={{ background: 'radial-gradient(ellipse at 50% 0%, #12060a 0%, #020204 100%)' }}
      >
        <div className="font-mono text-xs text-amber-500/60 uppercase tracking-[0.4em] mb-4">
          ── Epilogue ──
        </div>
        <div className="font-mono text-xs uppercase tracking-[0.3em] mb-2" style={{ color: char.color }}>
          {char.icon}  {char.name}
        </div>
        <h2 className="font-serif text-3xl italic text-amber-100 mb-2 tracking-widest">
          {churchEnding.title}
        </h2>
        <p className="font-mono text-sm text-amber-400/55 mb-8 uppercase tracking-widest">
          {churchEnding.subtitle}
        </p>
        <div className="max-w-lg flex flex-col gap-4 mb-10">
          {churchEnding.lines.map((line, i) => (
            <p key={i} className="font-serif text-lg text-amber-100/85 leading-relaxed">
              {line}
            </p>
          ))}
        </div>
        <div className="flex gap-4">
          <button
            onClick={() => { setPhase('opening'); setSelectedChar('hunter'); setSelectedDiff('normal'); }}
            className="game-button bg-amber-500/10 border border-amber-400/50 text-amber-200 font-mono text-sm px-6 py-2 hover:bg-amber-500/20 transition-all uppercase tracking-widest"
          >
            New Story
          </button>
          <button
            onClick={onBack}
            className="game-button border border-white/20 text-white/50 font-mono text-sm px-6 py-2 hover:border-white/40 hover:text-white/70 transition-all uppercase tracking-widest"
          >
            ← Main Menu
          </button>
        </div>
      </div>
    );
  }

  return null;
}
