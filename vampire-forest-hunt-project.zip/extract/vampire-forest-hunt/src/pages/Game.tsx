import React, { useEffect, useRef, useState } from 'react';
import { getUpgradeCost, SHOP_UPGRADES, useGameLoop } from '@/hooks/useGameLoop';
import MansionGame from '@/pages/MansionGame';
import ChurchGame from '@/pages/ChurchGame';
import StoryMode from '@/pages/StoryMode';
import { CHARACTERS, DIFFICULTIES } from '@/data/characters';
import type { CharacterId, DifficultyId } from '@/data/characters';

type PointerPoint = { x: number; y: number };

const trees = [
  { x: 70, y: 86, h: 210, w: 18, o: 0.55 },
  { x: 150, y: 310, h: 260, w: 24, o: 0.45 },
  { x: 246, y: 58, h: 180, w: 16, o: 0.35 },
  { x: 320, y: 542, h: 220, w: 20, o: 0.38 },
  { x: 440, y: 150, h: 260, w: 22, o: 0.32 },
  { x: 575, y: 610, h: 170, w: 15, o: 0.42 },
  { x: 705, y: 78, h: 250, w: 21, o: 0.34 },
  { x: 835, y: 405, h: 285, w: 25, o: 0.46 },
  { x: 980, y: 122, h: 230, w: 18, o: 0.4 },
  { x: 1100, y: 520, h: 245, w: 20, o: 0.5 },
  { x: 1160, y: 190, h: 190, w: 16, o: 0.36 },
  { x: 40, y: 650, h: 160, w: 14, o: 0.4 },
];

const lanterns = [
  { x: 190, y: 185, s: 1 },
  { x: 625, y: 160, s: 1.22 },
  { x: 1010, y: 275, s: 0.92 },
  { x: 370, y: 660, s: 0.82 },
  { x: 880, y: 620, s: 1.05 },
];

const fireflies = [
  { x: 128, y: 116, d: 0 },
  { x: 292, y: 250, d: 0.7 },
  { x: 520, y: 102, d: 1.1 },
  { x: 760, y: 212, d: 1.8 },
  { x: 1090, y: 150, d: 0.35 },
  { x: 980, y: 520, d: 1.45 },
  { x: 645, y: 690, d: 0.2 },
  { x: 222, y: 612, d: 1.25 },
  { x: 1115, y: 705, d: 0.95 },
  { x: 456, y: 430, d: 1.65 },
];

export default function Game() {
  const containerRef = useRef<HTMLDivElement>(null);
  const movementPointerIdRef = useRef<number | null>(null);
  const firePointerIdRef = useRef<number | null>(null);
  const movementOriginRef = useRef<PointerPoint>({ x: 0, y: 0 });
  const [worldScale, setWorldScale] = useState({ x: 1, y: 1 });
  const [gameMode, setGameMode] = useState<'select' | 'char_select' | 'diff_select' | 'forest' | 'mansion' | 'church' | 'story'>('select');
  const [pendingMode, setPendingMode] = useState<'forest' | 'mansion' | 'church'>('forest');
  const [selectedChar, setSelectedChar] = useState<CharacterId>('hunter');
  const [selectedDiff, setSelectedDiff] = useState<DifficultyId>('normal');
  const { gameState, startGame, continueFromShop, buyUpgrade, setTouchMovement, setAimPosition, setFiring, activateDash, activateHolyBurst, switchWeapon, GAME_WIDTH, GAME_HEIGHT } = useGameLoop();

  useEffect(() => {
    const updateScale = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      setWorldScale({ x: rect.width / GAME_WIDTH, y: rect.height / GAME_HEIGHT });
    };

    updateScale();
    const observer = new ResizeObserver(updateScale);
    if (containerRef.current) observer.observe(containerRef.current);
    window.addEventListener('orientationchange', updateScale);
    window.addEventListener('resize', updateScale);

    return () => {
      observer.disconnect();
      window.removeEventListener('orientationchange', updateScale);
      window.removeEventListener('resize', updateScale);
    };
  }, [GAME_WIDTH, GAME_HEIGHT]);

  const getScaledPoint = (clientX: number, clientY: number) => {
    if (!containerRef.current) return null;
    const rect = containerRef.current.getBoundingClientRect();
    const scaleX = GAME_WIDTH / rect.width;
    const scaleY = GAME_HEIGHT / rect.height;
    return {
      screen: { x: clientX - rect.left, y: clientY - rect.top },
      world: {
        x: (clientX - rect.left) * scaleX,
        y: (clientY - rect.top) * scaleY
      },
      rect
    };
  };

  const updateMovement = (clientX: number, clientY: number) => {
    const dx = clientX - movementOriginRef.current.x;
    const dy = clientY - movementOriginRef.current.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const maxDistance = 56;
    if (distance < 6) {
      setTouchMovement({ x: 0, y: 0 });
      return;
    }
    const strength = Math.min(1, distance / maxDistance);
    setTouchMovement({ x: (dx / distance) * strength, y: (dy / distance) * strength });
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (gameState.status !== 'playing') return;
    const point = getScaledPoint(e.clientX, e.clientY);
    if (!point) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);

    if (e.pointerType !== 'mouse' && point.screen.x < point.rect.width * 0.48) {
      movementPointerIdRef.current = e.pointerId;
      movementOriginRef.current = { x: e.clientX, y: e.clientY };
      updateMovement(e.clientX, e.clientY);
      return;
    }

    firePointerIdRef.current = e.pointerId;
    setAimPosition(point.world);
    setFiring(true);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const point = getScaledPoint(e.clientX, e.clientY);
    if (!point) return;

    if (e.pointerType === 'mouse') {
      setAimPosition(point.world);
      return;
    }

    if (movementPointerIdRef.current === e.pointerId) {
      e.preventDefault();
      updateMovement(e.clientX, e.clientY);
      return;
    }

    if (firePointerIdRef.current === e.pointerId) {
      e.preventDefault();
      setAimPosition(point.world);
    }
  };

  const releasePointer = (pointerId: number) => {
    if (movementPointerIdRef.current === pointerId) {
      movementPointerIdRef.current = null;
      setTouchMovement({ x: 0, y: 0 });
    }
    if (firePointerIdRef.current === pointerId) {
      firePointerIdRef.current = null;
      setFiring(false);
    }
  };

  const aimX = gameState.player.pos.x;
  const aimY = gameState.player.pos.y;
  const waveProgressPercent = Math.min(100, Math.max(0, (gameState.score % 1000) / 10));
  const boss = gameState.enemies.find(enemy => enemy.kind === 'boss');
  const dashReady = gameState.abilities.dashCooldown <= 0;
  const burstReady = gameState.abilities.burstCooldown <= 0;
  const dashLabel = dashReady ? 'READY' : `${Math.ceil(gameState.abilities.dashCooldown / 1000)}s`;
  const burstLabel = burstReady ? 'READY' : `${Math.ceil(gameState.abilities.burstCooldown / 1000)}s`;
  const upgradeEntries = Object.entries(SHOP_UPGRADES) as Array<[keyof typeof SHOP_UPGRADES, (typeof SHOP_UPGRADES)[keyof typeof SHOP_UPGRADES]]>;

  const triggerAbility = (e: React.PointerEvent<HTMLButtonElement>, ability: 'dash' | 'burst') => {
    e.preventDefault();
    e.stopPropagation();
    if (ability === 'dash') activateDash();
    else activateHolyBurst();
  };

  const handleWeaponSwitch = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();
    switchWeapon();
  };

  if (gameMode === 'story') {
    return <StoryMode onBack={() => setGameMode('select')} />;
  }

  if (gameMode === 'mansion') {
    return <MansionGame onBack={() => setGameMode('select')} characterId={selectedChar} difficultyId={selectedDiff} />;
  }

  if (gameMode === 'church') {
    return <ChurchGame onBack={() => setGameMode('select')} characterId={selectedChar} difficultyId={selectedDiff} />;
  }

  return (
    <div className="game-shell relative bg-black flex items-center justify-center crt">
      <div
        ref={containerRef}
        className="game-stage relative overflow-hidden vignette select-none"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={(e) => releasePointer(e.pointerId)}
        onPointerCancel={(e) => releasePointer(e.pointerId)}
        onPointerLeave={(e) => {
          if (e.pointerType === 'mouse') setFiring(false);
        }}
      >
        <div
          className="game-world absolute left-0 top-0"
          style={{
            width: GAME_WIDTH,
            height: GAME_HEIGHT,
            transform: `scale(${worldScale.x}, ${worldScale.y})`
          }}
        >
          <div className="forest-sky absolute inset-0" />
          <div className="moonbeam absolute" />
          <div className="forest-floor absolute inset-0" />
          <div className="forest-mist mist-a absolute inset-0" />
          <div className="forest-mist mist-b absolute inset-0" />

          {lanterns.map((lantern) => (
            <div key={`${lantern.x}-${lantern.y}`} className="lantern-light absolute" style={{ left: lantern.x, top: lantern.y, transform: `translate(-50%, -50%) scale(${lantern.s})` }}>
              <div className="lantern-core" />
            </div>
          ))}

          {trees.map((tree) => (
            <div key={`${tree.x}-${tree.y}`} className="forest-tree absolute" style={{ left: tree.x, top: tree.y, height: tree.h, width: tree.w, opacity: tree.o }} />
          ))}

          {fireflies.map((firefly) => (
            <div key={`${firefly.x}-${firefly.y}`} className="firefly absolute" style={{ left: firefly.x, top: firefly.y, animationDelay: `${firefly.d}s` }} />
          ))}

          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle at center, rgba(255,35,35,.9) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
          <div className="absolute inset-0 opacity-25" style={{ backgroundImage: 'linear-gradient(90deg, transparent 0 18px, rgba(140,20,20,.18) 19px 20px), linear-gradient(transparent 0 18px, rgba(140,20,20,.14) 19px 20px)', backgroundSize: '80px 80px' }} />

          {gameState.status === 'playing' && (
            <>
              <div
                className="aim-aura absolute rounded-full pointer-events-none"
                style={{
                  left: aimX,
                  top: aimY,
                }}
              />

              <div
                className={`hunter absolute rounded-full transform -translate-x-1/2 -translate-y-1/2 transition-transform duration-75 ${gameState.abilities.shieldActive ? 'hunter-shielded' : ''}`}
                style={{
                  left: gameState.player.pos.x,
                  top: gameState.player.pos.y,
                  width: gameState.player.radius * 2,
                  height: gameState.player.radius * 2
                }}
              />

              {gameState.abilities.shieldActive && (
                <div
                  className="shield-ring absolute rounded-full pointer-events-none"
                  style={{
                    left: gameState.player.pos.x,
                    top: gameState.player.pos.y,
                  }}
                />
              )}

              {gameState.abilities.holyPulse > 0 && (
                <div
                  className="holy-pulse absolute rounded-full pointer-events-none"
                  style={{
                    left: gameState.player.pos.x,
                    top: gameState.player.pos.y,
                    opacity: gameState.abilities.holyPulse,
                    transform: `translate(-50%, -50%) scale(${1.3 - gameState.abilities.holyPulse * 0.3})`
                  }}
                />
              )}

              {gameState.abilities.swordSlash > 0 && (
                <div
                  className="sword-slash absolute pointer-events-none"
                  style={{
                    left: gameState.player.pos.x,
                    top: gameState.player.pos.y,
                    opacity: gameState.abilities.swordSlash,
                  }}
                />
              )}

              {gameState.bullets.map(b => (
                <div
                  key={b.id}
                  className="silver-bullet absolute rounded-full transform -translate-x-1/2 -translate-y-1/2"
                  style={{
                    left: b.pos.x,
                    top: b.pos.y,
                    width: b.radius * 2,
                    height: b.radius * 2
                  }}
                />
              ))}

              {gameState.enemies.map(e => (
                <div
                  key={e.id}
                  className={`${e.kind === 'boss' ? 'boss-vampire' : e.kind === 'wraith' ? 'wraith' : 'vampire'} absolute transform -translate-x-1/2 -translate-y-1/2`}
                  style={{
                    left: e.pos.x,
                    top: e.pos.y,
                    width: e.radius * 2,
                    height: e.radius * 2,
                  }}
                >
                  <div className="vampire-body" />
                  <div className="vampire-health">
                    <div style={{ width: `${Math.max(0, (e.health / e.maxHealth) * 100)}%` }} />
                  </div>
                  {e.kind === 'boss' && <div className="boss-crown" />}
                  {e.kind === 'wraith' && <div className="wraith-mark">RANGED</div>}
                </div>
              ))}
            </>
          )}
        </div>

        {gameState.status === 'playing' && (
          <>
            <div className="game-hud-score absolute text-white font-mono z-10">
              <div className="score-label mb-1 text-red-300 font-serif italic">SCORE: {gameState.score.toString().padStart(6, '0')}</div>
              <div className="wave-label text-amber-200/90">WAVE {gameState.wave}</div>
              <div className="coin-label mt-1">COINS: {gameState.money}</div>
              <div className="weapon-label mt-1">WEAPON: {gameState.weapon === 'ranged' ? 'RANGED' : 'SWORD'}</div>
              <div className="wave-progress mt-2">
                <div style={{ width: `${waveProgressPercent}%` }} />
              </div>
              <div className="next-wave-label mt-1">NEXT WAVE</div>
            </div>

            <div className="game-hud-health absolute z-10">
              <div className="text-xs text-amber-200 mb-1 text-right">BLOOD</div>
              <div className="h-2 w-full bg-red-950/90 border border-amber-400/40 shadow-[0_0_18px_rgba(255,180,70,.25)]">
                <div
                  className="h-full bg-gradient-to-r from-red-700 via-red-500 to-amber-300 transition-all duration-200"
                  style={{ width: `${Math.max(0, (gameState.player.health / gameState.player.maxHealth) * 100)}%` }}
                />
              </div>
            </div>

            {boss && (
              <div className="boss-hud absolute z-10 text-center font-mono">
                <div className="boss-name">{boss.name}</div>
                <div className="boss-bar">
                  <div style={{ width: `${Math.max(0, (boss.health / boss.maxHealth) * 100)}%` }} />
                </div>
                <div className="boss-warning">{gameState.bossMessage}</div>
              </div>
            )}

            <div className="ability-panel absolute z-10 font-mono">
              <button
                type="button"
                className={`ability-button weapon-switch ${gameState.weapon === 'sword' ? 'sword-active' : 'ready'}`}
                onPointerDown={handleWeaponSwitch}
              >
                <span>SWITCH</span>
                <strong>{gameState.weapon === 'ranged' ? 'GUN' : 'SWORD'}</strong>
              </button>
              <button
                type="button"
                className={`ability-button ${dashReady ? 'ready' : 'cooling'}`}
                onPointerDown={(e) => triggerAbility(e, 'dash')}
              >
                <span>DASH</span>
                <strong>{dashLabel}</strong>
              </button>
              <button
                type="button"
                className={`ability-button ${burstReady ? 'ready' : 'cooling'}`}
                onPointerDown={(e) => triggerAbility(e, 'burst')}
              >
                <span>HOLY BURST</span>
                <strong>{burstLabel}</strong>
              </button>
            </div>

            <div className="touch-help pointer-events-none absolute inset-x-0 bottom-3 z-10 flex justify-between px-4 text-[10px] uppercase tracking-[0.25em] text-amber-100/75">
              <span>F/Tab switches weapon</span>
              <span>Wraiths fear ranged shots</span>
            </div>
          </>
        )}

        {gameState.status === 'shop' && (
          <div className="absolute inset-0 bg-black/82 flex flex-col items-center justify-center z-30 px-5 text-center menu-glow">
            <div className="shop-panel">
              <div className="shop-kicker">WAVE {gameState.shopWave} LANTERN SHOP</div>
              <h2 className="shop-title font-serif italic">Spend Vampire Coins</h2>
              <div className="shop-money">COINS: {gameState.money}</div>
              {gameState.notice && <div className="shop-notice">{gameState.notice}</div>}
              <div className="shop-grid">
                {upgradeEntries.map(([id, upgrade]) => {
                  const level = gameState.upgrades[id];
                  const maxed = level >= upgrade.max;
                  const cost = getUpgradeCost(id, level);
                  return (
                    <button
                      key={id}
                      type="button"
                      className={`shop-card ${maxed ? 'maxed' : gameState.money >= cost ? 'affordable' : 'locked'}`}
                      onClick={() => buyUpgrade(id)}
                    >
                      <span>{upgrade.label}</span>
                      <strong>{maxed ? 'MAX' : `${cost} COINS`}</strong>
                      <em>LV {level}/{upgrade.max}</em>
                      <small>{upgrade.description}</small>
                    </button>
                  );
                })}
              </div>
              <button
                onClick={continueFromShop}
                className="game-button mt-5 bg-amber-500/10 border border-amber-300/60 text-amber-100 font-mono hover:bg-red-900/50 hover:text-white transition-all hover:scale-105 uppercase tracking-widest shadow-[0_0_28px_rgba(255,170,70,.25)]"
              >
                Return to Hunt
              </button>
            </div>
          </div>
        )}

        {/* ── MODE SELECT ── */}
        {(gameState.status === 'menu' || gameMode === 'select') && (
          <div className="absolute inset-0 bg-black/58 flex flex-col items-center justify-center z-20 px-5 text-center menu-glow">
            <h1 className="game-title font-serif text-red-500 mb-1 italic tracking-widest" style={{ textShadow: '0 0 28px rgba(255,40,20,0.7), 0 0 80px rgba(255,180,80,.25)' }}>
              VAMPIRE<br/>HUNT
            </h1>
            <p className="game-subtitle text-amber-100/65 font-mono mb-5 max-w-sm uppercase tracking-widest">
              Choose your hunting ground
            </p>
            <div className="mode-select-panel">
              <button onClick={() => setGameMode('story')} className="mode-card text-left" style={{ borderColor: 'rgba(220,38,38,0.55)', background: 'rgba(80,10,10,0.45)' }}>
                <span className="mode-card-icon">📖</span>
                <div>
                  <div className="mode-card-title" style={{ color: '#f87171' }}>Story Mode</div>
                  <div className="mode-card-desc" style={{ color: 'rgba(252,165,165,0.62)' }}>Full narrative · all three acts · character-specific endings</div>
                </div>
              </button>
              <button onClick={() => { setPendingMode('forest'); setGameMode('char_select'); }} className="mode-card forest-card text-left">
                <span className="mode-card-icon">🌲</span>
                <div>
                  <div className="mode-card-title text-red-400">Forest Hunt</div>
                  <div className="mode-card-desc text-amber-200/65">Endless waves · coins · shop upgrades · Blood Moon boss</div>
                </div>
              </button>
              <button onClick={() => { setPendingMode('mansion'); setGameMode('char_select'); }} className="mode-card mansion-card text-left">
                <span className="mode-card-icon">🏰</span>
                <div>
                  <div className="mode-card-title" style={{ color: '#c084fc' }}>Vampire Mansion</div>
                  <div className="mode-card-desc" style={{ color: 'rgba(192,132,252,0.62)' }}>Room-by-room · cursed relics · debuffs · Lord Vladros</div>
                </div>
              </button>
              <button onClick={() => { setPendingMode('church'); setGameMode('char_select'); }} className="mode-card church-card text-left">
                <span className="mode-card-icon">⛪</span>
                <div>
                  <div className="mode-card-title" style={{ color: '#fcd34d' }}>Light Church</div>
                  <div className="mode-card-desc" style={{ color: 'rgba(253,224,71,0.62)' }}>Gargant portal · obstacle course · Cardinal Sanctus boss</div>
                </div>
              </button>
            </div>
          </div>
        )}

        {/* ── CHARACTER SELECT ── */}
        {gameMode === 'char_select' && (
          <div className="absolute inset-0 bg-black/82 flex flex-col items-center justify-center z-20 px-4">
            <h2 className="font-serif text-amber-200 text-2xl italic tracking-widest mb-1">Choose Your Hunter</h2>
            <p className="font-mono text-amber-400/50 text-xs mb-4 uppercase tracking-widest">Each character has unique weapons and abilities</p>
            <div className="char-select-grid">
              {CHARACTERS.map(char => (
                <button
                  key={char.id}
                  onClick={() => setSelectedChar(char.id)}
                  className={`char-card ${char.bgClass} ${selectedChar === char.id ? 'char-card-selected' : ''}`}
                  style={{ borderColor: selectedChar === char.id ? char.color : 'rgba(255,255,255,0.12)' }}
                >
                  <div className="char-icon">{char.icon}</div>
                  <div className="char-name" style={{ color: char.color }}>{char.name}</div>
                  <div className="char-subtitle">{char.subtitle}</div>
                  <div className="char-weapon-tag">⚔ {char.weapon.replace('_', ' ')}</div>
                  <div className="char-trait-preview">{char.trait.slice(0, 55)}{char.trait.length > 55 ? '…' : ''}</div>
                </button>
              ))}
            </div>
            {/* Selected char detail */}
            <div className="char-detail-row">
              {(() => {
                const c = CHARACTERS.find(ch => ch.id === selectedChar)!;
                return (
                  <>
                    <div className="font-mono text-xs" style={{ color: c.accentColor }}>
                      HP {c.stats.maxHealth} · SPD ×{c.stats.speed} · REGEN {c.stats.regen}/s
                    </div>
                    <div className="font-mono text-xs text-white/40 mt-1">{c.flavor}</div>
                  </>
                );
              })()}
            </div>
            <div className="flex gap-3 mt-4">
              <button onClick={() => setGameMode('select')} className="game-button border border-white/20 text-white/50 font-mono text-sm px-4 py-2 hover:border-white/40 transition-all">
                ← Back
              </button>
              <button
                onClick={() => setGameMode('diff_select')}
                className="game-button bg-amber-500/15 border border-amber-400/60 text-amber-100 font-mono text-sm px-6 py-2 hover:bg-amber-500/30 transition-all uppercase tracking-widest"
              >
                Continue →
              </button>
            </div>
          </div>
        )}

        {/* ── DIFFICULTY SELECT ── */}
        {gameMode === 'diff_select' && (
          <div className="absolute inset-0 bg-black/82 flex flex-col items-center justify-center z-20 px-4">
            <h2 className="font-serif text-amber-200 text-2xl italic tracking-widest mb-1">Choose Difficulty</h2>
            <p className="font-mono text-amber-400/50 text-xs mb-6 uppercase tracking-widest">Affects enemy strength and score multiplier</p>
            <div className="diff-select-row">
              {DIFFICULTIES.map(d => (
                <button
                  key={d.id}
                  onClick={() => setSelectedDiff(d.id)}
                  className={`diff-card diff-card-${d.id} ${selectedDiff === d.id ? 'diff-card-selected' : ''}`}
                >
                  <div className="diff-icon">{d.icon}</div>
                  <div className="diff-name">{d.name}</div>
                  <div className="diff-desc">{d.desc}</div>
                  <div className="diff-score-mult">×{d.scoreMultiplier} score</div>
                </button>
              ))}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setGameMode('char_select')} className="game-button border border-white/20 text-white/50 font-mono text-sm px-4 py-2 hover:border-white/40 transition-all">
                ← Back
              </button>
              <button
                onClick={() => {
                  if (pendingMode === 'forest') { startGame(); setGameMode('forest'); }
                  else if (pendingMode === 'mansion') { setGameMode('mansion'); }
                  else { setGameMode('church'); }
                }}
                className="game-button bg-red-900/30 border border-red-400/60 text-red-100 font-mono text-sm px-6 py-2 hover:bg-red-800/50 transition-all uppercase tracking-widest"
              >
                Begin Hunt
              </button>
            </div>
          </div>
        )}

        {/* ── FOREST GAMEOVER ── */}
        {gameState.status === 'gameover' && gameMode === 'forest' && (
          <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center z-20 px-5 text-center menu-glow">
            <h2 className="game-over-title font-serif text-red-500 mb-4 italic tracking-widest">SLAIN</h2>
            <div className="text-amber-100 font-mono mb-8 text-xl">
              FINAL SCORE: {gameState.score.toString().padStart(6, '0')}
            </div>
            <button
              onClick={startGame}
              className="game-button bg-amber-500/10 border border-amber-300/60 text-amber-100 font-mono hover:bg-red-900/50 hover:text-white transition-all hover:scale-105 uppercase tracking-widest shadow-[0_0_28px_rgba(255,170,70,.25)] mb-4"
            >
              Hunt Again
            </button>
            <button
              onClick={() => setGameMode('select')}
              className="text-amber-300/55 font-mono text-sm hover:text-amber-200/80 transition-colors uppercase tracking-widest"
            >
              ← Change Mode
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
