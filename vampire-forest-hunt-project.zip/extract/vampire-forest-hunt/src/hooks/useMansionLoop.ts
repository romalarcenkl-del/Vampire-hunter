import { useState, useEffect, useRef, useCallback } from 'react';

type Position = { x: number; y: number };
type Velocity = { x: number; y: number };
type WeaponMode = 'ranged' | 'sword';
export type Direction = 'north' | 'south' | 'east' | 'west';
export type RoomType = 'start' | 'normal' | 'elite' | 'item' | 'boss';

export type RoomDef = {
  type: RoomType;
  cleared: boolean;
  visited: boolean;
  connections: Partial<Record<Direction, boolean>>;
  itemId?: RelicId;
};

export type RelicId =
  | 'crimson_chalice' | 'shadow_veil' | 'blood_pact' | 'cursed_double'
  | 'hunters_debt' | 'vampire_embrace' | 'tainted_water' | 'dark_covenant'
  | 'soul_shard' | 'midnight_lens' | 'forsaken_shield' | 'wretched_eye';

export type RelicDef = {
  id: RelicId;
  name: string;
  flavor: string;
  buff: string;
  debuff: string;
  effects: Partial<RelicEffects>;
};

type RelicEffects = {
  gunDamageMult: number;
  swordDamageMult: number;
  speedMult: number;
  maxHealthBonus: number;
  fireRateMult: number;
  healPerKill: number;
  damageTakenMult: number;
  dashCooldownMult: number;
  burstCooldownMult: number;
  burstDamageMult: number;
  bulletSpeedMult: number;
  enemySpeedMult: number;
  shieldDurationMult: number;
  piercing: boolean;
  noRanged: boolean;
  multishot: boolean;
  healOnRoomClear: number;
};

type AbilityState = {
  dashCooldown: number;
  burstCooldown: number;
  shieldActive: boolean;
  holyPulse: number;
  swordSlash: number;
};

export type MansionPlayer = {
  pos: Position;
  health: number;
  maxHealth: number;
  speed: number;
  radius: number;
};

export type MansionEnemy = {
  id: string;
  kind: 'vampire' | 'wraith' | 'vladros';
  pos: Position;
  health: number;
  maxHealth: number;
  speed: number;
  radius: number;
  phase?: 1 | 2;
};

export type MansionBullet = {
  id: string;
  pos: Position;
  vel: Velocity;
  speed: number;
  radius: number;
  damage: number;
  piercing: boolean;
};

export type MansionState = {
  status: 'menu' | 'playing' | 'item_pickup' | 'gameover' | 'victory';
  roomGrid: (RoomDef | null)[][];
  currentRoomPos: { col: number; row: number };
  relics: RelicId[];
  pendingRelic: RelicId | null;
  player: MansionPlayer;
  enemies: MansionEnemy[];
  bullets: MansionBullet[];
  abilities: AbilityState;
  score: number;
  bossMessage: string;
  roomMessage: string;
  weapon: WeaponMode;
};

const GAME_WIDTH = 1200;
const GAME_HEIGHT = 800;
const PLAYER_SPEED = 5.4;
const BULLET_SPEED = 17;
const SHOOT_COOLDOWN = 170;
const SWORD_COOLDOWN = 330;
const DAMAGE_COOLDOWN = 400;
const DASH_COOLDOWN_BASE = 3600;
const BURST_COOLDOWN_BASE = 7200;
const DASH_DISTANCE = 150;
const SHIELD_DURATION_BASE = 560;
const BURST_RADIUS = 235;
const BURST_DAMAGE_BASE = 120;
const DOOR_ZONE = 44;
const GRID_COLS = 5;
const GRID_ROWS = 5;
const START_COL = 2;
const START_ROW = 2;

const DIRS: Array<[number, number, Direction, Direction]> = [
  [0, -1, 'north', 'south'],
  [0, 1, 'south', 'north'],
  [-1, 0, 'west', 'east'],
  [1, 0, 'east', 'west'],
];

const OPPOSITE: Record<Direction, Direction> = {
  north: 'south', south: 'north', east: 'west', west: 'east',
};

export const ALL_RELICS: RelicDef[] = [
  {
    id: 'crimson_chalice',
    name: 'Crimson Chalice',
    flavor: 'A goblet that always thirsts for more...',
    buff: '+35% gun damage',
    debuff: '-20 max HP',
    effects: { gunDamageMult: 1.35, maxHealthBonus: -20 },
  },
  {
    id: 'shadow_veil',
    name: 'Shadow Veil',
    flavor: 'Move like darkness itself. Shoot like fog.',
    buff: '+45% movement speed',
    debuff: '-30% gun damage',
    effects: { speedMult: 1.45, gunDamageMult: 0.7 },
  },
  {
    id: 'blood_pact',
    name: 'Blood Pact',
    flavor: 'Life traded freely for power.',
    buff: 'Heal 3 HP per kill',
    debuff: 'Take 25% more damage',
    effects: { healPerKill: 3, damageTakenMult: 1.25 },
  },
  {
    id: 'cursed_double',
    name: 'Cursed Double-Shot',
    flavor: 'Two bolts, half the force.',
    buff: 'Fire 2 bullets per shot',
    debuff: '-40% bullet speed',
    effects: { multishot: true, bulletSpeedMult: 0.6 },
  },
  {
    id: 'hunters_debt',
    name: "Hunter's Debt",
    flavor: 'All power has a price. Yours is time.',
    buff: '+65% all damage',
    debuff: '+80% dash cooldown',
    effects: { gunDamageMult: 1.65, swordDamageMult: 1.65, dashCooldownMult: 1.8 },
  },
  {
    id: 'vampire_embrace',
    name: "Vampire's Embrace",
    flavor: 'Their gift... and their hunger made yours.',
    buff: '+50 max HP',
    debuff: 'All enemies move 20% faster',
    effects: { maxHealthBonus: 50, enemySpeedMult: 1.2 },
  },
  {
    id: 'tainted_water',
    name: 'Tainted Holy Water',
    flavor: 'Blessed, yet utterly corrupted.',
    buff: 'Holy Burst charges 2x faster',
    debuff: '-50% burst damage',
    effects: { burstCooldownMult: 0.5, burstDamageMult: 0.5 },
  },
  {
    id: 'dark_covenant',
    name: 'Dark Covenant',
    flavor: 'The blade... above all else.',
    buff: '+80% sword damage',
    debuff: 'Ranged weapon disabled',
    effects: { swordDamageMult: 1.8, noRanged: true },
  },
  {
    id: 'soul_shard',
    name: 'Soul Shard',
    flavor: 'Consume the dead. Shrink among the living.',
    buff: 'Heal 4 HP per kill',
    debuff: '-30 max HP',
    effects: { healPerKill: 4, maxHealthBonus: -30 },
  },
  {
    id: 'midnight_lens',
    name: 'Midnight Lens',
    flavor: 'Pierce the veil between life and death.',
    buff: 'Bullets pierce through enemies',
    debuff: '-25% fire rate',
    effects: { piercing: true, fireRateMult: 0.75 },
  },
  {
    id: 'forsaken_shield',
    name: 'Forsaken Shield',
    flavor: 'Protected... but seldom able to flee.',
    buff: 'Dash shield lasts 2.5x longer',
    debuff: '+60% dash cooldown',
    effects: { shieldDurationMult: 2.5, dashCooldownMult: 1.6 },
  },
  {
    id: 'wretched_eye',
    name: 'Wretched Eye',
    flavor: 'It sees every room... and drains you for it.',
    buff: 'Fully heal on room clear',
    debuff: '-15 max HP',
    effects: { healOnRoomClear: 9999, maxHealthBonus: -15 },
  },
];

const DEFAULT_EFFECTS: RelicEffects = {
  gunDamageMult: 1, swordDamageMult: 1, speedMult: 1, maxHealthBonus: 0,
  fireRateMult: 1, healPerKill: 0, damageTakenMult: 1, dashCooldownMult: 1,
  burstCooldownMult: 1, burstDamageMult: 1, bulletSpeedMult: 1,
  enemySpeedMult: 1, shieldDurationMult: 1,
  piercing: false, noRanged: false, multishot: false, healOnRoomClear: 0,
};

export function computeRelicEffects(relics: RelicId[]): RelicEffects {
  const r = { ...DEFAULT_EFFECTS };
  for (const id of relics) {
    const def = ALL_RELICS.find(x => x.id === id);
    if (!def) continue;
    const fx = def.effects;
    if (fx.gunDamageMult !== undefined) r.gunDamageMult *= fx.gunDamageMult;
    if (fx.swordDamageMult !== undefined) r.swordDamageMult *= fx.swordDamageMult;
    if (fx.speedMult !== undefined) r.speedMult *= fx.speedMult;
    if (fx.maxHealthBonus !== undefined) r.maxHealthBonus += fx.maxHealthBonus;
    if (fx.fireRateMult !== undefined) r.fireRateMult *= fx.fireRateMult;
    if (fx.healPerKill !== undefined) r.healPerKill += fx.healPerKill;
    if (fx.damageTakenMult !== undefined) r.damageTakenMult *= fx.damageTakenMult;
    if (fx.dashCooldownMult !== undefined) r.dashCooldownMult *= fx.dashCooldownMult;
    if (fx.burstCooldownMult !== undefined) r.burstCooldownMult *= fx.burstCooldownMult;
    if (fx.burstDamageMult !== undefined) r.burstDamageMult *= fx.burstDamageMult;
    if (fx.bulletSpeedMult !== undefined) r.bulletSpeedMult *= fx.bulletSpeedMult;
    if (fx.enemySpeedMult !== undefined) r.enemySpeedMult *= fx.enemySpeedMult;
    if (fx.shieldDurationMult !== undefined) r.shieldDurationMult *= fx.shieldDurationMult;
    if (fx.piercing) r.piercing = true;
    if (fx.noRanged) r.noRanged = true;
    if (fx.multishot) r.multishot = true;
    if (fx.healOnRoomClear !== undefined && fx.healOnRoomClear > r.healOnRoomClear) r.healOnRoomClear = fx.healOnRoomClear;
  }
  return r;
}

function generateMansionMap(): (RoomDef | null)[][] {
  const grid: (RoomDef | null)[][] = Array.from({ length: GRID_ROWS }, () => Array(GRID_COLS).fill(null));
  grid[START_ROW][START_COL] = { type: 'start', cleared: true, visited: true, connections: {} };
  const roomList: [number, number][] = [[START_COL, START_ROW]];

  let attempts = 0;
  while (roomList.length < 14 && attempts < 500) {
    attempts++;
    const [col, row] = roomList[Math.floor(Math.random() * roomList.length)];
    const shuffled = [...DIRS].sort(() => Math.random() - 0.5);
    for (const [dc, dr, dir, revDir] of shuffled) {
      const nc = col + dc, nr = row + dr;
      if (nc >= 0 && nc < GRID_COLS && nr >= 0 && nr < GRID_ROWS && !grid[nr][nc]) {
        grid[nr][nc] = { type: 'normal', cleared: false, visited: false, connections: { [revDir]: true } };
        const existing = grid[row][col]!;
        grid[row][col] = { ...existing, connections: { ...existing.connections, [dir]: true } };
        roomList.push([nc, nr]);
        break;
      }
    }
  }

  const dist = new Map<string, number>();
  const bfsQueue: [number, number][] = [[START_COL, START_ROW]];
  dist.set(`${START_COL},${START_ROW}`, 0);
  while (bfsQueue.length > 0) {
    const [col, row] = bfsQueue.shift()!;
    const room = grid[row][col];
    if (!room) continue;
    const d = dist.get(`${col},${row}`)!;
    for (const [dc, dr, dir] of DIRS) {
      if (!room.connections[dir]) continue;
      const nc = col + dc, nr = row + dr;
      const key = `${nc},${nr}`;
      if (!dist.has(key)) { dist.set(key, d + 1); bfsQueue.push([nc, nr]); }
    }
  }

  let maxDist = 0, bossCol = START_COL, bossRow = START_ROW;
  for (const [key, d] of dist.entries()) {
    if (d > maxDist && key !== `${START_COL},${START_ROW}`) {
      maxDist = d;
      const parts = key.split(',');
      bossCol = Number(parts[0]); bossRow = Number(parts[1]);
    }
  }
  grid[bossRow][bossCol] = { ...grid[bossRow][bossCol]!, type: 'boss' };

  const relicPool: RelicId[] = [...ALL_RELICS.map(r => r.id)].sort(() => Math.random() - 0.5);
  let relicIdx = 0;
  const deadEnds = roomList
    .filter(([c, r]) => {
      if (c === START_COL && r === START_ROW) return false;
      if (c === bossCol && r === bossRow) return false;
      const room = grid[r][c];
      if (!room) return false;
      return Object.values(room.connections).filter(Boolean).length === 1;
    })
    .sort(() => Math.random() - 0.5);

  for (let i = 0; i < Math.min(3, deadEnds.length) && relicIdx < relicPool.length; i++, relicIdx++) {
    const [c, r] = deadEnds[i];
    grid[r][c] = { ...grid[r][c]!, type: 'item', cleared: false, itemId: relicPool[relicIdx] };
  }

  const eliteCandidates = roomList
    .filter(([c, r]) => grid[r][c]?.type === 'normal')
    .sort(() => Math.random() - 0.5);
  for (let i = 0; i < Math.min(2, eliteCandidates.length); i++) {
    const [c, r] = eliteCandidates[i];
    grid[r][c] = { ...grid[r][c]!, type: 'elite' };
  }

  return grid;
}

function spawnRoomEnemies(room: RoomDef, relicFx: RelicEffects, roomDepth: number): MansionEnemy[] {
  if (room.type === 'item' || room.type === 'start') return [];

  if (room.type === 'boss') {
    const hp = 1400 + roomDepth * 80;
    return [{
      id: 'vladros',
      kind: 'vladros',
      pos: { x: GAME_WIDTH / 2, y: 200 },
      health: hp,
      maxHealth: hp,
      speed: 2.0,
      radius: 48,
      phase: 1,
    }];
  }

  const isElite = room.type === 'elite';
  const count = isElite ? 5 : 4;
  const enemies: MansionEnemy[] = [];

  for (let i = 0; i < count; i++) {
    const isWraith = isElite && i === count - 1;
    const side = Math.floor(Math.random() * 4);
    let ex = 0, ey = 0;
    if (side === 0) { ex = 100 + Math.random() * (GAME_WIDTH - 200); ey = 100; }
    else if (side === 1) { ex = GAME_WIDTH - 100; ey = 100 + Math.random() * (GAME_HEIGHT - 200); }
    else if (side === 2) { ex = 100 + Math.random() * (GAME_WIDTH - 200); ey = GAME_HEIGHT - 100; }
    else { ex = 100; ey = 100 + Math.random() * (GAME_HEIGHT - 200); }

    const hp = isWraith ? 110 : isElite ? 145 : 90;
    enemies.push({
      id: `room-enemy-${i}-${Date.now()}-${Math.random()}`,
      kind: isWraith ? 'wraith' : 'vampire',
      pos: { x: ex, y: ey },
      health: hp,
      maxHealth: hp,
      speed: (isWraith ? 1.7 : 2.1) * relicFx.enemySpeedMult,
      radius: isWraith ? 17 : 14,
    });
  }
  return enemies;
}

const createInitialState = (): MansionState => ({
  status: 'menu',
  roomGrid: [],
  currentRoomPos: { col: START_COL, row: START_ROW },
  relics: [],
  pendingRelic: null,
  player: { pos: { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 }, health: 100, maxHealth: 100, speed: PLAYER_SPEED, radius: 15 },
  enemies: [],
  bullets: [],
  abilities: { dashCooldown: 0, burstCooldown: 0, shieldActive: false, holyPulse: 0, swordSlash: 0 },
  score: 0,
  bossMessage: '',
  roomMessage: '',
  weapon: 'ranged',
});

export function useMansionLoop() {
  const [mansionState, setMansionState] = useState<MansionState>(createInitialState());
  const keysRef = useRef<Record<string, boolean>>({});
  const mouseRef = useRef<Position>({ x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 });
  const isMouseDownRef = useRef(false);
  const touchMovementRef = useRef<Velocity>({ x: 0, y: 0 });
  const lastShootRef = useRef(0);
  const lastSwordRef = useRef(0);
  const lastDamageRef = useRef(0);
  const lastDashRef = useRef(-DASH_COOLDOWN_BASE);
  const lastBurstRef = useRef(-BURST_COOLDOWN_BASE);
  const shieldUntilRef = useRef(0);
  const holyPulseUntilRef = useRef(0);
  const swordSlashUntilRef = useRef(0);
  const dashReqRef = useRef(false);
  const burstReqRef = useRef(false);
  const weaponToggleReqRef = useRef(false);
  const frameRef = useRef<number | null>(null);
  const runningRef = useRef(false);
  const vladrosMinionTimerRef = useRef(0);
  const roomDepthRef = useRef(0);

  const stopFrame = useCallback(() => {
    runningRef.current = false;
    if (frameRef.current !== null) { cancelAnimationFrame(frameRef.current); frameRef.current = null; }
  }, []);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      keysRef.current[k] = true;
      if (k === ' ' || k === 'shift') { e.preventDefault(); dashReqRef.current = true; }
      if (k === 'q' || k === 'e') burstReqRef.current = true;
      if (k === 'tab' || k === 'f') { e.preventDefault(); weaponToggleReqRef.current = true; }
    };
    const onKeyUp = (e: KeyboardEvent) => { keysRef.current[e.key.toLowerCase()] = false; };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => { window.removeEventListener('keydown', onKeyDown); window.removeEventListener('keyup', onKeyUp); };
  }, []);

  const startMansion = useCallback(() => {
    stopFrame();
    const roomGrid = generateMansionMap();
    mouseRef.current = { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 };
    isMouseDownRef.current = false;
    touchMovementRef.current = { x: 0, y: 0 };
    lastShootRef.current = 0; lastSwordRef.current = 0; lastDamageRef.current = 0;
    lastDashRef.current = -DASH_COOLDOWN_BASE; lastBurstRef.current = -BURST_COOLDOWN_BASE;
    shieldUntilRef.current = 0; holyPulseUntilRef.current = 0; swordSlashUntilRef.current = 0;
    dashReqRef.current = false; burstReqRef.current = false; weaponToggleReqRef.current = false;
    vladrosMinionTimerRef.current = 0; roomDepthRef.current = 0;
    keysRef.current = {};
    runningRef.current = true;
    setMansionState({ ...createInitialState(), status: 'playing', roomGrid, roomMessage: 'You enter the Mansion...' });
  }, [stopFrame]);

  const acceptRelic = useCallback((relicId: RelicId) => {
    setMansionState(prev => {
      if (prev.status !== 'item_pickup') return prev;
      const nextRelics = [...prev.relics, relicId];
      const fx = computeRelicEffects(nextRelics);
      const newMaxHealth = Math.max(30, 100 + fx.maxHealthBonus);
      const newHealth = Math.min(newMaxHealth, prev.player.health);
      const newSpeed = PLAYER_SPEED * fx.speedMult;
      const nextWeapon: WeaponMode = fx.noRanged && prev.weapon === 'ranged' ? 'sword' : prev.weapon;
      const newGrid = prev.roomGrid.map(row => row.map(cell =>
        (cell?.itemId === relicId && cell.type === 'item') ? { ...cell, cleared: true } : cell
      ));
      runningRef.current = true;
      const relicName = ALL_RELICS.find(r => r.id === relicId)?.name ?? relicId;
      return {
        ...prev,
        status: 'playing',
        relics: nextRelics,
        pendingRelic: null,
        roomGrid: newGrid,
        weapon: nextWeapon,
        player: { ...prev.player, maxHealth: newMaxHealth, health: newHealth, speed: newSpeed },
        roomMessage: `Cursed by ${relicName}`,
      };
    });
  }, []);

  const setTouchMovement = useCallback((v: Velocity) => { touchMovementRef.current = v; }, []);
  const setAimPosition = useCallback((p: Position) => { mouseRef.current = p; }, []);
  const setFiring = useCallback((f: boolean) => { isMouseDownRef.current = f; }, []);
  const activateDash = useCallback(() => { dashReqRef.current = true; }, []);
  const activateHolyBurst = useCallback(() => { burstReqRef.current = true; }, []);
  const switchWeapon = useCallback(() => { weaponToggleReqRef.current = true; }, []);

  const update = useCallback((time: number) => {
    setMansionState(prev => {
      if (!runningRef.current || prev.status !== 'playing') {
        runningRef.current = false;
        return prev;
      }

      const fx = computeRelicEffects(prev.relics);
      const effectiveDashCD = DASH_COOLDOWN_BASE * fx.dashCooldownMult;
      const effectiveBurstCD = BURST_COOLDOWN_BASE * fx.burstCooldownMult;
      const effectiveShieldDur = SHIELD_DURATION_BASE * fx.shieldDurationMult;

      if (weaponToggleReqRef.current) {
        weaponToggleReqRef.current = false;
        if (fx.noRanged) return { ...prev, roomMessage: 'Dark Covenant forbids ranged' };
        return { ...prev, weapon: prev.weapon === 'ranged' ? 'sword' : 'ranged' };
      }

      let dx = touchMovementRef.current.x;
      let dy = touchMovementRef.current.y;
      if (keysRef.current['w'] || keysRef.current['arrowup']) dy -= 1;
      if (keysRef.current['s'] || keysRef.current['arrowdown']) dy += 1;
      if (keysRef.current['a'] || keysRef.current['arrowleft']) dx -= 1;
      if (keysRef.current['d'] || keysRef.current['arrowright']) dx += 1;
      if (dx !== 0 || dy !== 0) { const l = Math.sqrt(dx * dx + dy * dy); dx /= l; dy /= l; }

      let nextPos = {
        x: Math.max(24, Math.min(GAME_WIDTH - 24, prev.player.pos.x + dx * prev.player.speed)),
        y: Math.max(24, Math.min(GAME_HEIGHT - 24, prev.player.pos.y + dy * prev.player.speed)),
      };

      if (dashReqRef.current && time - lastDashRef.current >= effectiveDashCD) {
        let ddx = dx, ddy = dy;
        if (ddx === 0 && ddy === 0) {
          ddx = mouseRef.current.x - nextPos.x; ddy = mouseRef.current.y - nextPos.y;
          const dl = Math.sqrt(ddx * ddx + ddy * ddy) || 1; ddx /= dl; ddy /= dl;
        }
        nextPos = {
          x: Math.max(24, Math.min(GAME_WIDTH - 24, nextPos.x + ddx * DASH_DISTANCE)),
          y: Math.max(24, Math.min(GAME_HEIGHT - 24, nextPos.y + ddy * DASH_DISTANCE)),
        };
        lastDashRef.current = time;
        shieldUntilRef.current = time + effectiveShieldDur;
      }
      dashReqRef.current = false;

      const gunDmg = 30 * fx.gunDamageMult;
      const swordDmg = 72 * fx.swordDamageMult;
      const swordRange = 82;
      const shootCD = SHOOT_COOLDOWN / fx.fireRateMult;
      const bSpeed = BULLET_SPEED * fx.bulletSpeedMult;

      let newBullets = [...prev.bullets];
      let newEnemies = [...prev.enemies];

      const canRanged = prev.weapon === 'ranged' && !fx.noRanged;
      if (isMouseDownRef.current && canRanged && time - lastShootRef.current > shootCD) {
        const mx = mouseRef.current.x, my = mouseRef.current.y;
        let bx = mx - nextPos.x, by = my - nextPos.y;
        const bl = Math.sqrt(bx * bx + by * by);
        if (bl > 0) {
          bx /= bl; by /= bl;
          const base = { pos: { ...nextPos }, speed: bSpeed, radius: 5, damage: gunDmg, piercing: fx.piercing };
          newBullets.push({ ...base, id: `${time}-0`, vel: { x: bx * bSpeed, y: by * bSpeed } });
          if (fx.multishot) {
            const sp = 0.2;
            newBullets.push({ ...base, id: `${time}-1`, vel: { x: (bx * Math.cos(sp) - by * Math.sin(sp)) * bSpeed, y: (bx * Math.sin(sp) + by * Math.cos(sp)) * bSpeed } });
          }
          lastShootRef.current = time;
        }
      }

      if (isMouseDownRef.current && prev.weapon === 'sword' && time - lastSwordRef.current > SWORD_COOLDOWN) {
        let ax = mouseRef.current.x - nextPos.x, ay = mouseRef.current.y - nextPos.y;
        const al = Math.sqrt(ax * ax + ay * ay) || 1; ax /= al; ay /= al;
        newEnemies = newEnemies.map(e => {
          const ex = e.pos.x - nextPos.x, ey = e.pos.y - nextPos.y;
          const dist = Math.sqrt(ex * ex + ey * ey);
          if (dist > swordRange + e.radius) return e;
          const dot = dist > 0 ? (ex / dist) * ax + (ey / dist) * ay : 1;
          if (dot < 0.05) return e;
          const vuln = e.kind === 'wraith' ? 0.45 : e.kind === 'vladros' ? 0.7 : 1;
          return { ...e, health: e.health - swordDmg * vuln };
        });
        lastSwordRef.current = time;
        swordSlashUntilRef.current = time + 220;
      }

      newBullets = newBullets
        .map(b => ({ ...b, pos: { x: b.pos.x + b.vel.x, y: b.pos.y + b.vel.y } }))
        .filter(b => b.pos.x > -20 && b.pos.x < GAME_WIDTH + 20 && b.pos.y > -20 && b.pos.y < GAME_HEIGHT + 20);

      const vladros = newEnemies.find(e => e.kind === 'vladros');
      if (vladros && vladros.health > 0) {
        const isP2 = vladros.health < vladros.maxHealth * 0.5;
        const mInterval = isP2 ? 2600 : 4000;
        if (time - vladrosMinionTimerRef.current > mInterval) {
          vladrosMinionTimerRef.current = time;
          const mc = isP2 ? 2 : 1;
          for (let m = 0; m < mc; m++) {
            const angle = Math.random() * Math.PI * 2;
            const r = 110 + Math.random() * 80;
            const hp = isP2 ? 75 : 55;
            newEnemies.push({
              id: `minion-${time}-${m}-${Math.random()}`,
              kind: 'vampire',
              pos: {
                x: Math.max(60, Math.min(GAME_WIDTH - 60, vladros.pos.x + Math.cos(angle) * r)),
                y: Math.max(60, Math.min(GAME_HEIGHT - 60, vladros.pos.y + Math.sin(angle) * r)),
              },
              health: hp, maxHealth: hp,
              speed: 2.4 * fx.enemySpeedMult,
              radius: 13,
            });
          }
        }
      }

      if (burstReqRef.current && time - lastBurstRef.current >= effectiveBurstCD) {
        const burstDmg = BURST_DAMAGE_BASE * fx.burstDamageMult;
        newEnemies = newEnemies.map(e => {
          const dist = Math.sqrt((nextPos.x - e.pos.x) ** 2 + (nextPos.y - e.pos.y) ** 2);
          if (dist > BURST_RADIUS) return e;
          const push = Math.max(0, (BURST_RADIUS - dist) / BURST_RADIUS);
          const px = dist > 0 ? (e.pos.x - nextPos.x) / dist : 0;
          const py = dist > 0 ? (e.pos.y - nextPos.y) / dist : -1;
          const vuln = e.kind === 'wraith' ? 0.65 : e.kind === 'vladros' ? 0.45 : 1;
          return {
            ...e,
            health: e.health - burstDmg * vuln,
            pos: { x: Math.max(20, Math.min(GAME_WIDTH - 20, e.pos.x + px * push * 90)), y: Math.max(20, Math.min(GAME_HEIGHT - 20, e.pos.y + py * push * 90)) },
          };
        });
        lastBurstRef.current = time;
        shieldUntilRef.current = Math.max(shieldUntilRef.current, time + 1100);
        holyPulseUntilRef.current = time + 460;
      }
      burstReqRef.current = false;

      let newHealth = prev.player.health;
      let touchingPlayer = false;
      newEnemies = newEnemies.map(e => {
        const ex = nextPos.x - e.pos.x, ey = nextPos.y - e.pos.y;
        const dist = Math.sqrt(ex * ex + ey * ey);
        if (dist < e.radius + prev.player.radius + 2) touchingPlayer = true;
        if (dist === 0) return e;
        const isVP2 = e.kind === 'vladros' && e.health < e.maxHealth * 0.5;
        const spd = e.kind === 'wraith' ? e.speed * 0.78 : isVP2 ? e.speed * 1.7 : e.speed;
        return { ...e, pos: { x: e.pos.x + (ex / dist) * spd, y: e.pos.y + (ey / dist) * spd } };
      });

      if (touchingPlayer && time > shieldUntilRef.current && time - lastDamageRef.current > DAMAGE_COOLDOWN) {
        const hasVladros = newEnemies.some(e => e.kind === 'vladros');
        newHealth -= (hasVladros ? 14 : 9) * fx.damageTakenMult;
        lastDamageRef.current = time;
      }

      newBullets = newBullets.filter(b => {
        let hit = false;
        newEnemies = newEnemies.map(e => {
          if (!b.piercing && hit) return e;
          const dist = Math.sqrt((b.pos.x - e.pos.x) ** 2 + (b.pos.y - e.pos.y) ** 2);
          if (dist < b.radius + e.radius) {
            if (!b.piercing) hit = true;
            const vuln = e.kind === 'wraith' ? 1.85 : e.kind === 'vladros' ? 0.8 : 1;
            return { ...e, health: e.health - b.damage * vuln };
          }
          return e;
        });
        return b.piercing || !hit;
      });

      const killed = newEnemies.filter(e => e.health <= 0);
      newEnemies = newEnemies.filter(e => e.health > 0);
      newHealth = Math.min(prev.player.maxHealth, newHealth + killed.length * fx.healPerKill + killed.reduce((t, e) => t + (e.kind === 'vladros' ? 40 : 2), 0));
      const newScore = prev.score + killed.reduce((t, e) => t + (e.kind === 'vladros' ? 3000 : e.kind === 'wraith' ? 150 : 100), 0);

      let newGrid = prev.roomGrid.map(row => [...row]);
      const curRoomDef = newGrid[prev.currentRoomPos.row][prev.currentRoomPos.col];
      let newStatus: MansionState['status'] = prev.status;
      let newRoomMsg = prev.roomMessage;

      const justCleared = curRoomDef && !curRoomDef.cleared && newEnemies.length === 0 && ['normal', 'elite', 'boss'].includes(curRoomDef.type);

      if (justCleared) {
        if (curRoomDef.type === 'boss') {
          newStatus = 'victory';
          runningRef.current = false;
        } else {
          newGrid[prev.currentRoomPos.row][prev.currentRoomPos.col] = { ...curRoomDef, cleared: true };
          if (fx.healOnRoomClear > 0) newHealth = Math.min(prev.player.maxHealth, newHealth + fx.healOnRoomClear);
          newRoomMsg = 'Room cleared — doors open';
        }
      }

      if (newHealth <= 0) {
        newStatus = 'gameover';
        runningRef.current = false;
        isMouseDownRef.current = false;
        touchMovementRef.current = { x: 0, y: 0 };
      }

      if (newStatus === 'playing') {
        const roomDef = newGrid[prev.currentRoomPos.row][prev.currentRoomPos.col];
        const isRoomClear = roomDef?.cleared || roomDef?.type === 'item';
        let transition: Direction | null = null;
        if (isRoomClear) {
          if (nextPos.y < DOOR_ZONE && roomDef?.connections.north) transition = 'north';
          else if (nextPos.y > GAME_HEIGHT - DOOR_ZONE && roomDef?.connections.south) transition = 'south';
          else if (nextPos.x < DOOR_ZONE && roomDef?.connections.west) transition = 'west';
          else if (nextPos.x > GAME_WIDTH - DOOR_ZONE && roomDef?.connections.east) transition = 'east';
        }

        if (transition) {
          const delta: Record<Direction, [number, number]> = { north: [0, -1], south: [0, 1], east: [1, 0], west: [-1, 0] };
          const [dc, dr] = delta[transition];
          const newCol = prev.currentRoomPos.col + dc;
          const newRow = prev.currentRoomPos.row + dr;
          const newRoomDef = newGrid[newRow]?.[newCol];
          if (newRoomDef) {
            const entryDir = OPPOSITE[transition];
            let entryX = nextPos.x, entryY = nextPos.y;
            if (entryDir === 'south') entryY = GAME_HEIGHT - 90;
            else if (entryDir === 'north') entryY = 90;
            else if (entryDir === 'east') entryX = GAME_WIDTH - 90;
            else if (entryDir === 'west') entryX = 90;

            const updatedRoom = { ...newRoomDef, visited: true };
            newGrid[newRow][newCol] = updatedRoom;
            roomDepthRef.current += 1;

            if (newRoomDef.type === 'item' && !newRoomDef.cleared && newRoomDef.itemId) {
              runningRef.current = false;
              return {
                ...prev,
                status: 'item_pickup',
                currentRoomPos: { col: newCol, row: newRow },
                roomGrid: newGrid,
                enemies: [],
                bullets: [],
                pendingRelic: newRoomDef.itemId,
                player: { ...prev.player, pos: { x: entryX, y: entryY }, health: Math.max(1, Math.round(newHealth)) },
                score: newScore,
                roomMessage: '',
                bossMessage: '',
                abilities: buildAbilities(time, effectiveDashCD, effectiveBurstCD),
              };
            }

            let roomEnemies: MansionEnemy[] = [];
            if (!updatedRoom.cleared) {
              roomEnemies = spawnRoomEnemies(updatedRoom, fx, roomDepthRef.current);
              if (updatedRoom.type === 'boss') vladrosMinionTimerRef.current = time;
            }

            const isItemCleared = updatedRoom.type === 'item' && updatedRoom.cleared;
            if (isItemCleared) newGrid[newRow][newCol] = { ...updatedRoom, cleared: true };

            return {
              ...prev,
              currentRoomPos: { col: newCol, row: newRow },
              roomGrid: newGrid,
              enemies: roomEnemies,
              bullets: [],
              player: { ...prev.player, pos: { x: entryX, y: entryY }, health: Math.max(1, Math.round(newHealth)) },
              score: newScore,
              roomMessage: updatedRoom.type === 'boss' ? 'Lord Vladros awaits...' : updatedRoom.type === 'elite' ? 'Elite chamber!' : updatedRoom.type === 'item' ? (updatedRoom.cleared ? 'Empty relic room...' : '') : 'A new chamber...',
              bossMessage: updatedRoom.type === 'boss' ? 'Lord Vladros the Eternal' : '',
              status: newStatus,
              abilities: buildAbilities(time, effectiveDashCD, effectiveBurstCD),
            };
          }
        }
      }

      newEnemies = newEnemies.map(e => e.kind !== 'vladros' ? e : { ...e, phase: e.health < e.maxHealth * 0.5 ? 2 : 1 });
      const bossAlive = newEnemies.find(e => e.kind === 'vladros');

      return {
        ...prev,
        status: newStatus,
        roomGrid: newGrid,
        enemies: newEnemies,
        bullets: newBullets,
        score: newScore,
        roomMessage: newRoomMsg,
        bossMessage: bossAlive ? (bossAlive.phase === 2 ? 'LORD VLADROS — ENRAGED' : 'Lord Vladros the Eternal') : prev.bossMessage,
        player: { ...prev.player, pos: nextPos, health: Math.max(0, Math.min(Math.round(newHealth), prev.player.maxHealth)) },
        abilities: buildAbilities(time, effectiveDashCD, effectiveBurstCD),
      };
    });

    if (runningRef.current) {
      frameRef.current = requestAnimationFrame(update);
    } else {
      frameRef.current = null;
    }
  }, []);

  function buildAbilities(time: number, dashCD: number, burstCD: number): AbilityState {
    return {
      dashCooldown: Math.max(0, dashCD - (time - lastDashRef.current)),
      burstCooldown: Math.max(0, burstCD - (time - lastBurstRef.current)),
      shieldActive: time < shieldUntilRef.current,
      holyPulse: Math.max(0, (holyPulseUntilRef.current - time) / 460),
      swordSlash: Math.max(0, (swordSlashUntilRef.current - time) / 220),
    };
  }

  useEffect(() => {
    if (mansionState.status === 'playing' && runningRef.current && frameRef.current === null) {
      frameRef.current = requestAnimationFrame(update);
    }
    if (mansionState.status !== 'playing') {
      runningRef.current = false;
    }
    return () => {
      if (frameRef.current !== null) { cancelAnimationFrame(frameRef.current); frameRef.current = null; }
    };
  }, [mansionState.status, update]);

  return {
    mansionState, startMansion, acceptRelic,
    setTouchMovement, setAimPosition, setFiring,
    activateDash, activateHolyBurst, switchWeapon,
    GAME_WIDTH, GAME_HEIGHT,
    GRID_COLS, GRID_ROWS,
  };
}
