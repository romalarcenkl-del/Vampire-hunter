import React, { useState, useEffect } from 'react';
import type { StoryAct } from '@/data/story';

interface StorySceneProps {
  act: StoryAct;
  onComplete: () => void;
  accentColor?: string;
  bg?: 'forest' | 'mansion' | 'church' | 'hellsing' | 'default';
  onBack?: () => void;
}

const BG_STYLES: Record<string, React.CSSProperties> = {
  forest: { background: 'radial-gradient(ellipse at 50% 120%, #0a1a08 0%, #020804 100%)' },
  mansion: { background: 'radial-gradient(ellipse at 50% 120%, #1a0a1a 0%, #06020a 100%)' },
  church: { background: 'radial-gradient(ellipse at 50% 120%, #1a1408 0%, #060402 100%)' },
  hellsing: { background: 'radial-gradient(ellipse at 50% 120%, #1a0808 0%, #080202 100%)' },
  default: { background: 'radial-gradient(ellipse at 50% 120%, #0c0c10 0%, #040408 100%)' },
};

export default function StoryScene({ act, onComplete, accentColor = '#f59e0b', bg = 'default', onBack }: StorySceneProps) {
  const [slideIndex, setSlideIndex] = useState(0);
  const [visible, setVisible] = useState(false);
  const [textVisible, setTextVisible] = useState(false);

  useEffect(() => {
    setVisible(false);
    setTextVisible(false);
    const t1 = setTimeout(() => setVisible(true), 80);
    const t2 = setTimeout(() => setTextVisible(true), 400);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [slideIndex]);

  const slide = act[slideIndex];
  const isLast = slideIndex === act.length - 1;

  function advance() {
    if (!isLast) {
      setSlideIndex(i => i + 1);
    } else {
      setVisible(false);
      setTimeout(onComplete, 320);
    }
  }

  return (
    <div
      className="absolute inset-0 flex flex-col items-center justify-center z-50"
      style={BG_STYLES[bg]}
      onClick={advance}
    >
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at 50% 0%, rgba(255,255,255,0.015) 0%, transparent 60%)',
          transition: 'opacity 0.4s',
          opacity: visible ? 1 : 0,
        }}
      />

      <div
        className="relative z-10 max-w-2xl w-full mx-auto px-8 py-10 flex flex-col gap-6"
        style={{
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(18px)',
          transition: 'opacity 0.42s ease, transform 0.42s ease',
        }}
      >
        {slide.speaker && (
          <div
            className="font-mono text-xs uppercase tracking-[0.35em] mb-1"
            style={{ color: accentColor, opacity: textVisible ? 0.9 : 0, transition: 'opacity 0.35s ease 0.1s' }}
          >
            ── {slide.speaker} ──
          </div>
        )}

        <div
          className="font-serif text-xl leading-relaxed"
          style={{
            color: '#e8dfc8',
            textShadow: '0 2px 24px rgba(0,0,0,0.9)',
            opacity: textVisible ? 1 : 0,
            transition: 'opacity 0.5s ease 0.25s',
          }}
        >
          {slide.text}
        </div>

        <div
          className="flex items-center justify-between mt-6"
          style={{ opacity: textVisible ? 1 : 0, transition: 'opacity 0.4s ease 0.5s' }}
        >
          <div className="font-mono text-xs text-white/25 uppercase tracking-widest">
            {slideIndex + 1} / {act.length}
          </div>
          <button
            onClick={e => { e.stopPropagation(); advance(); }}
            className="font-mono text-sm uppercase tracking-[0.25em] px-6 py-2 border transition-all hover:scale-105"
            style={{
              color: accentColor,
              borderColor: accentColor + '55',
              background: accentColor + '0d',
              boxShadow: `0 0 18px ${accentColor}22`,
            }}
          >
            {isLast ? 'Continue →' : 'Next →'}
          </button>
        </div>
      </div>

      {onBack && (
        <button
          onClick={e => { e.stopPropagation(); onBack(); }}
          className="absolute top-5 left-5 font-mono text-xs text-white/30 uppercase tracking-widest hover:text-white/60 transition-colors z-20"
        >
          ← Exit Story
        </button>
      )}

      <div className="absolute bottom-4 inset-x-0 text-center font-mono text-[10px] text-white/18 uppercase tracking-widest pointer-events-none">
        Click anywhere to continue
      </div>
    </div>
  );
}
