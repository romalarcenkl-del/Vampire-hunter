import type { CharacterId } from './characters';

export type StorySlide = {
  speaker?: string;
  text: string;
};

export type StoryAct = StorySlide[];

export const OPENING_ACT: StoryAct = [
  {
    speaker: 'HELLSING INTELLIGENCE BRIEFING',
    text: 'England. Late autumn, 2003. Three villages in the British countryside have gone silent in less than a week. No bodies. No witnesses. No signs of struggle — only doors left open and candles still burning.',
  },
  {
    speaker: 'FIELD REPORT — CLASSIFIED',
    text: 'Thirty-seven civilians confirmed missing. Autopsies on four recovered subjects show signs consistent with vampiric conversion. An unknown party is building an army — quickly, and without care for secrecy.',
  },
  {
    speaker: 'SIR INTEGRA FAIRBROOK WINGATES HELLSING',
    text: '"I am sending one agent. You will investigate three confirmed locations and eliminate whatever you find at the source. I don\'t care what it is. Make sure it doesn\'t get up again."',
  },
];

export const CHAR_INTRO: Record<CharacterId, StoryAct> = {
  hunter: [
    {
      speaker: 'THE HUNTER',
      text: 'Another contract. Another mess someone else made. Hellsing pays on delivery — no questions, no paperwork, no explanations. He prefers it that way.',
    },
    {
      speaker: 'THE HUNTER',
      text: '"The forest, a mansion, a church. Three locations, three jobs. I\'ll clear them in order." He checks his pistol and lights a cigarette. "Let\'s not drag this out."',
    },
  ],
  alucard: [
    {
      speaker: 'ALUCARD',
      text: 'Sir Integra\'s exact words: "Don\'t dawdle." As if he ever did. The reports described recently-turned vampires — sloppy work, feral behaviour, no discipline. Someone in a hurry, building something. He found that mildly interesting.',
    },
    {
      speaker: 'ALUCARD',
      text: '"Shall we begin, then?" He smiles in the dark of the briefing room. No one smiles back. That\'s fine. He has enough amusement for all of them.',
    },
  ],
  integra: [
    {
      speaker: 'SIR INTEGRA HELLSING',
      text: 'She had not slept in thirty-one hours. She had also not delegated a single decision. When the Hellsing Organization moves, it moves at her word, her pace, and her standard.',
    },
    {
      speaker: 'SIR INTEGRA HELLSING',
      text: 'She picked up the mission herself. It was the only way to be certain. She lifts her head, sets her jaw, and does not explain herself to anyone in the room.',
    },
  ],
  walter: [
    {
      speaker: 'WALTER C. DORNEZ',
      text: 'He had served the Hellsing family since before Sir Integra was born. He had never once been asked to explain himself or justify a decision. He simply performed his duty — and performed it better than anyone alive.',
    },
    {
      speaker: 'WALTER C. DORNEZ',
      text: '"Three locations," he murmurs, examining his monocle in the light. He does not appear concerned. He coils his wires with the unhurried confidence of someone who has done this for sixty years. "Manageable."',
    },
  ],
  seras: [
    {
      speaker: 'SERAS VICTORIA',
      text: 'She was still adjusting. The dark wasn\'t dark anymore. She could hear heartbeats through stone walls, distinguish blood types by smell. She told herself it would be useful on this assignment. She wasn\'t wrong.',
    },
    {
      speaker: 'SERAS VICTORIA',
      text: '"I can do this," she says aloud, to nobody in particular, shouldering her rifle. "I\'m ready." She almost believes it. That\'s enough for now.',
    },
  ],
  anderson: [
    {
      speaker: 'FATHER ALEXANDER ANDERSON',
      text: 'Iscariot Section XIII had been watching the same three locations for three weeks. When Hellsing\'s involvement was confirmed, Anderson requested joint authority. He was denied. He came anyway.',
    },
    {
      speaker: 'FATHER ALEXANDER ANDERSON',
      text: '"Wherever the Devil makes a house, God sends a servant to burn it down." He unsheathes both bayonets. "I\'ve been burning them down for twenty years. This is no different."',
    },
  ],
};

export const FOREST_ACT: StoryAct = [
  {
    speaker: 'THE HEARTWOOD FOREST',
    text: 'The vampires here were freshly turned — feral, disorganised, multiplying without restraint. Whoever made them was in a hurry and had no interest in quality control. The forest smelled of turned earth and something older.',
  },
  {
    speaker: 'AFTER THE HUNT',
    text: 'The forest was cleared. In the ruins of the last nest, a single piece of paper survived — burned at the corners, ink still legible. A name, written over and over in different hands: VLADROS. Below it — a wax seal. An estate crest. Eastern England.',
  },
];

export const POST_MANSION_ACT: StoryAct = [
  {
    speaker: 'THE VLADROS ESTATE — AFTERMATH',
    text: 'Lord Vladros — vampire lord, three centuries old — spoke his last words through ash and crumbling stone. Not in defiance. In warning.',
  },
  {
    speaker: 'LORD VLADROS (last words)',
    text: '"You think I began this? I was invited. Offered an alliance, then discarded like a tool that had served its purpose. Ask the Cardinal. Ask Sanctus what he promised us. Ask him what he gave us instead."',
  },
  {
    speaker: 'HELLSING INTELLIGENCE — CROSS-REFERENCE',
    text: 'Cardinal Sanctus. Formerly attached to the Light Church of Saint Croix. Reported missing forty years ago — no body recovered. Church records sealed. The building itself has been locked from the inside ever since.',
  },
];

export const PRE_CHURCH_ACT: StoryAct = [
  {
    speaker: 'THE LIGHT CHURCH OF SAINT CROIX',
    text: 'A hundred and twelve years old. Built on a hill north of the city, visible for miles. The stained glass was intact. The candles inside were still lit — forty years of unmaintained candles, still burning without melting.',
  },
  {
    speaker: 'FIRST CONTACT',
    text: 'Inside the nave: a Garganta. A dimensional rift — not vampiric, not human. The kind used by entities that should not be in this world. Whoever opened it knew exactly what they were doing. They left it open. Like an invitation.',
  },
];

export const CHAR_POST_MANSION: Record<CharacterId, string> = {
  hunter: '"Vladros. A three-century-old lord reduced to ash in under an hour." He exhales smoke. "Not a bad rate."',
  alucard: 'Alucard stares at the name for a long moment. "Sanctus." He says it quietly, like someone remembering a face from a very old photograph.',
  integra: 'Sir Integra adds the name to her notes without pause. "Cardinal Sanctus. Find the file. Tonight." There is no hesitation in her voice. There never is.',
  walter: '"So there is a third party." Walter folds his monocle cloth precisely. "The Cardinal was the architect. Vladros was merely the contractor." He is already moving toward the door.',
  seras: 'Seras looks at the paper in her hands. Forty years. The Cardinal disappeared before she was born. "What did he promise them?" she asks. No one answers. She has to go find out herself.',
  anderson: '"A Cardinal turned to darkness." Anderson is silent for a long moment. When he speaks, his voice is flat. "There is no greater sin. Let us not leave it unanswered."',
};
