import type { CharacterId } from './characters';

export type EndingData = {
  title: string;
  subtitle: string;
  lines: string[];
};

export const MANSION_ENDINGS: Record<CharacterId, EndingData> = {
  hunter: {
    title: 'MANSION CLEARED',
    subtitle: 'The Hunter collects his fee.',
    lines: [
      'He counts the coins by torchlight — there are fewer than he expected.',
      '"Vampires. Always so dramatic and always so broke."',
      'He lights a cigarette off Lord Vladros\'s cape and walks out without looking back.',
    ],
  },
  alucard: {
    title: 'VLADROS HAS FALLEN',
    subtitle: 'Alucard is disappointed.',
    lines: [
      'He stands over the ashes for a long moment.',
      '"That\'s all? A thousand years of power and you couldn\'t even scratch me."',
      'He smiles. Not from victory. From the memory of something that once could.',
    ],
  },
  integra: {
    title: 'MANSION SECURED',
    subtitle: 'Mission complete. As expected.',
    lines: [
      '"Target eliminated. No casualties. No complications."',
      'She removes her gloves — there is blood on them — and drops them without looking.',
      '"Hellsing does not fail. Remember that."',
    ],
  },
  walter: {
    title: 'VLADROS SEVERED',
    subtitle: 'The Angel of Death departs.',
    lines: [
      'Walter coils his wires with practiced precision. There is no celebration.',
      '"Lord Vladros. I\'ve heard that name for eighty years."',
      '"I won\'t hear it again." He adjusts his monocle and walks into the dark.',
    ],
  },
  seras: {
    title: 'MANSION LIBERATED',
    subtitle: 'Seras Victoria stands in the silence.',
    lines: [
      'She stares at her rifle — it is dripping with something dark.',
      'She doesn\'t feel sick. That\'s what worries her.',
      '"Captain..." she whispers. "...did I do good?"',
      'The ruin answers in silence. She decides that means yes.',
    ],
  },
  anderson: {
    title: 'GOD\'S WILL DONE',
    subtitle: 'Father Anderson kneels in the ashes.',
    lines: [
      '"This place was an affront. It is no longer." He drives a bayonet into the floor.',
      'He prays over the ruins — not for the vampires, but for the souls they took.',
      '"Amen." One word. Enough.',
    ],
  },
};

export const CHURCH_ENDINGS: Record<CharacterId, EndingData> = {
  hunter: {
    title: 'LIGHT PREVAILS',
    subtitle: 'The Hunter walks out of the smoking nave.',
    lines: [
      'He lights a cigarette off Cardinal Sanctus\'s smouldering halo.',
      '"Next time, bring more angels."',
      'He pockets the last relic — it\'ll fetch a good price. He doesn\'t ask what it does.',
    ],
  },
  alucard: {
    title: 'THE CARDINAL FALLS',
    subtitle: 'Darkness swallows the sacred light.',
    lines: [
      'Alucard tilts his hat as holy fire fills the ruined nave.',
      '"Even God\'s soldiers fall in the end."',
      'He turns before the dawn touches him. He has seen enough churches burn.',
      '"Pathetic. Send a real saint next time."',
    ],
  },
  integra: {
    title: 'CHURCH SECURED',
    subtitle: 'Sir Integra Fairbrook Wingates Hellsing.',
    lines: [
      'She surveys the wreckage without expression.',
      '"The Cardinal was a problem. It has been resolved."',
      'She lights her cigar from a fallen candle.',
      '"Well done." Two words. From Integra, they mean more than any medal.',
    ],
  },
  walter: {
    title: 'THE CARDINAL SEVERED',
    subtitle: 'The Grim Reaper\'s Butler bows.',
    lines: [
      '"Cardinal Sanctus." Walter adjusts his monocle over the silence.',
      '"Two phases. Homing beams. Minion spawns. A competent opponent."',
      'He pauses. "Not competent enough."',
      'He vanishes into the shadows before the last candle gutters out.',
    ],
  },
  seras: {
    title: 'THE LIGHT DIMS',
    subtitle: 'Seras Victoria stands in the ruined nave.',
    lines: [
      'Stained glass rains around her. She doesn\'t flinch anymore.',
      '"I used to pray here," she says to nobody. "A long time ago."',
      'She looks at her hands. Then at the sky through the broken ceiling.',
      '"Captain... I think I\'m okay now."',
    ],
  },
  anderson: {
    title: 'THE CHURCH IS PURIFIED',
    subtitle: 'Father Alexander Anderson weeps — just once.',
    lines: [
      'He stands in what remains of the nave, dawn on his face.',
      '"This was God\'s house. It was desecrated."',
      'He drives both bayonets into the altar stone.',
      '"Now it is clean." He weeps. Only once. Then he is done.',
    ],
  },
};
