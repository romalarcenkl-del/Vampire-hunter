export type CharacterId = 'hunter' | 'alucard' | 'integra' | 'walter' | 'seras' | 'anderson';
export type WeaponKind = 'pistol' | 'dual_pistol' | 'rifle' | 'wire' | 'bayonet';
export type DifficultyId = 'easy' | 'normal' | 'hard';

export interface AbilityDef {
  id: string;
  name: string;
  desc: string;
  cooldown: number;
  type: 'normal' | 'special';
  icon: string;
}

export interface CharacterDef {
  id: CharacterId;
  name: string;
  subtitle: string;
  flavor: string;
  icon: string;
  color: string;
  accentColor: string;
  bgClass: string;
  weapon: WeaponKind;
  stats: {
    maxHealth: number;
    speed: number;
    regen: number;
    damage: number;
    fireRate: number;
    noLimits: boolean;
    vampiricRegen: boolean;
  };
  abilities: AbilityDef[];
  trait: string;
}

export interface DifficultyDef {
  id: DifficultyId;
  name: string;
  desc: string;
  icon: string;
  playerHealthMult: number;
  enemyHealthMult: number;
  enemyDamageMult: number;
  enemyCountMult: number;
  scoreMultiplier: number;
}

export const DIFFICULTIES: DifficultyDef[] = [
  {
    id: 'easy',
    name: 'Neophyte',
    desc: 'More HP, weaker enemies, 0.75× score',
    icon: '🌙',
    playerHealthMult: 1.5,
    enemyHealthMult: 0.7,
    enemyDamageMult: 0.6,
    enemyCountMult: 0.8,
    scoreMultiplier: 0.75,
  },
  {
    id: 'normal',
    name: 'Hunter',
    desc: 'Balanced challenge, standard score',
    icon: '⚔️',
    playerHealthMult: 1.0,
    enemyHealthMult: 1.0,
    enemyDamageMult: 1.0,
    enemyCountMult: 1.0,
    scoreMultiplier: 1.0,
  },
  {
    id: 'hard',
    name: 'Inquisitor',
    desc: 'Merciless carnage, 2× score',
    icon: '💀',
    playerHealthMult: 0.7,
    enemyHealthMult: 1.5,
    enemyDamageMult: 1.5,
    enemyCountMult: 1.3,
    scoreMultiplier: 2.0,
  },
];

export const CHARACTERS: CharacterDef[] = [
  {
    id: 'hunter',
    name: 'The Hunter',
    subtitle: 'Unnamed Vampire Hunter',
    flavor: '"Unnamed. Relentless. Armed with silver and faith."',
    icon: '🎯',
    color: '#f59e0b',
    accentColor: '#fcd34d',
    bgClass: 'char-card-hunter',
    weapon: 'pistol',
    stats: { maxHealth: 100, speed: 1.0, regen: 0, damage: 1.0, fireRate: 1.0, noLimits: false, vampiricRegen: false },
    abilities: [
      { id: 'dash', name: 'Shadow Dash', desc: 'Dash in movement direction — brief invulnerability', cooldown: 4, type: 'normal', icon: '💨' },
      { id: 'holy_burst', name: 'Holy Burst', desc: 'Radial silver explosion around you', cooldown: 12, type: 'special', icon: '✨' },
    ],
    trait: 'Human Grit — no passive bonuses. Pure skill.',
  },
  {
    id: 'alucard',
    name: 'Alucard',
    subtitle: 'No-Life King · Hellsing',
    flavor: '"I am the bird of Hermes, eating my wings to make me tame."',
    icon: '🧛',
    color: '#dc2626',
    accentColor: '#fca5a5',
    bgClass: 'char-card-alucard',
    weapon: 'dual_pistol',
    stats: { maxHealth: 120, speed: 1.1, regen: 1.5, damage: 1.3, fireRate: 1.4, noLimits: true, vampiricRegen: true },
    abilities: [
      { id: 'shadow_step', name: 'Shadow Step', desc: 'Teleport behind the nearest enemy', cooldown: 2.5, type: 'normal', icon: '🌑' },
      { id: 'hell_hound', name: 'Hell Hound', desc: 'Release Baskerville — summon a raging shadow wolf', cooldown: 8, type: 'normal', icon: '🐺' },
      { id: 'restriction_0', name: 'Restriction Release', desc: 'Remove all limits — cooldowns halved for 15 seconds', cooldown: 30, type: 'special', icon: '🔓' },
      { id: 'level_0', name: 'Level Zero', desc: 'Summon the souls of all his victims — devastating radial strike', cooldown: 45, type: 'special', icon: '💀' },
    ],
    trait: 'No Limits: ability cooldowns halved globally. Vampiric Regen: heals 10% of damage dealt.',
  },
  {
    id: 'integra',
    name: 'Sir Integra',
    subtitle: 'Director · Hellsing Organization',
    flavor: '"I give the orders here." Commands armies. Commands monsters.',
    icon: '👓',
    color: '#3b82f6',
    accentColor: '#93c5fd',
    bgClass: 'char-card-integra',
    weapon: 'pistol',
    stats: { maxHealth: 90, speed: 0.95, regen: 0, damage: 1.0, fireRate: 0.9, noLimits: false, vampiricRegen: false },
    abilities: [
      { id: 'summon_familiar', name: 'Familiar', desc: 'Summon a vampire minion to fight at your side', cooldown: 6, type: 'normal', icon: '🦇' },
      { id: 'round_table', name: 'Round Table Order', desc: 'Summon an elite vampire warrior', cooldown: 18, type: 'normal', icon: '⚔️' },
      { id: 'hellsing_protocol', name: 'Hellsing Protocol', desc: 'Summon Alucard himself — 5 phantom soldiers for 8 seconds', cooldown: 40, type: 'special', icon: '🧛' },
    ],
    trait: 'Command Aura: all summoned minions deal 30% more damage.',
  },
  {
    id: 'walter',
    name: 'Walter C. Dornez',
    subtitle: 'Angel of Death · Hellsing Butler',
    flavor: '"The butler did it." WWII operative. Wires that cut through steel, aircraft, and time.',
    icon: '🕸️',
    color: '#9ca3af',
    accentColor: '#e5e7eb',
    bgClass: 'char-card-walter',
    weapon: 'wire',
    stats: { maxHealth: 85, speed: 1.2, regen: 0.5, damage: 1.2, fireRate: 1.3, noLimits: false, vampiricRegen: false },
    abilities: [
      { id: 'wire_cage', name: 'Wire Cage', desc: 'Trap all nearby enemies in razor wire — 2s stun + continuous damage', cooldown: 7, type: 'normal', icon: '🕸️' },
      { id: 'decapitation', name: 'Decapitation Wire', desc: 'Instant-kill any enemy below 40% HP with a precision wire slash', cooldown: 10, type: 'normal', icon: '✂️' },
      { id: 'angel_mode', name: 'Angel of Death', desc: 'Surge of speed and damage — wires extend across the entire room for 8s', cooldown: 35, type: 'special', icon: '👼' },
    ],
    trait: 'Chain Cut: wire attacks bounce to 2 additional nearby enemies. No firearms.',
  },
  {
    id: 'seras',
    name: 'Seras Victoria',
    subtitle: 'Draculina · Former Police Officer',
    flavor: '"I am still a police officer." ...And a vampire. The Harkonnen says otherwise.',
    icon: '🔫',
    color: '#8b5cf6',
    accentColor: '#c4b5fd',
    bgClass: 'char-card-seras',
    weapon: 'rifle',
    stats: { maxHealth: 110, speed: 0.95, regen: 0.8, damage: 1.5, fireRate: 0.7, noLimits: false, vampiricRegen: true },
    abilities: [
      { id: 'vampire_strike', name: 'Vampire Strike', desc: 'Devastating melee slam — sends enemies flying', cooldown: 5, type: 'normal', icon: '👊' },
      { id: 'blood_release', name: 'Blood Release', desc: 'Drink shadow blood — all stats boosted for 8 seconds', cooldown: 20, type: 'normal', icon: '🩸' },
      { id: 'shadow_wing', name: 'Shadow Wing Dive', desc: 'Burst-dash through aim direction, destroying all enemies in path', cooldown: 12, type: 'special', icon: '🦇' },
    ],
    trait: 'Draculina: heals 15% of damage dealt. Rifle has double damage at long range.',
  },
  {
    id: 'anderson',
    name: 'Alexander Anderson',
    subtitle: 'Paladin · Iscariot Section XIII',
    flavor: '"Amen." Bayonets from nowhere. A monster that hunts monsters with scripture and steel.',
    icon: '✝️',
    color: '#d97706',
    accentColor: '#fef3c7',
    bgClass: 'char-card-anderson',
    weapon: 'bayonet',
    stats: { maxHealth: 130, speed: 0.9, regen: 4.0, damage: 1.1, fireRate: 0.8, noLimits: false, vampiricRegen: false },
    abilities: [
      { id: 'holy_barrier', name: 'Holy Barrier', desc: 'Sacred shield — blocks all projectiles for 4 seconds', cooldown: 14, type: 'normal', icon: '🛡️' },
      { id: 'nail_helena', name: 'Nail of Saint Helena', desc: 'Piercing holy lance — destroys everything in a straight line', cooldown: 18, type: 'normal', icon: '📌' },
      { id: 'blessed_regen', name: 'Blessed Regeneration', desc: 'Instantly restore 60 HP through holy scripture', cooldown: 25, type: 'special', icon: '💚' },
      { id: 'regenerator_form', name: 'Regenerator Form', desc: '10 seconds: 20 HP/s regen and complete stagger immunity', cooldown: 50, type: 'special', icon: '🌟' },
    ],
    trait: 'Paladin: 4 HP/s passive regen. Immune to all debuffs. Cannot use firearms.',
  },
];
