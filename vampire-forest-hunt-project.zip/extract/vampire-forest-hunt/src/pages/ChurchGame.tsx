import React, { useEffect, useRef, useState } from 'react';
import { useChurchLoop, CHURCH_RELICS, computeChurchRelicEffects } from '@/hooks/useChurchLoop';
import { CHARACTERS, DIFFICULTIES } from '@/data/characters';
import type { CharacterId, DifficultyId } from '@/data/characters';
import type { ChurchRelicId } from '@/hooks/useChurchLoop';
import { CHURCH_ENDINGS } from '@/data/endings';

type PointerPoint = { x: number; y: number };

const ROOM_COLORS: Record<string, string> = {
  start: '#22c55e',
  normal: '#6b7280',
  elite: '#a21caf',
  item: '#d97706',
  gargant: '#4f46e5',
  gauntlet: '#b45309',
  boss: '#dc2626',
};

const BLEACH_DIALOGUE = [
  "⊡  A Soul Reaper materializes from the shadows...  ⊡",
  "\"Hmm... you don't look like a Hollow to me.\"",
  '"...Eh. Close enough." *opens Garganta*',
];

const candlePositions = [
  { x: 100, y: 120 }, { x: 1100, y: 120 },
  { x: 100, y: 680 }, { x: 1100, y: 680 },
  { x: 600, y: 120 }, { x: 600, y: 680 },
  { x: 200, y: 400 }, { x: 1000, y: 400 },
];

export default function ChurchGame({
  onBack,
  characterId,
  difficultyId,
}: {
  onBack: () => void;
  characterId: CharacterId;
  difficultyId: DifficultyId;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const movPtrRef = useRef<number | null>(null);
  const firePtrRef = useRef<number | null>(null);
  const movOriginRef = useRef<PointerPoint>({ x: 0, y: 0 });
  const [worldScale, setWorldScale] = useState({ x: 1, y: 1 });
  const hasStarted = useRef(false);

  const {
    churchState, startChurch, acceptRelic, rejectRelic,
    setTouchMovement, setAimPosition, setFiring, activateAbility,
    GAME_WIDTH, GAME_HEIGHT, GRID_COLS, GRID_ROWS,
  } = useChurchLoop();

  useEffect(() => {
    if (!hasStarted.current) {
      hasStarted.current = true;
      startChurch(characterId, difficultyId);
    }
  }, [startChurch, characterId, difficultyId]);

  useEffect(() => {
    const updateScale = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      setWorldScale({ x: rect.width / GAME_WIDTH, y: rect.height / GAME_HEIGHT });
    };
    updateScale();
    const obs = new ResizeObserver(updateScale);
    if (containerRef.current) obs.observe(containerRef.current);
    window.addEventListener('resize', updateScale);
    return () => { obs.disconnect(); window.removeEventListener('resize', updateScale); };
  }, [GAME_WIDTH, GAME_HEIGHT]);

  const getScaledPoint = (clientX: number, clientY: number) => {
    if (!containerRef.current) return null;
    const rect = containerRef.current.getBoundingClientRect();
    return {
      screen: { x: clientX - rect.left, y: clientY - rect.top },
      world: { x: (clientX - rect.left) * (GAME_WIDTH / rect.width), y: (clientY - rect.top) * (GAME_HEIGHT / rect.height) },
      rect,
    };
  };

  const updateMovement = (clientX: number, clientY: number) => {
    const dx = clientX - movOriginRef.current.x;
    const dy = clientY - movOriginRef.current.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < 6) return;
    const max = 56;
    setTouchMovement({ x: Math.max(-1, Math.min(1, dx / max)), y: Math.max(-1, Math.min(1, dy / max)) });
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    const pt = getScaledPoint(e.clientX, e.clientY);
    if (!pt) return;
    if (e.pointerType === 'mouse') {
      setAimPosition(pt.world);
      setFiring(true);
      return;
    }
    if (movPtrRef.current === null && pt.screen.x < pt.rect.width * 0.45) {
      movPtrRef.current = e.pointerId;
      movOriginRef.current = { x: e.clientX, y: e.clientY };
    } else if (firePtrRef.current === null) {
      firePtrRef.current = e.pointerId;
      setAimPosition(pt.world);
      setFiring(true);
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    const pt = getScaledPoint(e.clientX, e.clientY);
    if (!pt) return;
    if (e.pointerType === 'mouse') { setAimPosition(pt.world); return; }
    if (e.pointerId === movPtrRef.current) updateMovement(e.clientX, e.clientY);
    if (e.pointerId === firePtrRef.current) setAimPosition(pt.world);
  };

  const releasePointer = (id: number) => {
    if (movPtrRef.current === id) { movPtrRef.current = null; setTouchMovement({ x: 0, y: 0 }); }
    if (firePtrRef.current === id) { firePtrRef.current = null; setFiring(false); }
  };

  const { currentRoomPos, roomGrid } = churchState;
  const curRoom = roomGrid[currentRoomPos.row]?.[currentRoomPos.col];
  const cardinal = churchState.enemies.find(e => e.kind === 'cardinal');
  const char = CHARACTERS.find(c => c.id === characterId)!;
  const diff = DIFFICULTIES.find(d => d.id === difficultyId)!;
  const relicFx = computeChurchRelicEffects(churchState.relics);
  const pendingDef = churchState.pendingRelic ? CHURCH_RELICS.find(r => r.id === churchState.pendingRelic) : null;

  const hasDoorNorth = !!curRoom?.connections.north;
  const hasDoorSouth = !!curRoom?.connections.south;
  const hasDoorEast = !!curRoom?.connections.east;
  const hasDoorWest = !!curRoom?.connections.west;
  const isCleared = !!curRoom?.cleared || curRoom?.type === 'start';

  const roomBg: Record<string, string> = {
    start: '#0f1b0f',
    normal: '#130e1a',
    elite: '#1a0820',
    item: '#1a1200',
    gargant: '#070a1f',
    gauntlet: '#1a0a00',
    boss: '#1a0000',
  };
  const currentBg = roomBg[curRoom?.type ?? 'normal'] ?? '#130e1a';

  return (
    <div className="game-shell relative bg-black flex items-center justify-center crt">
      <div
        ref={containerRef}
        className="game-stage relative overflow-hidden vignette select-none"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={e => releasePointer(e.pointerId)}
        onPointerCancel={e => releasePointer(e.pointerId)}
        onPointerLeave={e => { if (e.pointerType === 'mouse') setFiring(false); }}
      >
        <div
          className="game-world absolute left-0 top-0"
          style={{ width: GAME_WIDTH, height: GAME_HEIGHT, transform: `scale(${worldScale.x}, ${worldScale.y})`, transformOrigin: '0 0' }}
        >
          {/* Church room background */}
          <div className="absolute inset-0 church-floor" style={{ background: currentBg }} />
          <div className="absolute inset-0 church-walls" />
          <div className="absolute inset-0 church-tiles" />

          {/* Stained glass windows */}
          <div className="church-window church-window-left absolute" />
          <div className="church-window church-window-right absolute" />

          {/* Candles */}
          {candlePositions.map((c, i) => (
            <div key={i} className="church-candle absolute" style={{ left: c.x, top: c.y }} />
          ))}

          {/* Hazard beams (gauntlet room) */}
          {churchState.hazardBeams.map(beam => (
            <div
              key={beam.id}
              className={`church-hazard-beam ${beam.axis === 'h' ? 'beam-h' : 'beam-v'} ${beam.active ? 'beam-active' : beam.warning ? 'beam-warning' : ''}`}
              style={
                beam.axis === 'h'
                  ? { top: beam.position - beam.thickness / 2, left: 0, right: 0, height: beam.thickness }
                  : { left: beam.position - beam.thickness / 2, top: 0, bottom: 0, width: beam.thickness }
              }
            />
          ))}

          {/* Doors */}
          {hasDoorNorth && (
            <div className={`church-door church-door-north absolute ${isCleared ? 'door-open' : 'door-closed'}`} />
          )}
          {hasDoorSouth && (
            <div className={`church-door church-door-south absolute ${isCleared ? 'door-open' : 'door-closed'}`} />
          )}
          {hasDoorEast && (
            <div className={`church-door church-door-east absolute ${isCleared ? 'door-open' : 'door-closed'}`} />
          )}
          {hasDoorWest && (
            <div className={`church-door church-door-west absolute ${isCleared ? 'door-open' : 'door-closed'}`} />
          )}

          {/* Item pedestal */}
          {curRoom?.type === 'item' && curRoom.itemId && !curRoom.cleared && (
            <div className="church-pedestal absolute" style={{ left: GAME_WIDTH / 2, top: GAME_HEIGHT / 2 }}>
              <div className="pedestal-glow" />
              <div className="pedestal-item">✟</div>
            </div>
          )}

          {/* Gargant room decor */}
          {curRoom?.type === 'gargant' && (
            <div className="gargant-room-decor absolute inset-0" />
          )}

          {/* Gauntlet room decor */}
          {curRoom?.type === 'gauntlet' && (
            <>
              <div className="gauntlet-pillar absolute" style={{ left: 150, top: 150 }} />
              <div className="gauntlet-pillar absolute" style={{ left: 150, top: 600 }} />
              <div className="gauntlet-pillar absolute" style={{ left: 1050, top: 150 }} />
              <div className="gauntlet-pillar absolute" style={{ left: 1050, top: 600 }} />
            </>
          )}

          {churchState.status === 'playing' && (
            <>
              {/* Player */}
              <div
                className={`church-player absolute transform -translate-x-1/2 -translate-y-1/2 char-${characterId}`}
                style={{ left: churchState.player.pos.x, top: churchState.player.pos.y, width: churchState.player.radius * 2, height: churchState.player.radius * 2 }}
              >
                {churchState.abilities.shieldActive && (
                  <div className="church-shield-ring absolute rounded-full pointer-events-none" />
                )}
                {(churchState.abilities.bloodReleaseUntil > Date.now() || churchState.abilities.angelModeUntil > Date.now()) && (
                  <div className="power-aura absolute rounded-full pointer-events-none" style={{
                    background: churchState.abilities.bloodReleaseUntil > Date.now()
                      ? 'radial-gradient(circle, rgba(139,0,0,0.6) 0%, transparent 70%)'
                      : 'radial-gradient(circle, rgba(220,220,255,0.5) 0%, transparent 70%)',
                  }} />
                )}
              </div>

              {/* Summons */}
              {churchState.summons.map(s => (
                <div
                  key={s.id}
                  className={`church-summon summon-${s.kind} absolute transform -translate-x-1/2 -translate-y-1/2`}
                  style={{ left: s.pos.x, top: s.pos.y, width: s.radius * 2, height: s.radius * 2 }}
                />
              ))}

              {/* Bullets */}
              {churchState.bullets.map(b => (
                <div
                  key={b.id}
                  className={`${b.fromEnemy ? 'holy-bolt' : b.piercing ? 'church-nail' : 'church-bullet'} absolute rounded-full transform -translate-x-1/2 -translate-y-1/2`}
                  style={{ left: b.pos.x, top: b.pos.y, width: b.radius * 2, height: b.radius * 2 }}
                />
              ))}

              {/* Enemies */}
              {churchState.enemies.map(e => (
                <div
                  key={e.id}
                  className={`church-enemy enemy-${e.kind} absolute transform -translate-x-1/2 -translate-y-1/2`}
                  style={{ left: e.pos.x, top: e.pos.y, width: e.radius * 2, height: e.radius * 2 }}
                >
                  <div className="enemy-body" />
                  <div className="vampire-health">
                    <div style={{ width: `${Math.max(0, (e.health / e.maxHealth) * 100)}%` }} />
                  </div>
                  {e.kind === 'cardinal' && <div className="cardinal-halo" />}
                  {e.kind === 'cardinal' && e.phase === 2 && <div className="cardinal-wings" />}
                  {e.kind === 'fallen_angel' && <div className="fallen-wings" />}
                </div>
              ))}
            </>
          )}
        </div>

        {/* ── HUD ── */}
        {churchState.status === 'playing' && (
          <>
            <div className="game-hud-score absolute text-white font-mono z-10">
              <div className="score-label mb-1 font-serif italic" style={{ color: '#fcd34d' }}>
                SCORE: {churchState.score.toString().padStart(6, '0')}
              </div>
              <div className="wave-label" style={{ color: 'rgba(253,224,71,0.85)' }}>LIGHT CHURCH</div>
              <div className="coin-label mt-1" style={{ color: 'rgba(253,224,71,0.7)' }}>RELICS: {churchState.relics.length}</div>
              <div className="coin-label mt-1" style={{ color: char.color, opacity: 0.85 }}>{char.name}</div>
              <div className="coin-label" style={{ color: diff.id === 'hard' ? '#ef4444' : diff.id === 'easy' ? '#86efac' : '#fbbf24', opacity: 0.7 }}>{diff.name.toUpperCase()}</div>
              {churchState.roomMessage && (
                <div className="mansion-room-msg mt-2">{churchState.roomMessage}</div>
              )}
            </div>

            <div className="game-hud-health absolute z-10">
              <div className="text-xs mb-1 text-right" style={{ color: 'rgba(253,224,71,0.85)' }}>FAITH</div>
              <div className="h-2 w-full border" style={{ background: 'rgba(30,25,0,0.9)', borderColor: 'rgba(253,224,71,0.4)' }}>
                <div className="h-full transition-all duration-200" style={{ width: `${Math.max(0, (churchState.player.health / churchState.player.maxHealth) * 100)}%`, background: 'linear-gradient(90deg, #78350f, #d97706, #fcd34d)' }} />
              </div>
              <div className="text-right text-xs mt-1" style={{ color: 'rgba(253,224,71,0.5)' }}>
                {Math.round(churchState.player.health)}/{churchState.player.maxHealth}
              </div>
            </div>

            {/* Boss bar */}
            {cardinal && (
              <div className="boss-hud absolute z-10 text-center font-mono">
                <div className="boss-name" style={{ color: cardinal.phase === 2 ? '#fbbf24' : '#fde68a', fontStyle: 'italic' }}>{churchState.bossMessage}</div>
                <div className="boss-bar">
                  <div style={{ width: `${Math.max(0, (cardinal.health / cardinal.maxHealth) * 100)}%`, background: cardinal.phase === 2 ? 'linear-gradient(90deg, #78350f, #f59e0b, #fde68a)' : 'linear-gradient(90deg, #1c1400, #d97706, #fcd34d)' }} />
                </div>
                {cardinal.phase === 2 && <div className="boss-warning" style={{ color: '#fbbf24' }}>PHASE II — DIVINE WRATH UNLEASHED</div>}
              </div>
            )}

            {/* Abilities panel */}
            <div className="ability-panel absolute z-10 font-mono">
              {char.abilities.map((abil, i) => {
                const cd = churchState.abilities.cooldowns[i];
                const ready = cd <= 0;
                return (
                  <button
                    key={abil.id}
                    type="button"
                    className={`ability-button church-btn ${ready ? 'ready' : 'cooling'} ${abil.type === 'special' ? 'special-ability' : ''}`}
                    onPointerDown={ev => { ev.preventDefault(); ev.stopPropagation(); activateAbility(i); }}
                    title={abil.desc}
                  >
                    <span>{abil.icon} {abil.name}</span>
                    <strong>{ready ? 'READY' : `${Math.ceil(cd / 1000)}s`}</strong>
                  </button>
                );
              })}
            </div>

            {/* Summon count for Integra */}
            {characterId === 'integra' && churchState.summons.length > 0 && (
              <div className="absolute z-10 font-mono text-xs" style={{ bottom: 80, right: 20, color: '#93c5fd' }}>
                MINIONS: {churchState.summons.length}
              </div>
            )}

            {/* Minimap */}
            <div className="mansion-minimap absolute z-10">
              <div className="minimap-label">MAP</div>
              <div className="minimap-grid" style={{ gridTemplateColumns: `repeat(${GRID_COLS}, 16px)` }}>
                {Array.from({ length: GRID_ROWS }, (_, row) =>
                  Array.from({ length: GRID_COLS }, (_, col) => {
                    const room = roomGrid[row]?.[col];
                    const isCur = col === currentRoomPos.col && row === currentRoomPos.row;
                    if (!room) return <div key={`${col}-${row}`} className="minimap-empty" />;
                    if (!room.visited && !isCur) return <div key={`${col}-${row}`} className="minimap-unvisited" />;
                    const color = ROOM_COLORS[room.type] ?? '#6b7280';
                    return (
                      <div
                        key={`${col}-${row}`}
                        className="minimap-room"
                        style={{
                          background: color,
                          outline: isCur ? '2px solid #fcd34d' : 'none',
                          opacity: room.cleared ? 0.5 : 1,
                        }}
                      />
                    );
                  })
                )}
              </div>
            </div>

            {/* Relic chips */}
            {churchState.relics.length > 0 && (
              <div className="relic-chips absolute z-10">
                {churchState.relics.map(id => {
                  const def = CHURCH_RELICS.find(r => r.id === id);
                  return def ? (
                    <div key={id} className="relic-chip" title={`${def.name}: ${def.buff} / ${def.debuff}`} style={{ borderColor: '#d97706' }}>
                      {def.name.slice(0, 8)}
                    </div>
                  ) : null;
                })}
              </div>
            )}

            {/* Active effects indicators */}
            <div className="absolute z-10 font-mono text-xs flex gap-2" style={{ top: 120, left: 20 }}>
              {churchState.abilities.restrictionUntil > Date.now() && <span style={{ color: '#f87171' }}>⚡ NO LIMITS</span>}
              {churchState.abilities.bloodReleaseUntil > Date.now() && <span style={{ color: '#f43f5e' }}>🩸 RELEASE</span>}
              {churchState.abilities.angelModeUntil > Date.now() && <span style={{ color: '#e2e8f0' }}>👼 ANGEL MODE</span>}
              {churchState.abilities.regeneratorUntil > Date.now() && <span style={{ color: '#4ade80' }}>🌟 REGEN FORM</span>}
            </div>
          </>
        )}

        {/* ── GARGANT JOKE OVERLAY ── */}
        {churchState.status === 'gargant_joke' && (
          <div className="absolute inset-0 gargant-overlay flex flex-col items-center justify-center z-30">
            <div className="gargant-reaper">⚔</div>
            <div className="gargant-dialogue-box">
              {BLEACH_DIALOGUE.slice(0, churchState.dialogueLine + 1).map((line, i) => (
                <div key={i} className={`gargant-line ${i === churchState.dialogueLine ? 'gargant-line-active' : 'gargant-line-old'}`}>
                  {line}
                </div>
              ))}
            </div>
            {churchState.dialogueLine >= 2 && (
              <div className="gargant-portal-anim mt-8">
                <div className="gargant-portal-ring" />
                <div className="gargant-portal-inner" />
              </div>
            )}
          </div>
        )}

        {/* ── RELIC PICKUP ── */}
        {churchState.status === 'item_pickup' && pendingDef && (
          <div className="absolute inset-0 bg-black/75 flex items-center justify-center z-30">
            <div className="relic-pickup-panel" style={{ borderColor: '#d97706' }}>
              <div className="relic-pickup-title" style={{ color: '#fcd34d' }}>✟ Sacred Relic Found</div>
              <div className="relic-pickup-name" style={{ color: '#fcd34d' }}>{pendingDef.name}</div>
              <div className="relic-pickup-flavor">{pendingDef.flavor}</div>
              <div className="relic-pickup-effects">
                <div className="relic-buff">✦ {pendingDef.buff}</div>
                <div className="relic-debuff">✗ {pendingDef.debuff}</div>
              </div>
              <div className="flex gap-3 mt-4">
                <button className="game-button bg-amber-900/40 border border-amber-500/60 text-amber-100 font-mono hover:bg-amber-800/60 transition-all text-sm px-4 py-2" onClick={acceptRelic}>
                  Take Relic
                </button>
                <button className="game-button bg-slate-900/40 border border-slate-500/40 text-slate-300 font-mono hover:bg-slate-700/40 transition-all text-sm px-4 py-2" onClick={rejectRelic}>
                  Leave It
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ── VICTORY ── */}
        {churchState.status === 'victory' && (() => {
          const ending = CHURCH_ENDINGS[characterId];
          return (
            <div className="absolute inset-0 flex flex-col items-center justify-center z-30 text-center px-5" style={{ background: 'radial-gradient(circle at 50% 35%, rgba(120,90,0,0.45), transparent 55%), rgba(0,0,0,0.92)' }}>
              <div className="font-mono text-xs uppercase tracking-widest mb-2" style={{ color: 'rgba(253,224,71,0.55)', letterSpacing: '0.3em' }}>✝ {ending.subtitle} ✝</div>
              <h2 className="game-over-title font-serif mb-4 italic tracking-widest" style={{ color: '#fcd34d', textShadow: '0 0 40px rgba(253,224,71,0.6)' }}>
                {ending.title}
              </h2>
              <div className="mb-4 max-w-md" style={{ background: 'rgba(0,0,0,0.4)', borderRadius: 8, padding: '14px 20px', border: '1px solid rgba(253,224,71,0.15)' }}>
                {ending.lines.map((line, i) => (
                  <p key={i} className="font-serif mb-1 text-sm leading-relaxed" style={{ color: i === 0 ? 'rgba(253,224,71,0.85)' : 'rgba(253,230,138,0.65)', fontStyle: line.startsWith('"') ? 'italic' : 'normal' }}>{line}</p>
                ))}
              </div>
              <div className="text-amber-100 font-mono mb-1 text-lg">SCORE: {churchState.score.toString().padStart(6, '0')}</div>
              <div className="text-amber-400/60 font-mono text-xs mb-6">{char.name} · {diff.name}</div>
              <button
                onClick={() => startChurch(characterId, difficultyId)}
                className="game-button bg-amber-500/10 border border-amber-300/60 text-amber-100 font-mono hover:bg-amber-900/50 hover:text-white transition-all hover:scale-105 uppercase tracking-widest mb-4"
              >
                Play Again
              </button>
              <button onClick={onBack} className="text-amber-300/50 font-mono text-sm hover:text-amber-200/80 transition-colors uppercase tracking-widest">
                ← Choose Mode
              </button>
            </div>
          );
        })()}

        {/* ── GAME OVER ── */}
        {churchState.status === 'gameover' && (
          <div className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center z-30 text-center">
            <h2 className="game-over-title font-serif text-red-500 mb-4 italic tracking-widest">CONSUMED BY LIGHT</h2>
            <div className="text-amber-100 font-mono mb-2 text-xl">SCORE: {churchState.score.toString().padStart(6, '0')}</div>
            <div className="text-amber-400/50 font-mono text-sm mb-8">{char.name} · {diff.name}</div>
            <button
              onClick={() => startChurch(characterId, difficultyId)}
              className="game-button bg-amber-500/10 border border-amber-300/60 text-amber-100 font-mono hover:bg-red-900/50 hover:text-white transition-all hover:scale-105 uppercase tracking-widest mb-4"
            >
              Try Again
            </button>
            <button onClick={onBack} className="text-amber-300/50 font-mono text-sm hover:text-amber-200/80 transition-colors uppercase tracking-widest">
              ← Choose Mode
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
