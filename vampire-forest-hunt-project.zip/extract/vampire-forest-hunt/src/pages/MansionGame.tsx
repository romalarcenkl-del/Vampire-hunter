import React, { useEffect, useRef, useState } from 'react';
import { useMansionLoop, ALL_RELICS, computeRelicEffects } from '@/hooks/useMansionLoop';
import type { RelicId } from '@/hooks/useMansionLoop';
import type { CharacterId, DifficultyId } from '@/data/characters';
import { CHARACTERS, DIFFICULTIES } from '@/data/characters';
import { MANSION_ENDINGS } from '@/data/endings';

type PointerPoint = { x: number; y: number };

const ROOM_COLORS: Record<string, string> = {
  start: '#22c55e',
  normal: '#6b7280',
  elite: '#7c3aed',
  item: '#f59e0b',
  boss: '#dc2626',
};

const torchPositions = [
  { x: 130, y: 130 }, { x: 1070, y: 130 },
  { x: 130, y: 670 }, { x: 1070, y: 670 },
  { x: 600, y: 130 }, { x: 600, y: 670 },
];

export default function MansionGame({
  onBack,
  characterId = 'hunter',
  difficultyId = 'normal',
}: {
  onBack: () => void;
  characterId?: CharacterId;
  difficultyId?: DifficultyId;
}) {
  const char = CHARACTERS.find(c => c.id === characterId) ?? CHARACTERS[0];
  const diff = DIFFICULTIES.find(d => d.id === difficultyId) ?? DIFFICULTIES[1];
  const containerRef = useRef<HTMLDivElement>(null);
  const movPtrRef = useRef<number | null>(null);
  const firePtrRef = useRef<number | null>(null);
  const movOriginRef = useRef<PointerPoint>({ x: 0, y: 0 });
  const [worldScale, setWorldScale] = useState({ x: 1, y: 1 });

  const {
    mansionState, startMansion, acceptRelic,
    setTouchMovement, setAimPosition, setFiring,
    activateDash, activateHolyBurst, switchWeapon,
    GAME_WIDTH, GAME_HEIGHT, GRID_COLS, GRID_ROWS,
  } = useMansionLoop();

  useEffect(() => {
    const updateScale = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      setWorldScale({ x: rect.width / GAME_WIDTH, y: rect.height / GAME_HEIGHT });
    };
    updateScale();
    const obs = new ResizeObserver(updateScale);
    if (containerRef.current) obs.observe(containerRef.current);
    window.addEventListener('resize', updateScale);
    return () => { obs.disconnect(); window.removeEventListener('resize', updateScale); };
  }, [GAME_WIDTH, GAME_HEIGHT]);

  const getScaledPoint = (clientX: number, clientY: number) => {
    if (!containerRef.current) return null;
    const rect = containerRef.current.getBoundingClientRect();
    return {
      screen: { x: clientX - rect.left, y: clientY - rect.top },
      world: { x: (clientX - rect.left) * (GAME_WIDTH / rect.width), y: (clientY - rect.top) * (GAME_HEIGHT / rect.height) },
      rect,
    };
  };

  const updateMovement = (clientX: number, clientY: number) => {
    const dx = clientX - movOriginRef.current.x;
    const dy = clientY - movOriginRef.current.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < 6) { setTouchMovement({ x: 0, y: 0 }); return; }
    const str = Math.min(1, dist / 56);
    setTouchMovement({ x: (dx / dist) * str, y: (dy / dist) * str });
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (mansionState.status !== 'playing') return;
    const pt = getScaledPoint(e.clientX, e.clientY);
    if (!pt) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    if (e.pointerType !== 'mouse' && pt.screen.x < pt.rect.width * 0.48) {
      movPtrRef.current = e.pointerId;
      movOriginRef.current = { x: e.clientX, y: e.clientY };
      updateMovement(e.clientX, e.clientY);
      return;
    }
    firePtrRef.current = e.pointerId;
    setAimPosition(pt.world);
    setFiring(true);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const pt = getScaledPoint(e.clientX, e.clientY);
    if (!pt) return;
    if (e.pointerType === 'mouse') { setAimPosition(pt.world); return; }
    if (movPtrRef.current === e.pointerId) { e.preventDefault(); updateMovement(e.clientX, e.clientY); return; }
    if (firePtrRef.current === e.pointerId) { e.preventDefault(); setAimPosition(pt.world); }
  };

  const releasePointer = (id: number) => {
    if (movPtrRef.current === id) { movPtrRef.current = null; setTouchMovement({ x: 0, y: 0 }); }
    if (firePtrRef.current === id) { firePtrRef.current = null; setFiring(false); }
  };

  const { currentRoomPos, roomGrid } = mansionState;
  const curRoom = roomGrid[currentRoomPos.row]?.[currentRoomPos.col];
  const vladros = mansionState.enemies.find(e => e.kind === 'vladros');
  const dashReady = mansionState.abilities.dashCooldown <= 0;
  const burstReady = mansionState.abilities.burstCooldown <= 0;
  const pendingDef = mansionState.pendingRelic ? ALL_RELICS.find(r => r.id === mansionState.pendingRelic) : null;
  const relicFx = computeRelicEffects(mansionState.relics);

  const hasDoorNorth = !!curRoom?.connections.north;
  const hasDoorSouth = !!curRoom?.connections.south;
  const hasDoorEast = !!curRoom?.connections.east;
  const hasDoorWest = !!curRoom?.connections.west;
  const isCleared = !!curRoom?.cleared;

  return (
    <div className="game-shell relative bg-black flex items-center justify-center crt">
      <div
        ref={containerRef}
        className="game-stage relative overflow-hidden select-none"
        style={{ cursor: 'crosshair' }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={e => releasePointer(e.pointerId)}
        onPointerCancel={e => releasePointer(e.pointerId)}
        onPointerLeave={e => { if (e.pointerType === 'mouse') setFiring(false); }}
      >
        <div
          className="game-world absolute left-0 top-0"
          style={{ width: GAME_WIDTH, height: GAME_HEIGHT, transform: `scale(${worldScale.x}, ${worldScale.y})` }}
        >
          <div className="mansion-floor absolute inset-0" />

          {/* North wall */}
          {hasDoorNorth ? (
            <>
              <div className="mansion-wall-solid absolute" style={{ top: 0, left: 0, width: 520, height: 52 }} />
              <div className="mansion-wall-solid absolute" style={{ top: 0, right: 0, width: 520, height: 52 }} />
              <div className={`mansion-door ${isCleared ? 'mansion-door-open' : 'mansion-door-closed'} absolute`} style={{ top: 0, left: '50%', transform: 'translateX(-50%)', width: 160, height: 52 }} />
            </>
          ) : (
            <div className="mansion-wall-solid absolute" style={{ top: 0, left: 0, right: 0, height: 52 }} />
          )}

          {/* South wall */}
          {hasDoorSouth ? (
            <>
              <div className="mansion-wall-solid absolute" style={{ bottom: 0, left: 0, width: 520, height: 52 }} />
              <div className="mansion-wall-solid absolute" style={{ bottom: 0, right: 0, width: 520, height: 52 }} />
              <div className={`mansion-door ${isCleared ? 'mansion-door-open' : 'mansion-door-closed'} absolute`} style={{ bottom: 0, left: '50%', transform: 'translateX(-50%)', width: 160, height: 52 }} />
            </>
          ) : (
            <div className="mansion-wall-solid absolute" style={{ bottom: 0, left: 0, right: 0, height: 52 }} />
          )}

          {/* West wall */}
          {hasDoorWest ? (
            <>
              <div className="mansion-wall-solid absolute" style={{ top: 0, left: 0, height: 340, width: 52 }} />
              <div className="mansion-wall-solid absolute" style={{ bottom: 0, left: 0, height: 340, width: 52 }} />
              <div className={`mansion-door ${isCleared ? 'mansion-door-open' : 'mansion-door-closed'} absolute`} style={{ top: '50%', left: 0, transform: 'translateY(-50%)', width: 52, height: 120 }} />
            </>
          ) : (
            <div className="mansion-wall-solid absolute" style={{ top: 0, bottom: 0, left: 0, width: 52 }} />
          )}

          {/* East wall */}
          {hasDoorEast ? (
            <>
              <div className="mansion-wall-solid absolute" style={{ top: 0, right: 0, height: 340, width: 52 }} />
              <div className="mansion-wall-solid absolute" style={{ bottom: 0, right: 0, height: 340, width: 52 }} />
              <div className={`mansion-door ${isCleared ? 'mansion-door-open' : 'mansion-door-closed'} absolute`} style={{ top: '50%', right: 0, transform: 'translateY(-50%)', width: 52, height: 120 }} />
            </>
          ) : (
            <div className="mansion-wall-solid absolute" style={{ top: 0, bottom: 0, right: 0, width: 52 }} />
          )}

          {/* Corner reinforcements */}
          <div className="mansion-corner absolute" style={{ top: 0, left: 0 }} />
          <div className="mansion-corner absolute" style={{ top: 0, right: 0, transform: 'scaleX(-1)' }} />
          <div className="mansion-corner absolute" style={{ bottom: 0, left: 0, transform: 'scaleY(-1)' }} />
          <div className="mansion-corner absolute" style={{ bottom: 0, right: 0, transform: 'scale(-1)' }} />

          {/* Torches */}
          {torchPositions.map((t, i) => (
            <div key={i} className="mansion-torch absolute" style={{ left: t.x, top: t.y, transform: 'translate(-50%, -50%)' }}>
              <div className="mansion-torch-core" />
            </div>
          ))}

          {/* Room type indicator */}
          {curRoom?.type === 'boss' && (
            <div className="mansion-room-overlay boss-room-bg absolute inset-0 pointer-events-none" />
          )}
          {curRoom?.type === 'elite' && (
            <div className="mansion-room-overlay elite-room-bg absolute inset-0 pointer-events-none" />
          )}

          {/* Relic pedestal in item rooms */}
          {curRoom?.type === 'item' && !curRoom.cleared && curRoom.itemId && (
            <div className="mansion-pedestal absolute" style={{ left: GAME_WIDTH / 2, top: GAME_HEIGHT / 2, transform: 'translate(-50%, -50%)' }}>
              <div className="pedestal-glow" />
              <div className="pedestal-symbol">✦</div>
              <div className="pedestal-name">{ALL_RELICS.find(r => r.id === curRoom.itemId)?.name}</div>
            </div>
          )}

          {mansionState.status === 'playing' && (
            <>
              <div
                className={`hunter absolute rounded-full transform -translate-x-1/2 -translate-y-1/2 ${mansionState.abilities.shieldActive ? 'hunter-shielded' : ''}`}
                style={{ left: mansionState.player.pos.x, top: mansionState.player.pos.y, width: mansionState.player.radius * 2, height: mansionState.player.radius * 2 }}
              />
              {mansionState.abilities.shieldActive && (
                <div className="shield-ring absolute rounded-full pointer-events-none" style={{ left: mansionState.player.pos.x, top: mansionState.player.pos.y }} />
              )}
              {mansionState.abilities.holyPulse > 0 && (
                <div className="holy-pulse absolute rounded-full pointer-events-none" style={{ left: mansionState.player.pos.x, top: mansionState.player.pos.y, opacity: mansionState.abilities.holyPulse, transform: `translate(-50%, -50%) scale(${1.3 - mansionState.abilities.holyPulse * 0.3})` }} />
              )}
              {mansionState.abilities.swordSlash > 0 && (
                <div className="sword-slash absolute pointer-events-none" style={{ left: mansionState.player.pos.x, top: mansionState.player.pos.y, opacity: mansionState.abilities.swordSlash }} />
              )}
              {mansionState.bullets.map(b => (
                <div key={b.id} className={`${b.piercing ? 'piercing-bullet' : 'silver-bullet'} absolute rounded-full transform -translate-x-1/2 -translate-y-1/2`} style={{ left: b.pos.x, top: b.pos.y, width: b.radius * 2, height: b.radius * 2 }} />
              ))}
              {mansionState.enemies.map(e => (
                <div
                  key={e.id}
                  className={`${e.kind === 'vladros' ? 'vladros-enemy' : e.kind === 'wraith' ? 'wraith' : 'vampire'} absolute transform -translate-x-1/2 -translate-y-1/2`}
                  style={{ left: e.pos.x, top: e.pos.y, width: e.radius * 2, height: e.radius * 2 }}
                >
                  <div className="vampire-body" />
                  <div className="vampire-health">
                    <div style={{ width: `${Math.max(0, (e.health / e.maxHealth) * 100)}%` }} />
                  </div>
                  {e.kind === 'vladros' && <div className="boss-crown" />}
                  {e.kind === 'vladros' && e.phase === 2 && <div className="vladros-rage-ring" />}
                  {e.kind === 'wraith' && <div className="wraith-mark">RANGED</div>}
                </div>
              ))}
            </>
          )}
        </div>

        {/* HUD */}
        {mansionState.status === 'playing' && (
          <>
            <div className="game-hud-score absolute text-white font-mono z-10">
              <div className="score-label mb-1 font-serif italic" style={{ color: '#c084fc' }}>SCORE: {mansionState.score.toString().padStart(6, '0')}</div>
              <div className="wave-label" style={{ color: 'rgba(192,132,252,0.9)' }}>MANSION</div>
              <div className="coin-label mt-1" style={{ color: 'rgba(216,180,254,0.85)' }}>RELICS: {mansionState.relics.length}</div>
              <div className="weapon-label mt-1" style={{ color: 'rgba(216,180,254,0.75)' }}>
                {mansionState.weapon === 'ranged' ? (relicFx.noRanged ? '⚔ SWORD ONLY' : 'RANGED') : 'SWORD'}
              </div>
              {mansionState.roomMessage && (
                <div className="mansion-room-msg mt-2">{mansionState.roomMessage}</div>
              )}
            </div>

            <div className="game-hud-health absolute z-10">
              <div className="text-xs mb-1 text-right" style={{ color: 'rgba(192,132,252,0.85)' }}>BLOOD</div>
              <div className="h-2 w-full border" style={{ background: 'rgba(46,0,78,0.9)', borderColor: 'rgba(168,85,247,0.4)' }}>
                <div className="h-full transition-all duration-200" style={{ width: `${Math.max(0, (mansionState.player.health / mansionState.player.maxHealth) * 100)}%`, background: 'linear-gradient(90deg, #5b0fb5, #a855f7, #e879f9)' }} />
              </div>
            </div>

            {vladros && (
              <div className="boss-hud absolute z-10 text-center font-mono">
                <div className="boss-name" style={{ color: vladros.phase === 2 ? '#ff3080' : '#c084fc', fontStyle: 'italic' }}>{mansionState.bossMessage}</div>
                <div className="boss-bar">
                  <div style={{ width: `${Math.max(0, (vladros.health / vladros.maxHealth) * 100)}%`, background: vladros.phase === 2 ? 'linear-gradient(90deg, #4a0018, #ff3080, #ff80d0)' : 'linear-gradient(90deg, #2e006b, #9333ea, #d8b4fe)' }} />
                </div>
                {vladros.phase === 2 && <div className="boss-warning" style={{ color: '#ff80d0' }}>PHASE II — THE ETERNAL WRATH</div>}
              </div>
            )}

            <div className="ability-panel absolute z-10 font-mono">
              <button type="button" className={`ability-button mansion-btn weapon-switch ${mansionState.weapon === 'sword' ? 'sword-active' : 'ready'}`} onPointerDown={e => { e.preventDefault(); e.stopPropagation(); switchWeapon(); }}>
                <span>SWITCH</span>
                <strong>{mansionState.weapon === 'ranged' ? 'GUN' : 'SWORD'}</strong>
              </button>
              <button type="button" className={`ability-button mansion-btn ${dashReady ? 'ready' : 'cooling'}`} onPointerDown={e => { e.preventDefault(); e.stopPropagation(); activateDash(); }}>
                <span>DASH</span>
                <strong>{dashReady ? 'READY' : `${Math.ceil(mansionState.abilities.dashCooldown / 1000)}s`}</strong>
              </button>
              <button type="button" className={`ability-button mansion-btn ${burstReady ? 'ready' : 'cooling'}`} onPointerDown={e => { e.preventDefault(); e.stopPropagation(); activateHolyBurst(); }}>
                <span>HOLY BURST</span>
                <strong>{burstReady ? 'READY' : `${Math.ceil(mansionState.abilities.burstCooldown / 1000)}s`}</strong>
              </button>
            </div>

            {/* Minimap */}
            <div className="mansion-minimap absolute z-10">
              <div className="minimap-label">MAP</div>
              <div className="minimap-grid" style={{ gridTemplateColumns: `repeat(${GRID_COLS}, 16px)` }}>
                {Array.from({ length: GRID_ROWS }, (_, row) =>
                  Array.from({ length: GRID_COLS }, (_, col) => {
                    const room = roomGrid[row]?.[col];
                    const isCur = col === currentRoomPos.col && row === currentRoomPos.row;
                    if (!room) return <div key={`${col}-${row}`} className="minimap-empty" />;
                    if (!room.visited && !isCur) return <div key={`${col}-${row}`} className="minimap-unvisited" />;
                    const color = ROOM_COLORS[room.type] ?? '#6b7280';
                    return (
                      <div
                        key={`${col}-${row}`}
                        className={`minimap-room ${isCur ? 'minimap-current' : ''}`}
                        style={{
                          background: isCur ? '#ffffff' : color + (room.cleared ? 'dd' : '88'),
                          border: isCur ? '2px solid #fff' : `1px solid ${color}66`,
                        }}
                      />
                    );
                  })
                )}
              </div>
            </div>

            {/* Relic chips */}
            {mansionState.relics.length > 0 && (
              <div className="relic-list absolute z-10">
                {mansionState.relics.map(rid => {
                  const def = ALL_RELICS.find(r => r.id === rid);
                  return def ? (
                    <div key={rid} className="relic-chip" title={`${def.name} | ▲ ${def.buff} | ▼ ${def.debuff}`}>
                      {def.name.split(' ').map(w => w[0]).join('').substring(0, 2).toUpperCase()}
                    </div>
                  ) : null;
                })}
              </div>
            )}
          </>
        )}

        {/* Item pickup overlay */}
        {mansionState.status === 'item_pickup' && pendingDef && (
          <div className="absolute inset-0 bg-black/88 flex flex-col items-center justify-center z-30 px-5 text-center">
            <div className="relic-pickup-panel">
              <div className="relic-pickup-kicker font-mono">✦ CURSED RELIC FOUND ✦</div>
              <h2 className="relic-pickup-name font-serif">{pendingDef.name}</h2>
              <p className="relic-pickup-flavor font-serif">{pendingDef.flavor}</p>
              <div className="relic-pickup-effects">
                <div className="relic-buff">▲ {pendingDef.buff}</div>
                <div className="relic-debuff">▼ {pendingDef.debuff}</div>
              </div>
              <button
                type="button"
                className="game-button mt-6 font-mono uppercase tracking-widest transition-all hover:scale-105"
                style={{ background: 'rgba(88,28,135,0.4)', border: '1px solid rgba(168,85,247,0.7)', color: 'rgba(233,213,255,0.95)' }}
                onClick={() => acceptRelic(pendingDef.id as RelicId)}
              >
                Accept the Curse
              </button>
            </div>
          </div>
        )}

        {/* Mansion menu */}
        {mansionState.status === 'menu' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center z-20 px-5 text-center" style={{ background: 'radial-gradient(circle at 50% 38%, rgba(88,10,140,0.5), transparent 60%), rgba(0,0,0,0.7)' }}>
            <h1 className="game-title font-serif italic tracking-widest mb-2" style={{ color: '#c084fc', textShadow: '0 0 30px rgba(160,60,255,0.8), 0 0 80px rgba(255,100,255,0.2)' }}>
              VAMPIRE<br />MANSION
            </h1>
            <p className="game-subtitle font-mono mb-8 max-w-md uppercase tracking-widest" style={{ color: 'rgba(192,132,252,0.72)', lineHeight: 1.7 }}>
              Navigate haunted chambers. Collect cursed relics — each brings power and peril. Reach Lord Vladros and end his reign.
            </p>
            <button onClick={startMansion} className="game-button font-mono hover:scale-105 transition-all uppercase tracking-widest mb-4" style={{ background: 'rgba(88,28,135,0.25)', border: '1px solid rgba(168,85,247,0.65)', color: 'rgba(233,213,255,0.95)', boxShadow: '0 0 28px rgba(160,60,255,0.22)' }}>
              Storm the Mansion
            </button>
            <button onClick={onBack} className="font-mono text-sm uppercase tracking-widest transition-colors" style={{ color: 'rgba(192,132,252,0.55)' }} onMouseEnter={e => (e.currentTarget.style.color = 'rgba(216,180,254,0.85)')} onMouseLeave={e => (e.currentTarget.style.color = 'rgba(192,132,252,0.55)')}>
              ← Return to Forest
            </button>
          </div>
        )}

        {/* Game over */}
        {mansionState.status === 'gameover' && (
          <div className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center z-20 px-5 text-center">
            <h2 className="game-over-title font-serif italic tracking-widest mb-4" style={{ color: '#c084fc' }}>CONSUMED</h2>
            <div className="font-mono mb-2 text-xl" style={{ color: 'rgba(216,180,254,0.9)' }}>SCORE: {mansionState.score.toString().padStart(6, '0')}</div>
            <div className="font-mono text-sm mb-8" style={{ color: 'rgba(192,132,252,0.65)' }}>RELICS CARRIED: {mansionState.relics.length}</div>
            {mansionState.relics.length > 0 && (
              <div className="flex flex-wrap gap-2 justify-center mb-6 max-w-sm">
                {mansionState.relics.map(rid => {
                  const def = ALL_RELICS.find(r => r.id === rid);
                  return def ? <div key={rid} className="relic-chip">{def.name}</div> : null;
                })}
              </div>
            )}
            <button onClick={startMansion} className="game-button font-mono uppercase tracking-widest hover:scale-105 transition-all mb-4" style={{ background: 'rgba(88,28,135,0.3)', border: '1px solid rgba(168,85,247,0.6)', color: 'rgba(233,213,255,0.95)' }}>
              Try Again
            </button>
            <button onClick={onBack} className="font-mono text-sm uppercase tracking-widest transition-colors" style={{ color: 'rgba(192,132,252,0.5)' }} onMouseEnter={e => (e.currentTarget.style.color = 'rgba(216,180,254,0.8)')} onMouseLeave={e => (e.currentTarget.style.color = 'rgba(192,132,252,0.5)')}>
              ← Return to Forest
            </button>
          </div>
        )}

        {/* Victory */}
        {mansionState.status === 'victory' && (() => {
          const ending = MANSION_ENDINGS[characterId];
          return (
            <div className="absolute inset-0 flex flex-col items-center justify-center z-20 px-5 text-center" style={{ background: 'radial-gradient(circle at 50% 38%, rgba(120,80,0,0.5), transparent 60%), rgba(0,0,0,0.92)' }}>
              <div className="font-mono text-xs uppercase tracking-widest mb-2" style={{ color: 'rgba(253,224,71,0.6)', letterSpacing: '0.3em' }}>★ {ending.subtitle} ★</div>
              <h2 className="font-serif italic tracking-widest mb-4" style={{ fontSize: 'clamp(1.8rem, 6vw, 2.6rem)', color: '#fcd34d', textShadow: '0 0 32px rgba(253,211,77,0.8), 0 0 80px rgba(255,170,0,0.3)' }}>{ending.title}</h2>
              <div className="mb-4 max-w-md" style={{ background: 'rgba(0,0,0,0.4)', borderRadius: 8, padding: '14px 20px', border: '1px solid rgba(253,224,71,0.15)' }}>
                {ending.lines.map((line, i) => (
                  <p key={i} className="font-serif mb-1 text-sm leading-relaxed" style={{ color: i === 0 ? 'rgba(253,224,71,0.85)' : 'rgba(253,230,138,0.65)', fontStyle: line.startsWith('"') ? 'italic' : 'normal' }}>{line}</p>
                ))}
              </div>
              <div className="font-mono mb-1 text-lg" style={{ color: 'rgba(253,224,71,0.92)' }}>SCORE: {mansionState.score.toString().padStart(6, '0')}</div>
              <div className="font-mono text-xs mb-4" style={{ color: 'rgba(253,211,77,0.5)' }}>{char.name} · {diff.name} · {mansionState.relics.length} relics</div>
              {mansionState.relics.length > 0 && (
                <div className="flex flex-wrap gap-2 justify-center mb-4 max-w-sm">
                  {mansionState.relics.map(rid => {
                    const def = ALL_RELICS.find(r => r.id === rid);
                    return def ? <div key={rid} className="relic-chip victory-chip">{def.name}</div> : null;
                  })}
                </div>
              )}
              <button onClick={startMansion} className="game-button font-mono uppercase tracking-widest hover:scale-105 transition-all mb-4" style={{ background: 'rgba(120,80,0,0.3)', border: '1px solid rgba(253,211,77,0.6)', color: 'rgba(253,230,138,0.95)' }}>
                Storm Again
              </button>
              <button onClick={onBack} className="font-mono text-sm uppercase tracking-widest transition-colors" style={{ color: 'rgba(253,211,77,0.5)' }} onMouseEnter={e => (e.currentTarget.style.color = 'rgba(253,230,138,0.8)')} onMouseLeave={e => (e.currentTarget.style.color = 'rgba(253,211,77,0.5)')}>
                ← Choose Mode
              </button>
            </div>
          );
        })()}
      </div>
    </div>
  );
}
