import { useState, useEffect, useRef, useCallback } from 'react';
import type { CharacterId, DifficultyId } from '../data/characters';
import { CHARACTERS, DIFFICULTIES } from '../data/characters';

type Position = { x: number; y: number };
type Velocity = { x: number; y: number };

export type ChurchDirection = 'north' | 'south' | 'east' | 'west';
export type ChurchRoomType = 'start' | 'normal' | 'elite' | 'item' | 'gargant' | 'gauntlet' | 'boss';
export type ChurchEnemyKind = 'paladin' | 'crusader' | 'fallen_angel' | 'cardinal';

export type ChurchRoom = {
  type: ChurchRoomType;
  cleared: boolean;
  visited: boolean;
  connections: Partial<Record<ChurchDirection, boolean>>;
  itemId?: ChurchRelicId;
};

export type ChurchRelicId =
  | 'sacred_flame' | 'broken_halo' | 'martyrs_blood' | 'void_chalice'
  | 'silver_thread' | 'tainted_incense' | 'bishops_ring' | 'fallen_grace'
  | 'crimson_chalice' | 'shadow_veil' | 'blood_pact' | 'midnight_lens';

export type ChurchRelicDef = {
  id: ChurchRelicId;
  name: string;
  flavor: string;
  buff: string;
  debuff: string;
  effects: Partial<ChurchRelicEffects>;
};

type ChurchRelicEffects = {
  damageMult: number;
  speedMult: number;
  maxHealthBonus: number;
  fireRateMult: number;
  healPerKill: number;
  damageTakenMult: number;
  dashCooldownMult: number;
  piercing: boolean;
  multishot: boolean;
  healOnRoomClear: number;
  regenBonus: number;
};

export const CHURCH_RELICS: ChurchRelicDef[] = [
  { id: 'sacred_flame', name: 'Sacred Flame', flavor: 'Burns the unholy — and the holy alike.', buff: '+40% damage', debuff: 'Take 20% more damage', effects: { damageMult: 1.4, damageTakenMult: 1.2 } },
  { id: 'broken_halo', name: 'Broken Halo', flavor: 'Its blessing is... mixed.', buff: '+45% movement speed', debuff: '-25% damage', effects: { speedMult: 1.45, damageMult: 0.75 } },
  { id: 'martyrs_blood', name: "Martyr's Blood", flavor: 'Life given freely for power.', buff: 'Heal 4 HP per kill', debuff: 'Max HP -25', effects: { healPerKill: 4, maxHealthBonus: -25 } },
  { id: 'void_chalice', name: 'Void Chalice', flavor: 'Drink deep. Pay later.', buff: '+50 max HP', debuff: '+70% ability cooldowns', effects: { maxHealthBonus: 50, dashCooldownMult: 1.7 } },
  { id: 'silver_thread', name: 'Silver Thread', flavor: 'Thin as mercy, sharp as judgment.', buff: 'Piercing shots', debuff: '-20% fire rate', effects: { piercing: true, fireRateMult: 0.8 } },
  { id: 'tainted_incense', name: 'Tainted Incense', flavor: 'Smells like salvation. Burns like sin.', buff: '+30% fire rate', debuff: '-15% movement speed', effects: { fireRateMult: 1.3, speedMult: 0.85 } },
  { id: 'bishops_ring', name: "Bishop's Ring", flavor: 'Authority given, wisdom not included.', buff: 'Heal 15 HP on room clear', debuff: 'Lose 5 HP when missing a shot (max 1/s)', effects: { healOnRoomClear: 15 } },
  { id: 'fallen_grace', name: 'Fallen Grace', flavor: 'The angels wept. Then fell.', buff: 'Double shot — fire 2 bullets', debuff: '-35% bullet speed', effects: { multishot: true } },
  { id: 'crimson_chalice', name: 'Crimson Chalice', flavor: 'A goblet that always thirsts.', buff: '+35% damage', debuff: '-20 max HP', effects: { damageMult: 1.35, maxHealthBonus: -20 } },
  { id: 'shadow_veil', name: 'Shadow Veil', flavor: 'Move like darkness, shoot like fog.', buff: '+40% speed', debuff: '-30% damage', effects: { speedMult: 1.4, damageMult: 0.7 } },
  { id: 'blood_pact', name: 'Blood Pact', flavor: 'Life traded freely for power.', buff: 'Heal 3 HP per kill', debuff: 'Take 25% more damage', effects: { healPerKill: 3, damageTakenMult: 1.25 } },
  { id: 'midnight_lens', name: 'Midnight Lens', flavor: 'See through walls. Die by them.', buff: 'Piercing shots + 2.5 regen/s', debuff: '-30% damage', effects: { piercing: true, regenBonus: 2.5, damageMult: 0.7 } },
];

export function computeChurchRelicEffects(relics: ChurchRelicId[]): Required<ChurchRelicEffects> {
  const base: Required<ChurchRelicEffects> = {
    damageMult: 1, speedMult: 1, maxHealthBonus: 0, fireRateMult: 1, healPerKill: 0,
    damageTakenMult: 1, dashCooldownMult: 1, piercing: false, multishot: false, healOnRoomClear: 0, regenBonus: 0,
  };
  for (const id of relics) {
    const def = CHURCH_RELICS.find(r => r.id === id);
    if (!def) continue;
    if (def.effects.damageMult !== undefined) base.damageMult *= def.effects.damageMult;
    if (def.effects.speedMult !== undefined) base.speedMult *= def.effects.speedMult;
    if (def.effects.maxHealthBonus !== undefined) base.maxHealthBonus += def.effects.maxHealthBonus;
    if (def.effects.fireRateMult !== undefined) base.fireRateMult *= def.effects.fireRateMult;
    if (def.effects.healPerKill !== undefined) base.healPerKill += def.effects.healPerKill;
    if (def.effects.damageTakenMult !== undefined) base.damageTakenMult *= def.effects.damageTakenMult;
    if (def.effects.dashCooldownMult !== undefined) base.dashCooldownMult *= def.effects.dashCooldownMult;
    if (def.effects.piercing) base.piercing = true;
    if (def.effects.multishot) base.multishot = true;
    if (def.effects.healOnRoomClear !== undefined) base.healOnRoomClear += def.effects.healOnRoomClear;
    if (def.effects.regenBonus !== undefined) base.regenBonus += def.effects.regenBonus;
  }
  return base;
}

export type ChurchPlayer = {
  pos: Position;
  health: number;
  maxHealth: number;
  speed: number;
  radius: number;
};

export type ChurchEnemy = {
  id: string;
  kind: ChurchEnemyKind;
  pos: Position;
  health: number;
  maxHealth: number;
  speed: number;
  radius: number;
  phase?: 1 | 2;
  shootTimer?: number;
  orbitAngle?: number;
};

export type ChurchBullet = {
  id: string;
  pos: Position;
  vel: Velocity;
  speed: number;
  radius: number;
  damage: number;
  piercing: boolean;
  fromEnemy?: boolean;
  homing?: boolean;
};

export type ChurchSummon = {
  id: string;
  kind: 'familiar' | 'elite_vampire' | 'shadow_soldier' | 'hellhound' | 'alucard_ghost';
  pos: Position;
  health: number;
  maxHealth: number;
  speed: number;
  damage: number;
  radius: number;
  attackTimer: number;
};

export type HazardBeam = {
  id: string;
  axis: 'h' | 'v';
  position: number;
  thickness: number;
  active: boolean;
  warning: boolean;
  stateTimer: number;
  offDuration: number;
  warnDuration: number;
  activeDuration: number;
};

export type ChurchAbilityState = {
  cooldowns: number[];
  shieldActive: boolean;
  shieldUntil: number;
  bloodReleaseUntil: number;
  angelModeUntil: number;
  regeneratorUntil: number;
  restrictionUntil: number;
};

export type ChurchState = {
  status: 'menu' | 'playing' | 'item_pickup' | 'gameover' | 'victory' | 'gargant_joke' | 'gargant_portal';
  characterId: CharacterId;
  difficultyId: DifficultyId;
  roomGrid: (ChurchRoom | null)[][];
  currentRoomPos: { col: number; row: number };
  bossRoomPos: { col: number; row: number };
  gauntletRoomPos: { col: number; row: number } | null;
  gargantRoomPos: { col: number; row: number } | null;
  relics: ChurchRelicId[];
  pendingRelic: ChurchRelicId | null;
  player: ChurchPlayer;
  enemies: ChurchEnemy[];
  bullets: ChurchBullet[];
  summons: ChurchSummon[];
  hazardBeams: HazardBeam[];
  abilities: ChurchAbilityState;
  score: number;
  bossMessage: string;
  roomMessage: string;
  gargantPhase: number;
  gargantTimer: number;
  dialogueLine: number;
  wireArcTimer: number;
};

const GAME_WIDTH = 1200;
const GAME_HEIGHT = 800;
const PLAYER_SPEED = 5.4;
const BULLET_SPEED = 16;
const DOOR_ZONE = 44;
const GRID_COLS = 5;
const GRID_ROWS = 5;
const START_COL = 2;
const START_ROW = 2;
const DAMAGE_COOLDOWN = 400;

const DIRS: Array<[number, number, ChurchDirection, ChurchDirection]> = [
  [0, -1, 'north', 'south'],
  [0, 1, 'south', 'north'],
  [-1, 0, 'west', 'east'],
  [1, 0, 'east', 'west'],
];

const OPPOSITE: Record<ChurchDirection, ChurchDirection> = {
  north: 'south', south: 'north', east: 'west', west: 'east',
};

function bfsDistances(grid: (ChurchRoom | null)[][]): number[][] {
  const dist = Array.from({ length: GRID_ROWS }, () => Array(GRID_COLS).fill(-1));
  const queue: [number, number][] = [[START_ROW, START_COL]];
  dist[START_ROW][START_COL] = 0;
  while (queue.length) {
    const [r, c] = queue.shift()!;
    for (const [dc, dr] of [[0,-1],[0,1],[-1,0],[1,0]]) {
      const nr = r + dr, nc = c + dc;
      if (nr < 0 || nr >= GRID_ROWS || nc < 0 || nc >= GRID_COLS) continue;
      if (!grid[nr][nc] || dist[nr][nc] !== -1) continue;
      dist[nr][nc] = dist[r][c] + 1;
      queue.push([nr, nc]);
    }
  }
  return dist;
}

function generateChurchMap(): {
  grid: (ChurchRoom | null)[][];
  bossPos: { row: number; col: number };
  gauntletPos: { row: number; col: number } | null;
  gargantPos: { row: number; col: number } | null;
} {
  const grid: (ChurchRoom | null)[][] = Array.from({ length: GRID_ROWS }, () => Array(GRID_COLS).fill(null));
  const placed = new Set<string>();
  const key = (r: number, c: number) => `${r},${c}`;

  grid[START_ROW][START_COL] = { type: 'start', cleared: true, visited: true, connections: {} };
  placed.add(key(START_ROW, START_COL));

  const frontier: [number, number][] = [[START_ROW, START_COL]];
  while (frontier.length && placed.size < 14) {
    const idx = Math.floor(Math.random() * frontier.length);
    const [r, c] = frontier[idx];
    const shuffled = DIRS.slice().sort(() => Math.random() - 0.5);
    for (const [dc, dr, myDir, theirDir] of shuffled) {
      const nr = r + dr, nc = c + dc;
      if (nr < 0 || nr >= GRID_ROWS || nc < 0 || nc >= GRID_COLS) continue;
      if (placed.has(key(nr, nc))) continue;
      if (Math.random() > 0.62 && placed.size > 5) continue;
      grid[r][c]!.connections[myDir] = true;
      grid[nr][nc] = { type: 'normal', cleared: false, visited: false, connections: { [theirDir]: true } };
      placed.add(key(nr, nc));
      frontier.push([nr, nc]);
    }
    frontier.splice(idx, 1);
  }

  const dist = bfsDistances(grid);
  let bossRow = START_ROW, bossCol = START_COL, bossMaxDist = 0;
  for (let r = 0; r < GRID_ROWS; r++) {
    for (let c = 0; c < GRID_COLS; c++) {
      if (!grid[r][c] || (r === START_ROW && c === START_COL)) continue;
      if (dist[r][c] > bossMaxDist) { bossMaxDist = dist[r][c]; bossRow = r; bossCol = c; }
    }
  }
  grid[bossRow][bossCol]!.type = 'boss';

  const deadEnds: [number, number][] = [];
  for (let r = 0; r < GRID_ROWS; r++) {
    for (let c = 0; c < GRID_COLS; c++) {
      if (!grid[r][c] || (r === START_ROW && c === START_COL) || (r === bossRow && c === bossCol)) continue;
      const conns = Object.keys(grid[r][c]!.connections).length;
      if (conns === 1) deadEnds.push([r, c]);
    }
  }
  deadEnds.sort(() => Math.random() - 0.5);

  let gauntletPos: { row: number; col: number } | null = null;
  let gargantPos: { row: number; col: number } | null = null;
  let itemCount = 0;

  const bossAdjacent: Array<{ row: number; col: number; dirToBoss: ChurchDirection; dirFromBoss: ChurchDirection }> = [];
  for (const [dc, dr, myDir, theirDir] of DIRS) {
    const ar = bossRow + dr, ac = bossCol + dc;
    if (ar >= 0 && ar < GRID_ROWS && ac >= 0 && ac < GRID_COLS && grid[ar][ac]) {
      bossAdjacent.push({ row: ar, col: ac, dirToBoss: myDir, dirFromBoss: theirDir });
    }
  }

  for (const [r, c] of deadEnds) {
    if (!gauntletPos) {
      const adjEntry = bossAdjacent.find(a => a.row === r && a.col === c);
      if (adjEntry) {
        grid[r][c]!.type = 'gauntlet';
        gauntletPos = { row: r, col: c };
        grid[bossRow][bossCol]!.connections[adjEntry.dirFromBoss] = true;
        grid[r][c]!.connections[adjEntry.dirToBoss] = true;
      }
    }
    if (grid[r][c]?.type === 'gauntlet') continue;
    if (!gargantPos && dist[r][c] >= 2) {
      grid[r][c]!.type = 'gargant';
      gargantPos = { row: r, col: c };
    } else if (itemCount < 3) {
      grid[r][c]!.type = 'item';
      const relicIds = CHURCH_RELICS.map(r => r.id);
      grid[r][c]!.itemId = relicIds[Math.floor(Math.random() * relicIds.length)];
      itemCount++;
    }
  }

  const eliteEligible: [number, number][] = [];
  for (let r = 0; r < GRID_ROWS; r++) {
    for (let c = 0; c < GRID_COLS; c++) {
      if (grid[r][c]?.type === 'normal') eliteEligible.push([r, c]);
    }
  }
  eliteEligible.sort(() => Math.random() - 0.5);
  for (let i = 0; i < Math.min(2, eliteEligible.length); i++) {
    grid[eliteEligible[i][0]][eliteEligible[i][1]]!.type = 'elite';
  }

  return { grid, bossPos: { row: bossRow, col: bossCol }, gauntletPos, gargantPos };
}

function spawnRoomEnemies(
  roomType: ChurchRoomType,
  diffMult: number,
  charId: CharacterId
): ChurchEnemy[] {
  const spd = (base: number) => base * (charId === 'alucard' ? 0.95 : 1);
  const hp = (base: number) => Math.round(base * diffMult);
  const id = () => `e-${Math.random().toString(36).slice(2)}`;
  const rndPos = () => ({ x: 180 + Math.random() * 840, y: 180 + Math.random() * 440 });

  if (roomType === 'normal') {
    return [
      { id: id(), kind: 'paladin', pos: rndPos(), health: hp(80), maxHealth: hp(80), speed: spd(2.3), radius: 16, shootTimer: 0 },
      { id: id(), kind: 'crusader', pos: rndPos(), health: hp(60), maxHealth: hp(60), speed: spd(1.8), radius: 13, shootTimer: 0 },
    ];
  }
  if (roomType === 'elite') {
    return [
      { id: id(), kind: 'paladin', pos: rndPos(), health: hp(140), maxHealth: hp(140), speed: spd(2.7), radius: 19, shootTimer: 0 },
      { id: id(), kind: 'crusader', pos: rndPos(), health: hp(100), maxHealth: hp(100), speed: spd(2.1), radius: 14, shootTimer: 0 },
      { id: id(), kind: 'fallen_angel', pos: rndPos(), health: hp(70), maxHealth: hp(70), speed: spd(3.8), radius: 12, shootTimer: 0 },
    ];
  }
  if (roomType === 'gauntlet') {
    return [
      { id: id(), kind: 'paladin', pos: { x: 300, y: 300 }, health: hp(130), maxHealth: hp(130), speed: spd(2.5), radius: 18, shootTimer: 0 },
      { id: id(), kind: 'paladin', pos: { x: 900, y: 500 }, health: hp(130), maxHealth: hp(130), speed: spd(2.5), radius: 18, shootTimer: 0 },
      { id: id(), kind: 'fallen_angel', pos: rndPos(), health: hp(60), maxHealth: hp(60), speed: spd(4.0), radius: 11, shootTimer: 0 },
    ];
  }
  if (roomType === 'boss') {
    const bossHp = hp(1100);
    return [{ id: 'cardinal', kind: 'cardinal', pos: { x: GAME_WIDTH / 2, y: 250 }, health: bossHp, maxHealth: bossHp, speed: 1.0, radius: 34, phase: 1, shootTimer: 0, orbitAngle: 0 }];
  }
  return [];
}

function createHazardBeams(): HazardBeam[] {
  return [
    { id: 'b0', axis: 'h', position: 250, thickness: 24, active: false, warning: false, stateTimer: 1800, offDuration: 1800, warnDuration: 700, activeDuration: 1600 },
    { id: 'b1', axis: 'h', position: 550, thickness: 24, active: false, warning: false, stateTimer: 900, offDuration: 1800, warnDuration: 700, activeDuration: 1600 },
    { id: 'b2', axis: 'v', position: 400, thickness: 22, active: false, warning: false, stateTimer: 1400, offDuration: 1800, warnDuration: 700, activeDuration: 1600 },
    { id: 'b3', axis: 'v', position: 800, thickness: 22, active: false, warning: false, stateTimer: 600, offDuration: 1800, warnDuration: 700, activeDuration: 1600 },
  ];
}

function getInitialAbilities(charId: CharacterId): ChurchAbilityState {
  const char = CHARACTERS.find(c => c.id === charId)!;
  return {
    cooldowns: char.abilities.map(() => 0),
    shieldActive: false,
    shieldUntil: 0,
    bloodReleaseUntil: 0,
    angelModeUntil: 0,
    regeneratorUntil: 0,
    restrictionUntil: 0,
  };
}

const initialState: ChurchState = {
  status: 'menu',
  characterId: 'hunter',
  difficultyId: 'normal',
  roomGrid: Array.from({ length: GRID_ROWS }, () => Array(GRID_COLS).fill(null)),
  currentRoomPos: { col: START_COL, row: START_ROW },
  bossRoomPos: { col: 0, row: 0 },
  gauntletRoomPos: null,
  gargantRoomPos: null,
  relics: [],
  pendingRelic: null,
  player: { pos: { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 }, health: 100, maxHealth: 100, speed: PLAYER_SPEED, radius: 14 },
  enemies: [],
  bullets: [],
  summons: [],
  hazardBeams: [],
  abilities: { cooldowns: [0, 0], shieldActive: false, shieldUntil: 0, bloodReleaseUntil: 0, angelModeUntil: 0, regeneratorUntil: 0, restrictionUntil: 0 },
  score: 0,
  bossMessage: '',
  roomMessage: '',
  gargantPhase: 0,
  gargantTimer: 0,
  dialogueLine: 0,
  wireArcTimer: 0,
};

export function useChurchLoop() {
  const [churchState, setChurchState] = useState<ChurchState>(initialState);
  const runningRef = useRef(false);
  const rafRef = useRef<number>(0);
  const lastFrameRef = useRef(0);
  const mouseRef = useRef<Position>({ x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 });
  const touchMovementRef = useRef<Position>({ x: 0, y: 0 });
  const isMouseDownRef = useRef(false);
  const lastShootRef = useRef(0);
  const lastDamageRef = useRef(0);
  const lastDamageByEnemyRef = useRef(0);
  const abilityReqRef = useRef<number | null>(null);
  const cardinalMinionTimerRef = useRef(0);

  const startChurch = useCallback((charId: CharacterId, diffId: DifficultyId) => {
    const char = CHARACTERS.find(c => c.id === charId)!;
    const diff = DIFFICULTIES.find(d => d.id === diffId)!;
    const { grid, bossPos, gauntletPos, gargantPos } = generateChurchMap();
    const maxHp = Math.round(char.stats.maxHealth * diff.playerHealthMult);
    runningRef.current = true;
    lastFrameRef.current = performance.now();
    lastShootRef.current = 0;
    lastDamageRef.current = 0;
    lastDamageByEnemyRef.current = 0;
    cardinalMinionTimerRef.current = 0;
    setChurchState({
      ...initialState,
      status: 'playing',
      characterId: charId,
      difficultyId: diffId,
      roomGrid: grid,
      bossRoomPos: bossPos,
      gauntletRoomPos: gauntletPos,
      gargantRoomPos: gargantPos,
      player: { pos: { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 }, health: maxHp, maxHealth: maxHp, speed: PLAYER_SPEED * char.stats.speed, radius: 14 },
      enemies: [],
      bullets: [],
      summons: [],
      hazardBeams: [],
      abilities: getInitialAbilities(charId),
      score: 0,
    });
  }, []);

  const setTouchMovement = useCallback((v: Position) => { touchMovementRef.current = v; }, []);
  const setAimPosition = useCallback((pos: Position) => { mouseRef.current = pos; }, []);
  const setFiring = useCallback((f: boolean) => { isMouseDownRef.current = f; }, []);
  const activateAbility = useCallback((slot: number) => { abilityReqRef.current = slot; }, []);

  const acceptRelic = useCallback(() => {
    setChurchState(prev => {
      if (!prev.pendingRelic) return prev;
      return { ...prev, relics: [...prev.relics, prev.pendingRelic], pendingRelic: null, status: 'playing' };
    });
    runningRef.current = true;
  }, []);

  const rejectRelic = useCallback(() => {
    setChurchState(prev => ({ ...prev, pendingRelic: null, status: 'playing' }));
    runningRef.current = true;
  }, []);

  useEffect(() => {
    const tick = () => {
      const now = performance.now();
      const dt = Math.min(now - lastFrameRef.current, 50);
      lastFrameRef.current = now;

      setChurchState(prev => {
        if (prev.status === 'gargant_joke' || prev.status === 'gargant_portal') {
          const newTimer = prev.gargantTimer - dt;
          if (prev.status === 'gargant_joke') {
            if (newTimer <= -3500) {
              runningRef.current = true;
              const target = prev.gauntletRoomPos ?? prev.bossRoomPos;
              const room = prev.roomGrid[target.row][target.col];
              const diff = DIFFICULTIES.find(d => d.id === prev.difficultyId)!;
              const enemies = room ? spawnRoomEnemies(room.type, diff.enemyHealthMult, prev.characterId) : [];
              const beams = room?.type === 'gauntlet' ? createHazardBeams() : [];
              const newGrid = prev.roomGrid.map(row => [...row]);
              if (newGrid[target.row][target.col]) {
                newGrid[target.row][target.col] = { ...newGrid[target.row][target.col]!, visited: true };
              }
              return {
                ...prev, status: 'playing', currentRoomPos: target, enemies, hazardBeams: beams,
                bullets: [], summons: [], roomGrid: newGrid, gargantTimer: 0, dialogueLine: 0,
                player: { ...prev.player, pos: { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 } },
                roomMessage: room?.type === 'gauntlet' ? 'Welcome to the obstacle course' : 'Boss chamber entered',
              };
            }
            const line = newTimer < -2200 ? 2 : newTimer < -1100 ? 1 : 0;
            return { ...prev, gargantTimer: newTimer, dialogueLine: line };
          }
          return prev;
        }

        if (!runningRef.current || prev.status !== 'playing') return prev;

        const char = CHARACTERS.find(c => c.id === prev.characterId)!;
        const diff = DIFFICULTIES.find(d => d.id === prev.difficultyId)!;
        const fx = computeChurchRelicEffects(prev.relics);

        const isRestriction = now < prev.abilities.restrictionUntil;
        const cdMult = (isRestriction || char.stats.noLimits) ? 0.5 : 1;

        const movement = touchMovementRef.current;
        const spd = prev.player.speed * fx.speedMult * (now < prev.abilities.angelModeUntil ? 1.5 : 1) * (now < prev.abilities.bloodReleaseUntil ? 1.3 : 1);
        let nx = prev.player.pos.x + movement.x * spd;
        let ny = prev.player.pos.y + movement.y * spd;
        nx = Math.max(prev.player.radius, Math.min(GAME_WIDTH - prev.player.radius, nx));
        ny = Math.max(prev.player.radius, Math.min(GAME_HEIGHT - prev.player.radius, ny));
        const nextPos = { x: nx, y: ny };

        const curRoom = prev.roomGrid[prev.currentRoomPos.row]?.[prev.currentRoomPos.col];
        const isCleared = !!curRoom?.cleared;

        let newEnemies = [...prev.enemies];
        let newBullets = [...prev.bullets];
        let newSummons = [...prev.summons];

        const dmgMult = fx.damageMult * char.stats.damage * (now < prev.abilities.bloodReleaseUntil ? 1.4 : 1) * (now < prev.abilities.angelModeUntil ? 1.6 : 1);
        const baseDmg = char.weapon === 'rifle' ? 90 : char.weapon === 'bayonet' ? 52 : char.weapon === 'wire' ? 42 : char.weapon === 'dual_pistol' ? 22 : 35;
        const gunDmg = baseDmg * dmgMult;

        const shootBase = char.weapon === 'rifle' ? 580 : char.weapon === 'bayonet' ? 380 : char.weapon === 'wire' ? 240 : char.weapon === 'dual_pistol' ? 120 : 180;
        const shootCD = shootBase / (fx.fireRateMult * char.stats.fireRate);
        const bSpeed = BULLET_SPEED * (char.weapon === 'rifle' ? 1.3 : 1);

        if (isMouseDownRef.current && now - lastShootRef.current > shootCD) {
          const mx = mouseRef.current.x, my = mouseRef.current.y;
          let dx = mx - nextPos.x, dy = my - nextPos.y;
          const dl = Math.sqrt(dx * dx + dy * dy);

          if (char.weapon === 'wire') {
            const coneAngle = Math.PI * 0.7;
            const aimAngle = Math.atan2(dy, dx);
            const arcRange = 160 * (now < prev.abilities.angelModeUntil ? 2.5 : 1);
            newEnemies = newEnemies.map(e => {
              const ex = e.pos.x - nextPos.x, ey = e.pos.y - nextPos.y;
              const dist = Math.sqrt(ex * ex + ey * ey);
              if (dist > arcRange + e.radius) return e;
              const angle = Math.atan2(ey, ex);
              let diff = angle - aimAngle;
              while (diff > Math.PI) diff -= 2 * Math.PI;
              while (diff < -Math.PI) diff += 2 * Math.PI;
              if (Math.abs(diff) > coneAngle / 2) return e;
              return { ...e, health: e.health - gunDmg };
            });
            lastShootRef.current = now;
          } else if (dl > 0) {
            dx /= dl; dy /= dl;
            const bBase = { pos: { ...nextPos }, speed: bSpeed, radius: char.weapon === 'rifle' ? 7 : 5, damage: gunDmg, piercing: fx.piercing || char.weapon === 'rifle' || char.weapon === 'bayonet' };
            newBullets.push({ ...bBase, id: `b-${now}-0`, vel: { x: dx * bSpeed, y: dy * bSpeed } });
            if (fx.multishot || char.weapon === 'dual_pistol') {
              const sp = 0.18;
              newBullets.push({ ...bBase, id: `b-${now}-1`, vel: { x: (dx * Math.cos(sp) - dy * Math.sin(sp)) * bSpeed, y: (dx * Math.sin(sp) + dy * Math.cos(sp)) * bSpeed } });
              if (char.weapon === 'dual_pistol') {
                newBullets.push({ ...bBase, id: `b-${now}-2`, vel: { x: (dx * Math.cos(-sp) - dy * Math.sin(-sp)) * bSpeed, y: (dx * Math.sin(-sp) + dy * Math.cos(-sp)) * bSpeed } });
              }
            }
            lastShootRef.current = now;
          }
        }

        const abilitySlot = abilityReqRef.current;
        abilityReqRef.current = null;
        const newAbilities = { ...prev.abilities, cooldowns: [...prev.abilities.cooldowns] };

        if (abilitySlot !== null && abilitySlot < char.abilities.length) {
          const abilDef = char.abilities[abilitySlot];
          const cdMs = abilDef.cooldown * 1000 * cdMult;
          if (newAbilities.cooldowns[abilitySlot] <= 0) {
            newAbilities.cooldowns[abilitySlot] = cdMs;

            if (abilDef.id === 'dash') {
              const mx = movement.x || 1, my = movement.y || 0;
              const ml = Math.sqrt(mx * mx + my * my) || 1;
              nextPos.x = Math.max(30, Math.min(GAME_WIDTH - 30, nextPos.x + (mx / ml) * 150));
              nextPos.y = Math.max(30, Math.min(GAME_HEIGHT - 30, nextPos.y + (my / ml) * 150));
            } else if (abilDef.id === 'holy_burst') {
              const bRadius = 235;
              newEnemies = newEnemies.map(e => {
                const d = Math.sqrt((nextPos.x - e.pos.x) ** 2 + (nextPos.y - e.pos.y) ** 2);
                return d < bRadius ? { ...e, health: e.health - 120 * dmgMult } : e;
              });
            } else if (abilDef.id === 'shadow_step') {
              const nearest = newEnemies.reduce<ChurchEnemy | null>((best, e) => {
                const d = Math.sqrt((nextPos.x - e.pos.x) ** 2 + (nextPos.y - e.pos.y) ** 2);
                if (!best) return e;
                const bd = Math.sqrt((nextPos.x - best.pos.x) ** 2 + (nextPos.y - best.pos.y) ** 2);
                return d < bd ? e : best;
              }, null);
              if (nearest) {
                const dx = nextPos.x - nearest.pos.x, dy = nextPos.y - nearest.pos.y;
                const dl = Math.sqrt(dx * dx + dy * dy) || 1;
                nextPos.x = Math.max(30, Math.min(GAME_WIDTH - 30, nearest.pos.x + (dx / dl) * 70));
                nextPos.y = Math.max(30, Math.min(GAME_HEIGHT - 30, nearest.pos.y + (dy / dl) * 70));
              }
            } else if (abilDef.id === 'hell_hound') {
              newSummons.push({ id: `hound-${now}`, kind: 'hellhound', pos: { ...nextPos }, health: 50, maxHealth: 50, speed: 5.5, damage: 8, radius: 14, attackTimer: 0 });
            } else if (abilDef.id === 'restriction_0') {
              newAbilities.restrictionUntil = now + 15000;
            } else if (abilDef.id === 'level_0') {
              for (let i = 0; i < 8; i++) {
                const angle = (i / 8) * Math.PI * 2;
                newSummons.push({ id: `soul-${now}-${i}`, kind: 'shadow_soldier', pos: { x: nextPos.x + Math.cos(angle) * 60, y: nextPos.y + Math.sin(angle) * 60 }, health: 30, maxHealth: 30, speed: 4.0, damage: 5, radius: 10, attackTimer: 0 });
              }
              newEnemies = newEnemies.map(e => ({ ...e, health: e.health - 200 * dmgMult }));
            } else if (abilDef.id === 'summon_familiar') {
              newSummons.push({ id: `fam-${now}`, kind: 'familiar', pos: { ...nextPos }, health: 40, maxHealth: 40, speed: 3.2, damage: 4, radius: 11, attackTimer: 0 });
            } else if (abilDef.id === 'round_table') {
              newSummons.push({ id: `elite-${now}`, kind: 'elite_vampire', pos: { ...nextPos }, health: 80, maxHealth: 80, speed: 3.8, damage: 7, radius: 14, attackTimer: 0 });
            } else if (abilDef.id === 'hellsing_protocol') {
              for (let i = 0; i < 5; i++) {
                const angle = (i / 5) * Math.PI * 2;
                newSummons.push({ id: `aluc-${now}-${i}`, kind: 'alucard_ghost', pos: { x: nextPos.x + Math.cos(angle) * 80, y: nextPos.y + Math.sin(angle) * 80 }, health: 60, maxHealth: 60, speed: 4.5, damage: 9, radius: 13, attackTimer: 0 });
              }
            } else if (abilDef.id === 'wire_cage') {
              const cageRange = 200;
              newEnemies = newEnemies.map(e => {
                const d = Math.sqrt((nextPos.x - e.pos.x) ** 2 + (nextPos.y - e.pos.y) ** 2);
                return d < cageRange ? { ...e, health: e.health - gunDmg * 1.5, speed: Math.max(0.4, e.speed * 0.3) } : e;
              });
            } else if (abilDef.id === 'decapitation') {
              newEnemies = newEnemies.map(e => {
                if (e.kind === 'cardinal') return e;
                const d = Math.sqrt((nextPos.x - e.pos.x) ** 2 + (nextPos.y - e.pos.y) ** 2);
                if (d < 300 && e.health < e.maxHealth * 0.4) return { ...e, health: 0 };
                return e;
              });
            } else if (abilDef.id === 'angel_mode') {
              newAbilities.angelModeUntil = now + 8000;
            } else if (abilDef.id === 'vampire_strike') {
              const strikeRange = 100;
              newEnemies = newEnemies.map(e => {
                const dx2 = e.pos.x - nextPos.x, dy2 = e.pos.y - nextPos.y;
                const d = Math.sqrt(dx2 * dx2 + dy2 * dy2);
                if (d > strikeRange) return e;
                const pushMult = 80 / (d || 1);
                return { ...e, health: e.health - gunDmg * 2, pos: { x: Math.max(20, Math.min(GAME_WIDTH - 20, e.pos.x + dx2 * pushMult / d * 80)), y: Math.max(20, Math.min(GAME_HEIGHT - 20, e.pos.y + dy2 * pushMult / d * 80)) } };
              });
            } else if (abilDef.id === 'blood_release') {
              newAbilities.bloodReleaseUntil = now + 8000;
            } else if (abilDef.id === 'shadow_wing') {
              const mx2 = mouseRef.current.x - nextPos.x, my2 = mouseRef.current.y - nextPos.y;
              const ml2 = Math.sqrt(mx2 * mx2 + my2 * my2) || 1;
              const ddx = mx2 / ml2, ddy = my2 / ml2;
              newEnemies = newEnemies.map(e => {
                const t = (e.pos.x - nextPos.x) * ddx + (e.pos.y - nextPos.y) * ddy;
                if (t < 0 || t > 500) return e;
                const cx = nextPos.x + ddx * t, cy = nextPos.y + ddy * t;
                const perp = Math.sqrt((e.pos.x - cx) ** 2 + (e.pos.y - cy) ** 2);
                return perp < 45 ? { ...e, health: e.health - gunDmg * 2.5 } : e;
              });
              nextPos.x = Math.max(30, Math.min(GAME_WIDTH - 30, nextPos.x + ddx * 350));
              nextPos.y = Math.max(30, Math.min(GAME_HEIGHT - 30, nextPos.y + ddy * 350));
            } else if (abilDef.id === 'holy_barrier') {
              newAbilities.shieldActive = true;
              newAbilities.shieldUntil = now + 4000;
            } else if (abilDef.id === 'nail_helena') {
              const mx3 = mouseRef.current.x - nextPos.x, my3 = mouseRef.current.y - nextPos.y;
              const ml3 = Math.sqrt(mx3 * mx3 + my3 * my3) || 1;
              newBullets.push({ id: `nail-${now}`, pos: { ...nextPos }, vel: { x: (mx3 / ml3) * 22, y: (my3 / ml3) * 22 }, speed: 22, radius: 10, damage: 200 * dmgMult, piercing: true, fromEnemy: false });
            } else if (abilDef.id === 'blessed_regen') {
              // handled in health update below
              newAbilities.cooldowns[abilitySlot] = cdMs;
            } else if (abilDef.id === 'regenerator_form') {
              newAbilities.regeneratorUntil = now + 10000;
            }
          }
        }

        for (let i = 0; i < newAbilities.cooldowns.length; i++) {
          newAbilities.cooldowns[i] = Math.max(0, newAbilities.cooldowns[i] - dt);
        }
        if (newAbilities.shieldUntil < now) newAbilities.shieldActive = false;

        newBullets = newBullets
          .map(b => ({ ...b, pos: { x: b.pos.x + b.vel.x, y: b.pos.y + b.vel.y } }))
          .filter(b => b.pos.x > -30 && b.pos.x < GAME_WIDTH + 30 && b.pos.y > -30 && b.pos.y < GAME_HEIGHT + 30);

        const hitEnemyIds = new Set<string>();
        newBullets = newBullets.filter(b => {
          if (b.fromEnemy) return true;
          let hit = false;
          newEnemies = newEnemies.map(e => {
            if (hitEnemyIds.has(e.id) && !b.piercing) return e;
            const d = Math.sqrt((b.pos.x - e.pos.x) ** 2 + (b.pos.y - e.pos.y) ** 2);
            if (d < b.radius + e.radius) {
              hit = true;
              hitEnemyIds.add(e.id);
              return { ...e, health: e.health - b.damage };
            }
            return e;
          });
          return b.piercing ? true : !hit;
        });

        const cardinal = newEnemies.find(e => e.kind === 'cardinal');
        if (cardinal && cardinal.health > 0) {
          const isP2 = cardinal.health < cardinal.maxHealth * 0.5;
          const shootInt = isP2 ? 2200 : 3200;
          if (now - (cardinal.shootTimer ?? 0) > shootInt) {
            const shots = isP2 ? 8 : 4;
            for (let i = 0; i < shots; i++) {
              const angle = (i / shots) * Math.PI * 2 + (cardinal.orbitAngle ?? 0);
              const bSpeed2 = 4.5 * diff.enemyDamageMult;
              newBullets.push({ id: `cb-${now}-${i}`, pos: { ...cardinal.pos }, vel: { x: Math.cos(angle) * bSpeed2, y: Math.sin(angle) * bSpeed2 }, speed: bSpeed2, radius: 7, damage: 9 * diff.enemyDamageMult, piercing: false, fromEnemy: true });
            }
            if (isP2 && Math.random() < 0.22) {
              const dx4 = nextPos.x - cardinal.pos.x, dy4 = nextPos.y - cardinal.pos.y;
              const dl4 = Math.sqrt(dx4 * dx4 + dy4 * dy4) || 1;
              newBullets.push({ id: `hb-${now}`, pos: { ...cardinal.pos }, vel: { x: (dx4 / dl4) * 7, y: (dy4 / dl4) * 7 }, speed: 7, radius: 9, damage: 12 * diff.enemyDamageMult, piercing: false, fromEnemy: true, homing: true });
            }
            const mInterval = isP2 ? 6000 : 10000;
            if (now - cardinalMinionTimerRef.current > mInterval) {
              cardinalMinionTimerRef.current = now;
              const mKind: ChurchEnemyKind = isP2 ? 'fallen_angel' : 'crusader';
              for (let m = 0; m < (isP2 ? 2 : 1); m++) {
                const angle2 = Math.random() * Math.PI * 2;
                const r = 120 + Math.random() * 80;
                const mhp = isP2 ? Math.round(40 * diff.enemyHealthMult) : Math.round(50 * diff.enemyHealthMult);
                newEnemies.push({ id: `cm-${now}-${m}`, kind: mKind, pos: { x: Math.max(60, Math.min(GAME_WIDTH - 60, cardinal.pos.x + Math.cos(angle2) * r)), y: Math.max(60, Math.min(GAME_HEIGHT - 60, cardinal.pos.y + Math.sin(angle2) * r)) }, health: mhp, maxHealth: mhp, speed: mKind === 'fallen_angel' ? 3.2 : 1.8, radius: mKind === 'fallen_angel' ? 11 : 13, shootTimer: 0 });
              }
            }
            newEnemies = newEnemies.map(e => e.id === 'cardinal' ? { ...e, shootTimer: now, orbitAngle: ((e.orbitAngle ?? 0) + (isP2 ? 0.10 : 0.05)) % (Math.PI * 2), phase: isP2 ? 2 : 1 } : e);
          }
        }

        for (const e of newEnemies.filter(e => e.kind === 'crusader' && e.id !== 'cardinal')) {
          const shootInt2 = 2600 / diff.enemyDamageMult;
          if (now - (e.shootTimer ?? 0) > shootInt2) {
            const dx5 = nextPos.x - e.pos.x, dy5 = nextPos.y - e.pos.y;
            const dl5 = Math.sqrt(dx5 * dx5 + dy5 * dy5) || 1;
            const bSpd2 = 7.5;
            newBullets.push({ id: `cr-${now}-${e.id}`, pos: { ...e.pos }, vel: { x: (dx5 / dl5) * bSpd2, y: (dy5 / dl5) * bSpd2 }, speed: bSpd2, radius: 6, damage: 8 * diff.enemyDamageMult, piercing: false, fromEnemy: true });
            newEnemies = newEnemies.map(en => en.id === e.id ? { ...en, shootTimer: now } : en);
          }
        }

        const cardinalCur = newEnemies.find(e => e.kind === 'cardinal');
        if (cardinalCur && cardinalCur.health > 0) {
          const isP2 = cardinalCur.health < cardinalCur.maxHealth * 0.5;
          const orbitR = isP2 ? 200 : 160;
          const orbitSpd = (isP2 ? 0.0012 : 0.0007) * dt;
          const newAngle = ((cardinalCur.orbitAngle ?? 0) + orbitSpd) % (Math.PI * 2);
          const cx = GAME_WIDTH / 2 + Math.cos(newAngle) * orbitR;
          const cy = 300 + Math.sin(newAngle) * 130;
          newEnemies = newEnemies.map(e => e.id === 'cardinal' ? { ...e, pos: { x: Math.max(50, Math.min(GAME_WIDTH - 50, cx)), y: Math.max(80, Math.min(GAME_HEIGHT - 200, cy)) }, orbitAngle: newAngle } : e);
        }

        newEnemies = newEnemies.filter(e => e.kind !== 'cardinal').map(e => {
          if (e.health <= 0) return e;
          const ex = nextPos.x - e.pos.x, ey = nextPos.y - e.pos.y;
          const dist = Math.sqrt(ex * ex + ey * ey) || 1;
          const spd2 = e.speed;
          return { ...e, pos: { x: e.pos.x + (ex / dist) * spd2, y: e.pos.y + (ey / dist) * spd2 } };
        }).concat(newEnemies.filter(e => e.kind === 'cardinal'));

        newSummons = newSummons.filter(s => s.health > 0).map(s => {
          const target = newEnemies.filter(e => e.health > 0).reduce<ChurchEnemy | null>((best, e) => {
            const d = Math.sqrt((s.pos.x - e.pos.x) ** 2 + (s.pos.y - e.pos.y) ** 2);
            if (!best) return e;
            return d < Math.sqrt((s.pos.x - best.pos.x) ** 2 + (s.pos.y - best.pos.y) ** 2) ? e : best;
          }, null);
          if (!target) return s;
          const dx6 = target.pos.x - s.pos.x, dy6 = target.pos.y - s.pos.y;
          const d6 = Math.sqrt(dx6 * dx6 + dy6 * dy6) || 1;
          const newPos = d6 < s.radius + target.radius + 4 ? s.pos : { x: s.pos.x + (dx6 / d6) * s.speed, y: s.pos.y + (dy6 / d6) * s.speed };
          if (d6 < s.radius + target.radius + 4 && now - s.attackTimer > 600) {
            newEnemies = newEnemies.map(e => e.id === target.id ? { ...e, health: e.health - s.damage } : e);
            return { ...s, pos: newPos, attackTimer: now };
          }
          return { ...s, pos: newPos };
        });

        const shieldBlocking = newAbilities.shieldActive || now < newAbilities.shieldUntil;
        let newHealth = prev.player.health;
        let touchingEnemy = false;
        newEnemies.filter(e => e.health > 0).forEach(e => {
          const d = Math.sqrt((nextPos.x - e.pos.x) ** 2 + (nextPos.y - e.pos.y) ** 2);
          if (d < e.radius + prev.player.radius + 2) touchingEnemy = true;
        });

        if (touchingEnemy && !shieldBlocking && now - lastDamageRef.current > DAMAGE_COOLDOWN) {
          const cardinal2 = newEnemies.find(e => e.kind === 'cardinal' && e.health > 0);
          newHealth -= ((cardinal2 ? 18 : 10) * diff.enemyDamageMult * fx.damageTakenMult);
          lastDamageRef.current = now;
        }

        const enemyBulletsHit = newBullets.filter(b => b.fromEnemy && Math.sqrt((b.pos.x - nextPos.x) ** 2 + (b.pos.y - nextPos.y) ** 2) < b.radius + prev.player.radius);
        if (enemyBulletsHit.length > 0 && !shieldBlocking && now - lastDamageByEnemyRef.current > 300) {
          const totalDmg = enemyBulletsHit.reduce((sum, b) => sum + b.damage, 0);
          newHealth -= totalDmg * fx.damageTakenMult;
          lastDamageByEnemyRef.current = now;
          newBullets = newBullets.filter(b => !enemyBulletsHit.includes(b));
        }

        const pasiveRegen = (char.stats.regen + fx.regenBonus + (now < newAbilities.regeneratorUntil ? 20 : 0)) * dt / 1000;
        if (pasiveRegen > 0) newHealth = Math.min(prev.player.maxHealth, newHealth + pasiveRegen);
        if (char.stats.vampiricRegen) {
          const killed2 = newEnemies.filter(e => e.health <= 0 && prev.enemies.find(pe => pe.id === e.id && pe.health > 0));
          newHealth = Math.min(prev.player.maxHealth, newHealth + killed2.length * 5);
        }

        const killed = newEnemies.filter(e => e.health <= 0 && prev.enemies.some(pe => pe.id === e.id && pe.health > 0));
        if (killed.length > 0) {
          newHealth = Math.min(prev.player.maxHealth, newHealth + killed.length * fx.healPerKill);
        }

        const scoreGain = killed.reduce((t, e) => t + (e.kind === 'cardinal' ? 5000 : e.kind === 'fallen_angel' ? 200 : 150), 0);
        const newScore = prev.score + Math.round(scoreGain * diff.scoreMultiplier);
        newEnemies = newEnemies.filter(e => e.health > 0);

        let newHazardBeams = prev.hazardBeams.map(beam => {
          let { stateTimer, active, warning } = beam;
          stateTimer -= dt;
          if (active && stateTimer <= 0) {
            return { ...beam, active: false, warning: false, stateTimer: beam.offDuration };
          } else if (warning && !active && stateTimer <= 0) {
            return { ...beam, active: true, warning: false, stateTimer: beam.activeDuration };
          } else if (!active && !warning && stateTimer <= 0) {
            return { ...beam, active: false, warning: true, stateTimer: beam.warnDuration };
          }
          return { ...beam, stateTimer, active, warning };
        });

        const inActiveBeam = newHazardBeams.some(beam => {
          if (!beam.active) return false;
          if (beam.axis === 'h') return Math.abs(nextPos.y - beam.position) < beam.thickness + prev.player.radius;
          return Math.abs(nextPos.x - beam.position) < beam.thickness + prev.player.radius;
        });
        if (inActiveBeam && !shieldBlocking && now - lastDamageRef.current > 500) {
          newHealth -= 15 * diff.enemyDamageMult;
          lastDamageRef.current = now;
        }

        let newStatus: ChurchState['status'] = prev.status;
        let newRoomMsg = prev.roomMessage;
        let newBossMsg = prev.bossMessage;
        let newRoomGrid = prev.roomGrid.map(row => [...row]);
        let newPendingRelic: ChurchRelicId | null = prev.pendingRelic;

        const justCleared = curRoom && !curRoom.cleared && newEnemies.length === 0;
        if (justCleared) {
          if (curRoom.type === 'boss') {
            newStatus = 'victory';
            runningRef.current = false;
          } else {
            newRoomGrid[prev.currentRoomPos.row][prev.currentRoomPos.col] = { ...curRoom, cleared: true };
            if (fx.healOnRoomClear > 0) newHealth = Math.min(prev.player.maxHealth, newHealth + fx.healOnRoomClear);
            newHazardBeams = [];
            if (curRoom.type === 'item' && curRoom.itemId) {
              newPendingRelic = curRoom.itemId;
              newStatus = 'item_pickup';
              runningRef.current = false;
            } else {
              newRoomMsg = 'Room cleared — doors open';
            }
          }
        }

        const cardinal3 = newEnemies.find(e => e.kind === 'cardinal');
        if (cardinal3) {
          const isP2b = cardinal3.health < cardinal3.maxHealth * 0.5;
          newBossMsg = isP2b ? '⚠ CARDINAL SANCTUS — DIVINE WRATH' : 'Cardinal Sanctus — The Fallen Light';
        }

        if (newHealth <= 0) {
          newStatus = 'gameover';
          runningRef.current = false;
        }

        const { col, row } = prev.currentRoomPos;
        let newRoomPos = prev.currentRoomPos;
        if (isCleared) {
          const p = nextPos;
          const conns = curRoom?.connections ?? {};
          if (conns.north && p.y < DOOR_ZONE && Math.abs(p.x - GAME_WIDTH / 2) < 80) {
            const nr = row - 1, nc = col;
            if (nr >= 0 && prev.roomGrid[nr][nc]) {
              const nextRoom = prev.roomGrid[nr][nc]!;
              if (nextRoom.type === 'gargant' && !nextRoom.visited) {
                newRoomGrid[nr][nc] = { ...nextRoom, visited: true };
                runningRef.current = false;
                return { ...prev, status: 'gargant_joke', gargantTimer: 0, dialogueLine: 0, player: { ...prev.player, pos: { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 } }, roomGrid: newRoomGrid };
              }
              newRoomPos = { row: nr, col: nc };
              const spawnedEnemies = nextRoom.cleared ? [] : spawnRoomEnemies(nextRoom.type, diff.enemyHealthMult, prev.characterId);
              const beams = nextRoom.type === 'gauntlet' ? createHazardBeams() : [];
              newRoomGrid[nr][nc] = { ...nextRoom, visited: true };
              return { ...prev, currentRoomPos: newRoomPos, enemies: spawnedEnemies, bullets: [], summons: [], hazardBeams: beams, roomGrid: newRoomGrid, player: { ...prev.player, pos: { x: GAME_WIDTH / 2, y: GAME_HEIGHT - 100 }, health: newHealth }, score: newScore };
            }
          }
          if (conns.south && p.y > GAME_HEIGHT - DOOR_ZONE && Math.abs(p.x - GAME_WIDTH / 2) < 80) {
            const nr = row + 1, nc = col;
            if (nr < GRID_ROWS && prev.roomGrid[nr][nc]) {
              const nextRoom = prev.roomGrid[nr][nc]!;
              if (nextRoom.type === 'gargant' && !nextRoom.visited) {
                newRoomGrid[nr][nc] = { ...nextRoom, visited: true };
                runningRef.current = false;
                return { ...prev, status: 'gargant_joke', gargantTimer: 0, dialogueLine: 0, player: { ...prev.player, pos: { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 } }, roomGrid: newRoomGrid };
              }
              newRoomPos = { row: nr, col: nc };
              const spawnedEnemies = nextRoom.cleared ? [] : spawnRoomEnemies(nextRoom.type, diff.enemyHealthMult, prev.characterId);
              const beams = nextRoom.type === 'gauntlet' ? createHazardBeams() : [];
              newRoomGrid[nr][nc] = { ...nextRoom, visited: true };
              return { ...prev, currentRoomPos: newRoomPos, enemies: spawnedEnemies, bullets: [], summons: [], hazardBeams: beams, roomGrid: newRoomGrid, player: { ...prev.player, pos: { x: GAME_WIDTH / 2, y: 100 }, health: newHealth }, score: newScore };
            }
          }
          if (conns.west && p.x < DOOR_ZONE && Math.abs(p.y - GAME_HEIGHT / 2) < 80) {
            const nr = row, nc = col - 1;
            if (nc >= 0 && prev.roomGrid[nr][nc]) {
              const nextRoom = prev.roomGrid[nr][nc]!;
              if (nextRoom.type === 'gargant' && !nextRoom.visited) {
                newRoomGrid[nr][nc] = { ...nextRoom, visited: true };
                runningRef.current = false;
                return { ...prev, status: 'gargant_joke', gargantTimer: 0, dialogueLine: 0, player: { ...prev.player, pos: { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 } }, roomGrid: newRoomGrid };
              }
              newRoomPos = { row: nr, col: nc };
              const spawnedEnemies = nextRoom.cleared ? [] : spawnRoomEnemies(nextRoom.type, diff.enemyHealthMult, prev.characterId);
              const beams = nextRoom.type === 'gauntlet' ? createHazardBeams() : [];
              newRoomGrid[nr][nc] = { ...nextRoom, visited: true };
              return { ...prev, currentRoomPos: newRoomPos, enemies: spawnedEnemies, bullets: [], summons: [], hazardBeams: beams, roomGrid: newRoomGrid, player: { ...prev.player, pos: { x: GAME_WIDTH - 100, y: GAME_HEIGHT / 2 }, health: newHealth }, score: newScore };
            }
          }
          if (conns.east && p.x > GAME_WIDTH - DOOR_ZONE && Math.abs(p.y - GAME_HEIGHT / 2) < 80) {
            const nr = row, nc = col + 1;
            if (nc < GRID_COLS && prev.roomGrid[nr][nc]) {
              const nextRoom = prev.roomGrid[nr][nc]!;
              if (nextRoom.type === 'gargant' && !nextRoom.visited) {
                newRoomGrid[nr][nc] = { ...nextRoom, visited: true };
                runningRef.current = false;
                return { ...prev, status: 'gargant_joke', gargantTimer: 0, dialogueLine: 0, player: { ...prev.player, pos: { x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 } }, roomGrid: newRoomGrid };
              }
              newRoomPos = { row: nr, col: nc };
              const spawnedEnemies = nextRoom.cleared ? [] : spawnRoomEnemies(nextRoom.type, diff.enemyHealthMult, prev.characterId);
              const beams = nextRoom.type === 'gauntlet' ? createHazardBeams() : [];
              newRoomGrid[nr][nc] = { ...nextRoom, visited: true };
              return { ...prev, currentRoomPos: newRoomPos, enemies: spawnedEnemies, bullets: [], summons: [], hazardBeams: beams, roomGrid: newRoomGrid, player: { ...prev.player, pos: { x: 100, y: GAME_HEIGHT / 2 }, health: newHealth }, score: newScore };
            }
          }
        }

        const abilitySlot2Used = char.abilities.findIndex((a, i) => a.id === 'blessed_regen' && newAbilities.cooldowns[i] > 0 && prev.abilities.cooldowns[i] === 0);
        if (abilitySlot2Used >= 0) {
          newHealth = Math.min(prev.player.maxHealth, newHealth + 60);
        }

        return {
          ...prev,
          status: newStatus,
          player: { ...prev.player, pos: nextPos, health: Math.max(0, newHealth) },
          enemies: newEnemies,
          bullets: newBullets,
          summons: newSummons,
          hazardBeams: newHazardBeams,
          abilities: newAbilities,
          score: newScore,
          bossMessage: newBossMsg,
          roomMessage: newRoomMsg,
          roomGrid: newRoomGrid,
          pendingRelic: newPendingRelic,
          wireArcTimer: char.weapon === 'wire' && isMouseDownRef.current ? Math.max(0, (prev.wireArcTimer ?? 0) - dt) : 0,
        };
      });

      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  return {
    churchState, startChurch, acceptRelic, rejectRelic,
    setTouchMovement, setAimPosition, setFiring, activateAbility,
    GAME_WIDTH, GAME_HEIGHT, GRID_COLS, GRID_ROWS,
  };
}
